#!/usr/bin/env python
#  -*- coding: utf-8 -*-

from __future__ import print_function
from time import sleep
from sys import stdout
from daqhats import mcc118, OptionFlags, HatIDs, HatError
from daqhats_utils import select_hat_device, enum_mask_to_string, chan_list_to_mask
import time
from tkinter import *
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib import style


GUI = Tk()
GUI.geometry('750x250')
GUI.title('Analog Input Live Graph')

style.use('ggplot')

fig = plt.figure(figsize=(15,5), dpi=50)
ax1 = fig.add_subplot(1, 1, 1)

#CURSOR_BACK_2 = '\x1b[2D'
#ERASE_TO_END_OF_LINE = '\x1b[0K'

str = str (input("Enter Channels to Record Seperated by Commas:"))
list=str.split(",")
li=[]
for i in list:
    li.append(int(i))
print(li)

channels = li

# Create a dummy clock and the number of ittrations to run through the sampling script
h=time.time()
trigb = 20
triga = 0

# Set up the board and the cannels to record
channel_mask = chan_list_to_mask(channels)
num_channels = len(channels)

# Set how many samples are to be collected and the sample rate
samples_per_channel = 20
scan_rate = 10
options = OptionFlags.DEFAULT

# Create a GUI to place the real-time plot on
plotcanvas = FigureCanvasTkAgg(fig, GUI)
plotcanvas.get_tk_widget().grid(column=1, row=1)

# Determine how many samples need to be read and how fast they should be read
total_samples_read = 0
samples_per_channel_read= 1
timeout = 1/scan_rate

# Select an MCC 118 HAT device to use.
address = select_hat_device(HatIDs.MCC_118)
hat = mcc118(address)
hat.a_in_scan_stop()

print('\nSelected MCC 118 HAT device at address', address)

actual_scan_rate = hat.a_in_scan_actual_rate(num_channels, scan_rate)

input('\nPress ENTER to continue ...')            

# Configure and start the scan.
hat.a_in_scan_start(channel_mask, samples_per_channel, scan_rate,options)

# Display the header row for the data table.
print('Samples Read    Scan Count', end='')
for chan in channels:
    print('    Channel ', chan, sep='', end='')    
print('')


def animate(i):
    global trigb
    global triga
    global total_samples_read
    
    graph_data = open('Position_Feedback.txt','r').read()
    lines = graph_data.split('\n')
    xs = []
    ys = []
    for line in lines:
        if len(line) > 1:
            x, y = line.split(',')
            xs.append(x)
            ys.append(y) 
    ax1.clear()
    
    ax1.plot(xs,ys)
    line, = ax1.plot(xs, ys, 'b', linewidth=.05, linestyle='dashed', marker='o', markerfacecolor='r', markersize=4)
        
    if triga < trigb:
        triga += 1
        read_and_display_data(hat, samples_per_channel, num_channels)
    


def read_and_display_data(hat, samples_per_channel, num_channels):
    global h
    global scan_rate
    global total_samples_read
    global samples_per_channel_read
    global timeout
    global animate
    
    total_samples_read = 1
    
    #hat.a_in_scan_start(channel_mask, samples_per_channel, scan_rate,options)
    
    while total_samples_read < samples_per_channel:
        read_result = hat.a_in_scan_read(samples_per_channel_read, timeout)
      
        ts= time.time()-h
        samples_read_per_channel = int(len(read_result.data) / num_channels)
        total_samples_read += samples_read_per_channel
                  
        # Display the last sample for each channel.
        print('\r{:8}'.format(samples_read_per_channel),' {:12} '.format(total_samples_read), end='')

        if samples_read_per_channel > 0:
            index = samples_read_per_channel * num_channels - num_channels

            for i in range(num_channels):
                file_object=open("Position_Feedback.txt","a")
                file_object.write('{0} {1}\n'.format("%.6f"%ts,","+"%.2f"%read_result.data[index + i]))
                
                print('{:12.5f}'.format(read_result.data[index + i]), 'V ',time.time()-h,
                      end='')
                file_object.close()
                
            stdout.flush()
            print('\n')

    ani = animation.FuncAnimation(fig, animate)
    
# Redraw the plot at a given interval

