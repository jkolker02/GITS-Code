import numpy as np
import pandas

pandas.set_option('display.max_colwidth',-1)

df = pandas.read_csv('Position_Feedback.txt', sep=',', header=None)

df = pandas.DataFrame(df)

df_len = len(df)

df_count = len(df.columns)

print(df_len,df_count)


#df = ((df.loc[df_len-1000:df_len,[0,1]]))
#
#df.to_csv('Position_Feedback.txt', header=False, index=False)

#x = ((df.loc[df_len-30:df_len,[0]]))
#x = (x[0]).tolist()
#
#y = ((df.loc[df_len-30:df_len,[1]]))
#y = (y[1]).tolist()

