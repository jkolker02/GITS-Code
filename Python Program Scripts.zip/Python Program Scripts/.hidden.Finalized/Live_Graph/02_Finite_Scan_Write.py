#!/usr/bin/env python

from __future__ import print_function
from time import sleep
from sys import stdout
from daqhats import mcc118, OptionFlags, HatIDs, HatError
from daqhats_utils import select_hat_device, enum_mask_to_string, chan_list_to_mask
import time
import pandas
import os
import csv

str = str (input("Enter Channels to Record Seperated by Commas:"))
list=str.split(",")
li=[]
for i in list:
    li.append(int(i))
print(li)

channels = li

channel_mask = chan_list_to_mask(channels)
num_channels = len(channels)

samples_per_channel = 2000
scan_rate = 75
options = OptionFlags.DEFAULT


# Select an MCC 118 HAT device to use.
address = select_hat_device(HatIDs.MCC_118)
hat = mcc118(address)
hat.a_in_scan_stop()

print('\nSelected MCC 118 HAT device at address', address)

actual_scan_rate = hat.a_in_scan_actual_rate(num_channels, scan_rate)


input('\nPress ENTER to continue ...')
            

# Configure and start the scan.


# Display the header row for the data table.
#print('Samples Read    Scan Count', end='')
#
#for chan in channels:
#    print('    Channel ', chan, sep='', end='')
#    
#print('')

dummy_clock=time.time()
file_object=open("Position_Feedback.txt","w")
file_object.close()


def read_and_display_data(hat, samples_per_channel, num_channels):
    global dummy_clock
    global scan_rate
    global channel_mask, scan_rate,options
    
    total_samples_read = 0
    samples_per_channel_read= 1
    timeout = 1/scan_rate
    
    if os.stat('Position_Feedback.txt').st_size == 0:
        print('empty')
    else:
        pandas.set_option('display.max_colwidth',-1)
        df = pandas.read_csv('Position_Feedback.txt', sep=',', header=None)
        df = pandas.DataFrame(df)
        df_len = len(df)
        df = ((df.loc[df_len-1000:df_len,0:]))
        df.to_csv('Position_Feedback.txt', header=False, index=False)
    
    hat.a_in_scan_start(channel_mask, samples_per_channel, scan_rate,options)
    
    while total_samples_read < samples_per_channel:
        read_result = hat.a_in_scan_read(samples_per_channel_read, timeout)
        
        ts= time.time()-dummy_clock
        samples_read_per_channel = int(len(read_result.data) / num_channels)
        total_samples_read += samples_read_per_channel
                  
        if samples_read_per_channel > 0:
            index = (samples_read_per_channel * num_channels) - num_channels
            data=read_result.data
            data.insert(0,ts)
            with open("Position_Feedback.txt","a") as file_object:
                writer = csv.writer(file_object)
                writer.writerow(data)
            #file_object.writerows('{0} {1}\n'.format("%.6f"%ts,","+"%.2f"%read_result.data))
            #print(i)
                
    hat.a_in_scan_stop()
    hat.a_in_scan_cleanup()
    stdout.flush()
    read_and_display_data(hat, samples_per_channel, num_channels)

read_and_display_data(hat, samples_per_channel, num_channels)

stdout.flush() 