#!/usr/bin/env python3

from tkinter import *
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib import style
import pandas
import os


GUI = Tk()
GUI.geometry('750x250')
GUI.title('Analog Input Live Graph')

style.use('ggplot')

fig = plt.figure(figsize=(15,5), dpi=50)
ax1 = fig.add_subplot(1, 1, 1)

x=0
y1=0
y2=0

def animate(i):
    global x, y1, y2
    
    if os.stat('Position_Feedback.txt').st_size == 0:
        x=0
        y1=0
        y2=0
        
    else:
        pandas.set_option('display.max_colwidth',-1)
        df = pandas.read_csv('Position_Feedback.txt', sep=',', header=None)
        df = pandas.DataFrame(df)
        df_len = len(df)
        df_count = len(df.columns)
        
        
        if df_count == 2:
            if df_len < 1000:
                
                x = ((df.loc[1:df_len,[0]]))
                x = (x[0]).tolist()

                y1 = ((df.loc[1:df_len,[1]]))
                y1 = (y1[1]).tolist()
                
                
            elif df_len > 1000:
                
                x = ((df.loc[df_len-900:df_len,[0]]))
                x = (x[0]).tolist()

                y1 = ((df.loc[df_len-900:df_len,[1]]))
                y1 = (y1[1]).tolist()
            
            ax1.clear()
            ax1.plot(x,y1,'m')
            plt.ylim(-.5,5)
            
        
        elif df_count == 3:
            if df_len < 1000:
                
                x = ((df.loc[1:df_len,[0]]))
                x = (x[0]).tolist()

                y1 = ((df.loc[1:df_len,[1]]))
                y1 = (y1[1]).tolist()
                
                y2 = ((df.loc[1:df_len,[2]]))
                y2 = (y2[2]).tolist()
                
            elif df_len > 1000:
                
                x = ((df.loc[df_len-900:df_len,[0]]))
                x = (x[0]).tolist()

                y1 = ((df.loc[df_len-900:df_len,[1]]))
                y1 = (y1[1]).tolist()
                
                y2 = ((df.loc[df_len-900:df_len,[2]]))
                y2 = (y2[2]).tolist()
             
            ax1.clear()
            ax1.plot(x,y1,'b',x,y2,'g')
            plt.ylim(-.5,5)
            

def Exit_Program():
    print("Exit Button pressed")
    sys.exit()

plotcanvas = FigureCanvasTkAgg(fig, GUI)
plotcanvas.get_tk_widget().grid(column=1, row=1)    
ani = animation.FuncAnimation(fig, animate, interval=1,blit=False)

GUI.protocol("WM_DELETE_WINDOW", Exit_Program)
GUI.mainloop()
