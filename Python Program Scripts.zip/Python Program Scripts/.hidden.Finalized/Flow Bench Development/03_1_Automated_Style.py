#!/usr/bin/env python3

#Imported Libraries for Background Processing
import os
from tkinter import *
import tkinter as tk
import subprocess
from tkinter import messagebox
import csv

#Setup the GUI Window
GUI = Tk()

GUI.grid_rowconfigure(0, minsize=25)
GUI.grid_rowconfigure(1, minsize=5)
GUI.grid_rowconfigure(3, minsize=25)
GUI.grid_rowconfigure(4, minsize=5)

GUI.grid_columnconfigure(0, minsize=10)
GUI.grid_columnconfigure(4, minsize=10)

GUI.configure(background='black')
GUI.title('Flow Bench User Interface Setup')

GUIFI = Frame(GUI, height=1, bg='black')
GUIFI.grid(row=2, column=2)
GUIFI.grid_columnconfigure(0, minsize=75)
GUIFI.grid_rowconfigure(2, minsize=10)
GUIFI.grid_columnconfigure(1, minsize=30)
GUIFI.grid_columnconfigure(3, minsize=30)

GUIF = Frame(GUI, bg='black', height=1)
GUIF.grid(row=1, column=2)

GUIFII = Frame(GUI, height=1, bg='black')
GUIFII.grid(row=3, column=2, sticky = W)
GUIFII.grid_columnconfigure(1, minsize=10)

M = tk.StringVar()
M.set(0)

#Setup Callable Functions
    #Function to launch ramp program
def Ramp():
    with open("Z1_BENCH_CONFIGURATION.txt","a") as file_object:
                writer = csv.writer(file_object)
                writer.writerow([M.get()])
                file_object.close()
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/04_Confirmation_Page.py"])
    sys.exit()
    #Function to launch step program
def Step():
    with open("Z1_BENCH_CONFIGURATION.txt","a") as file_object:
                writer = csv.writer(file_object)
                writer.writerow([M.get()])
                file_object.close()
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/04_Confirmation_Page.py"]) 
    sys.exit()
    #Function to launch step program
def Equation():
    with open("Z1_BENCH_CONFIGURATION.txt","a") as file_object:
                writer = csv.writer(file_object)
                writer.writerow([M.get()])
                file_object.close()
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/04_Confirmation_Page.py"]) 
    sys.exit()
    #Function to define pressure transducer usage
def Mode_Select():
    global M
    
    if M.get() == '0':
        print('no mode')
    elif M.get() == '1':
        print('Ramp')
    elif M.get() == '2':
        print('Step')
    elif M.get() == '3':
        print('Equation')
        
    #Function to return to previous screen
def Back():
            
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/03_0_Automated_Manual.py"]) 
    sys.exit()    
    #Function to end program selection window
def Forward():
    if M.get() == '0':
        messagebox.showinfo("Error - No Selection Made","Please select RAMP, STEP, or EQUATION CONTROL")
    elif M.get() == '2':
        Ramp()
    elif M.get() == '3':
        Step()
    elif M.get() == '4':
        Equation()
    #Function to exit the program properly
def Exit_Program():
    print("Exit Button pressed")
    file_object=open("Z1_BENCH_CONFIGURATION.txt","w")
    file_object.close()
    sys.exit()
    
#Buttons and Labels
    #Headers/titles - LABELS
Header = Label(GUI, text="Flow Bench User Interface - System Setup (*3/4)", background='black', font = 'Helvetica 14 bold underline bold', fg='dark goldenrod')
Header.grid(row=0, column=2)
    #Pick Pressure as Primary Control - LABEL ENTRY
Choice_Ramp = Radiobutton(GUIFI, text='    Enable Ramp    \n Control', value=2, variable=M, command=Mode_Select, selectcolor='green', background='black', font = 'Helvetica 10 bold', fg='dark goldenrod', activebackground='gray20', activeforeground = 'dark goldenrod')
Choice_Ramp.grid(row=0, column=0, sticky=W)
    #Pick Flow as Primary Control - LABEL ENTRY
Choice_Step = Radiobutton(GUIFI, text='     Enable Step     \n Control', value=3, variable=M, command=Mode_Select, selectcolor='green', background='black', font = 'Helvetica 10 bold', fg='dark goldenrod', activebackground='gray20', activeforeground = 'dark goldenrod')
Choice_Step.grid(row=0, column=2)
    #Pick Flow as Primary Control - LABEL ENTRY
Choice_Equation = Radiobutton(GUIFI, text='  Enable Equation  \n Control', value=4, variable=M, command=Mode_Select, selectcolor='green', background='black', font = 'Helvetica 10 bold', fg='dark goldenrod', activebackground='gray20', activeforeground = 'dark goldenrod')
Choice_Equation.grid(row=0, column=4, sticky=E)
    #Program Forward - BUTTON COMMAND
ForwardButton = tk.Button(GUIFII, text="Next Screen",command=Forward, background='steel blue', width =12, font = 'Helvetica 8 bold', highlightbackground='gray82', activebackground='royal blue', borderwidth=.5, relief='solid')
ForwardButton.grid(row=3, column=2, sticky = E)
    #Program Back - BUTTON COMMAND
BackButton = tk.Button(GUIFII, text="Previous Screen",command=Back, background='steel blue', width =12, font = 'Helvetica 8 bold', highlightbackground='gray82', activebackground='royal blue', borderwidth=.5, relief='solid')
BackButton.grid(row=3, column=0, sticky = W)
    #Program Exit - BUTTON COMMAND
ExitButton = tk.Button(GUI, text="EXIT NOW",command=Exit_Program, background='orangered4', width =10, font = 'Helvetica 8 bold', highlightbackground='yellow', activebackground='orangered3', borderwidth=.5, relief='solid')
ExitButton.grid(row=3, column=2, columnspan = 2, sticky = E)

#Keeping the Window Open and Protocals for Closing
GUI.protocol("WM_DELETE_WINDOW", Exit_Program)
GUI.mainloop()
