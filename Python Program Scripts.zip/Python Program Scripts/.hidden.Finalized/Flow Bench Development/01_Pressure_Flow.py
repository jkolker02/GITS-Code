#!/usr/bin/env python3

#Imported Libraries for Background Processing
import os
from tkinter import *
import tkinter as tk
import subprocess
import csv
from tkinter import messagebox

#Setup the GUI Window
GUI = Tk()

GUI.grid_rowconfigure(0, minsize=25)
GUI.grid_rowconfigure(1, minsize=5)
GUI.grid_rowconfigure(3, minsize=25)
GUI.grid_rowconfigure(4, minsize=5)

GUI.grid_columnconfigure(0, minsize=10)
GUI.grid_columnconfigure(4, minsize=10)

GUI.configure(background='black')
GUI.title('Flow Bench User Interface Setup')

GUIFI = Frame(GUI, height=1, bg='black')
GUIFI.grid(row=2, column=2)
GUIFI.grid_columnconfigure(0, minsize=75)
GUIFI.grid_rowconfigure(2, minsize=10)
GUIFI.grid_columnconfigure(1, minsize=75)

GUIF = Frame(GUI, bg='black', height=1)
GUIF.grid(row=1, column=2)

GUIFII = Frame(GUI, height=1, bg='black')
GUIFII.grid(row=3, column=2, sticky = W)
GUIFII.grid_columnconfigure(1, minsize=10)

M = tk.StringVar()
M.set(0)

file_object=open("Z1_BENCH_CONFIGURATION.txt","w")
file_object.close()

#Setup Callable Functions
    #Function to launch ramp program
def Pressure():
    
    with open("Z1_BENCH_CONFIGURATION.txt","a") as file_object:
                writer = csv.writer(file_object)
                writer.writerow([1])
                file_object.close()
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/02_Instrument_Setup.py"])
    sys.exit()
    #Function to launch step program
def Flow():
    with open("Z1_BENCH_CONFIGURATION.txt","a") as file_object:
                writer = csv.writer(file_object)
                writer.writerow([2])
                file_object.close()
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/02_Instrument_Setup.py"]) 
    sys.exit()
    #Function to define pressure transducer usage
def Mode_Select():
    global M
    
    if M.get() == '0':
        print('no mode')
    elif M.get() == '1':
        print('Pressure Control')
    elif M.get() == '2':
        print('Flow Control')
#Function to end program selection window
def Forward():
    if M.get() == '0':
        messagebox.showinfo("Error - No Selection Made","Please select PRESSURE CONTROL or FLOW CONTROL")
    elif M.get() == '1':
        Pressure()
    elif M.get() == '2':
        Flow()
#Function to exit the program properly
def Exit_Program():
    print("Exit Button pressed")
    file_object=open("Z1_BENCH_CONFIGURATION.txt","w")
    file_object.close()
    sys.exit()
    
#Buttons and Labels
    #Headers/titles - LABELS
Header = Label(GUI, text="Flow Bench User Interface - System Setup (1/4)", background='black', font = 'Helvetica 14 bold underline bold', fg='dark goldenrod')
Header.grid(row=0, column=2)
    #Pick Pressure as Primary Control - LABEL ENTRY
Choice_Pressure = Radiobutton(GUIFI, text='   Enable Pressure   \n Control', value=1, variable=M, command=Mode_Select, selectcolor='green', background='black', font = 'Helvetica 10 bold', fg='dark goldenrod', activebackground='gray20', activeforeground = 'dark goldenrod')
Choice_Pressure.grid(row=0, column=0, sticky=W)
    #Pick Flow as Primary Control - LABEL ENTRY
Choice_Flow = Radiobutton(GUIFI, text='       Enable Flow      \n Control', value=2, variable=M, command=Mode_Select, selectcolor='green', background='black', font = 'Helvetica 10 bold', fg='dark goldenrod', activebackground='gray20', activeforeground = 'dark goldenrod')
Choice_Flow.grid(row=0, column=2, sticky=W)
    #Program Forward - BUTTON COMMAND
ForwardButton = tk.Button(GUIFII, text="Next Screen",command=Forward, background='steel blue', width =12, font = 'Helvetica 8 bold', highlightbackground='gray82', activebackground='royal blue', borderwidth=.5, relief='solid')
ForwardButton.grid(row=3, column=2, sticky = E)
    #Program Exit - BUTTON COMMAND
ExitButton = tk.Button(GUI, text="EXIT NOW",command=Exit_Program, background='orangered4', width =10, font = 'Helvetica 8 bold', highlightbackground='yellow', activebackground='orangered3', borderwidth=.5, relief='solid')
ExitButton.grid(row=3, column=2, columnspan = 2, sticky = E)

#Keeping the Window Open and Protocals for Closing
GUI.protocol("WM_DELETE_WINDOW", Exit_Program)
GUI.mainloop()
