#!/usr/bin/env python3

#Imported Libraries for Background Processing
import os
from tkinter import *
import tkinter as tk
import subprocess
import pandas
import csv

#Setup the GUI Window
GUI = Tk()

GUI.grid_rowconfigure(0, minsize=25)
GUI.grid_rowconfigure(1, minsize=5)
GUI.grid_rowconfigure(4, minsize=5)

GUI.grid_columnconfigure(0, minsize=10)
GUI.grid_columnconfigure(4, minsize=10)
GUI.configure(background='black')
GUI.title('Flow Bench User Interface Setup')

GUIF = Frame(GUI, height=1, bg='black')
GUIF.grid(row=1, column=2, sticky=W)

GUIFI = Frame(GUI, height=1, bg='black')
GUIFI.grid(row=2, column=2)
GUIFI.grid_columnconfigure(0, minsize=2)
GUIFI.grid_columnconfigure(1, minsize=2)

GUIFII = Frame(GUI, height=1, bg='black')
GUIFII.grid(row=3, column=2, sticky = W)
GUIFII.grid_columnconfigure(0, minsize=2)
GUIFII.grid_columnconfigure(1, minsize=15)
GUIFII.grid_columnconfigure(2, minsize=30)
GUIFII.grid_columnconfigure(3, minsize=30)
GUIFII.grid_columnconfigure(4, minsize=2)

#Read setup data and display on the GUI window
confirmationI = tk.DoubleVar()
confirmationII = tk.DoubleVar()
confirmationIII = tk.DoubleVar()

data = pandas.read_csv(r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/Z1_BENCH_CONFIGURATION.txt", header=None)

dataI = ((data.loc[0:0,[0]]))
dataI = dataI.to_string(index=False, header=None)

dataII = ((data.loc[1:1,[0]]))
dataII = dataII.to_string(index=False, header=None)

dataIII = ((data.loc[2:2,[0]]))
dataIII = dataIII.to_string(index=False, header=None)

dataIIII = ((data.loc[3:3,[0]]))
dataIIII = dataIIII.to_string(index=False, header=None)

df = pandas.DataFrame({'A':[0,1,2,3],'B':[0,1,2,3],'C':[0,1,2,3]})

if dataIIII == '1':
    df=df.replace({'A':{0:'- Manual Control               '}})
    df=df.replace({'A':{2:'    * physical input/output    '}})
    df=df.replace({'A':{3:'    * slider input/output      '}})    
elif dataIIII == '2':
    df=df.replace({'A':{0:'- Automated Control            '}})
    df=df.replace({'A':{2:'    * ramp function            '}})
    df=df.replace({'A':{3:'    * timed input/output       '}})
elif dataIIII == '3':
    df=df.replace({'A':{0:'- Automated Control            '}})
    df=df.replace({'A':{2:'    * step function            '}})
    df=df.replace({'A':{3:'    * timed input/output       '}})
elif dataIIII == '4':
    df=df.replace({'A':{0:'- Automated Control            '}})
    df=df.replace({'A':{2:'    * user equation            '}})
    df=df.replace({'A':{3:'    * timed input/output       '}})
    
if dataI == '1':
    df=df.replace({'A':{1:'    * pressure dependent       '}})
elif dataI == '2':
    df=df.replace({'A':{1:'    * flow dependent           '}})
    
if dataII == '1':
    df=df.replace({'B':{0:'- Flow Meter                   '}})
    df=df.replace({'B':{1:'    * scale: 0.00-0.01 kg/hr   '}})
    df=df.replace({'B':{2:'    * accuracy: +/- 0.2 kg/hr  '}})
    df=df.replace({'B':{3:'    * resolution: 0.3 kg/hr    '}})
elif dataII == '2':
    df=df.replace({'B':{0:'- Flow Meter                   '}})
    df=df.replace({'B':{1:'    * scale: 0.01-0.15 kg/hr   '}})
    df=df.replace({'B':{2:'    * accuracy: +/- 0.2 kg/hr  '}})
    df=df.replace({'B':{3:'    * resolution: 0.3 kg/hr    '}})
elif dataII == '3':
    df=df.replace({'B':{0:'- Flow Meter                   '}})
    df=df.replace({'B':{1:'    * scale: 0.15-2.00 kg/hr   '}})
    df=df.replace({'B':{2:'    * accuracy: +/- 0.2 kg/hr  '}})
    df=df.replace({'B':{3:'    * resolution: 0.3 kg/hr    '}})
elif dataII == '4':
    df=df.replace({'B':{0:'- Flow Meter                   '}})
    df=df.replace({'B':{1:'    * scale: 2.00-4.00 kg/hr   '}})
    df=df.replace({'B':{2:'    * accuracy: +/- 0.2 kg/hr  '}})
    df=df.replace({'B':{3:'    * resolution: 0.3 kg/hr    '}})
elif dataII == '5':
    df=df.replace({'B':{0:'- Flow Meter                   '}})
    df=df.replace({'B':{1:'    * scale: 4-50.00 kg/hr     '}})
    df=df.replace({'B':{2:'    * accuracy: +/- 0.2 kg/hr  '}})
    df=df.replace({'B':{3:'    * resolution: 0.3 kg/hr    '}})
elif dataII == '6':
    df=df.replace({'B':{0:'- Flow Meter                   '}})
    df=df.replace({'B':{1:'    * scale: 50.00-612.00 kg/hr'}})
    df=df.replace({'B':{2:'    * accuracy: +/- 0.2 kg/hr  '}})
    df=df.replace({'B':{3:'    * resolution: 0.3 kg/hr    '}})
    
if dataIII == '1':
    df=df.replace({'C':{0:'- Pressure Transducer          '}})
    df=df.replace({'C':{1:'    * scale: 0.00-5.00 Bar     '}})
    df=df.replace({'C':{2:'    * accuracy: +/- 0.01 Bar   '}})
    df=df.replace({'C':{3:'    * resolution: 0.10 Bar     '}})
elif dataIII == '2':
    df=df.replace({'C':{0:'- Pressure Transducer          '}})
    df=df.replace({'C':{1:'    * scale: 0.00-10.00 Bar    '}})
    df=df.replace({'C':{2:'    * accuracy: +/- 0.1 Bar    '}})
    df=df.replace({'C':{3:'    * resolution: 0.5 Bar      '}})
elif dataIII == '3':
    df=df.replace({'C':{0:'- Pressure Transducer          '}})
    df=df.replace({'C':{1:'    * scale: 1.00 Bar differn. '}})
    df=df.replace({'C':{2:'    * accuracy: +/- 0.01 Bar   '}})
    df=df.replace({'C':{3:'    * resolution: 0.005 Bar    '}})

one=((df.loc[0:3,['A']])).to_csv(index=False, header=False)
two=((df.loc[0:3,['B']])).to_csv(index=False, header=False)
three=((df.loc[0:3,['C']])).to_csv(index=False, header=False)


        
confirmationI.set(one)
confirmationII.set(two)
confirmationIII.set(three)

#Setup Callable Functions
    #Function to launch ramp program
def Manual():
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench/04_A_Pressure_Control_Ramp.py"])
    sys.exit()
    #Function to launch step program
def Ramp():
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench/04_B_Pressure_Control_Step.py"]) 
    sys.exit()
    #Function to launch step program
def Step():
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench/04_B_Pressure_Control_Step.py"]) 
    sys.exit()    
    #Function to launch step program
def Equation():
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench/04_B_Pressure_Control_Step.py"]) 
    sys.exit()        
    #Function to proceed with setup
def Forward():
    if dataIIII == '1' and dataI == '1':
        subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/05_0_Manual_Pressure_Input.py"]) 
        sys.exit() 
    elif dataIIII == '1' and dataI =='2':
        subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/05_0_Manual_Flow_Input.py"]) 
        sys.exit()
    
    elif dataIIII == '2' and dataI == '1':
        subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/05_1_Automated_Pressure_Ramp.py"]) 
        sys.exit()
    elif dataIIII == '2' and dataI == '2':
        subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/05_1_Automated_Flow_Ramp.py"]) 
        sys.exit()
    
    elif dataIIII == '3' and dataI == '1':
        subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/05_2_Automated_Pressure_Step.py"]) 
        sys.exit()
    elif dataIIII == '3' and dataI == '2':
        subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/05_2_Automated_Flow_Step.py"]) 
        sys.exit()
        
    elif dataIIII == '4' and dataI == '1':
        subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/05_3_Automated_Pressure_Equation.py"]) 
        sys.exit()
    elif dataIIII == '4' and dataI == '2':
        subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/05_3_Automated_Flow_Equation.py"]) 
        sys.exit()
        
    #Function to return to the previous setup window
def Back():
    file_object = open("Z1_BENCH_CONFIGURATION.txt", "r")
    lines = file_object.readlines()
    lines = lines[:-1]
    lines = [x.strip('\n') for x in lines]

    with open("Z1_BENCH_CONFIGURATION.txt","w") as file_object:
                    writer = csv.writer(file_object)
                    for line in lines:
                        writer.writerow([line])
                    file_object.close()
        
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/03_0_Automated_Manual.py"]) 
    sys.exit()
    #Function to end program selection window
def Exit_Program():
    print("Exit Button pressed")
    file_object=open("Z1_BENCH_CONFIGURATION.txt","w")
    file_object.close()
    sys.exit()
    
    
#Buttons and Labels
    #Headers/titles - LABELS
Header = Label(GUI, text="Flow Bench User Interface - System Setup (4/4)", background='black', font = 'Helvetica 14 bold underline bold', fg='dark goldenrod')
Header.grid(row=0, column=2)
    #Settup Details - LABELS
HeaderI = Label(GUIF, text="Confirmation of flow bench settings:", anchor=NW, justify=LEFT, background='black', font = 'Helvetica 11 bold underline',fg='dark goldenrod', highlightthickness=1, highlightbackground='black')
HeaderI.grid(row=0, column=0, sticky=W)

ConfirmationI_Label = Label(GUIFI, height=5, width=30, textvariable=confirmationI, anchor=NW, justify=LEFT, background='black', font = 'Helvetica 8 bold',fg='dark goldenrod', highlightthickness=1, highlightbackground='black')
ConfirmationI_Label.grid(row=1, column=1, sticky=W, padx=15)
ConfirmationII_Label = Label(GUIFI, height=5, width=30, textvariable=confirmationII, anchor=NW, justify=LEFT, background='black', font = 'Helvetica 8 bold',fg='dark goldenrod', highlightthickness=1, highlightbackground='black')
ConfirmationII_Label.grid(row=1, column=2, sticky=W)
ConfirmationIII_Label = Label(GUIFI, height=5, width=27, textvariable=confirmationIII, anchor=NW, justify=LEFT, background='black', font = 'Helvetica 8 bold',fg='dark goldenrod', highlightthickness=1, highlightbackground='black')
ConfirmationIII_Label.grid(row=1, column=3, sticky=W)
    #Program Forward - BUTTON COMMAND
ForwardButton = tk.Button(GUIFII, text="Next Screen",command=Forward, background='steel blue', width =12, font = 'Helvetica 8 bold', highlightbackground='gray82', activebackground='royal blue', borderwidth=.5, relief='solid')
ForwardButton.grid(row=3, column=2, sticky = E)
    #Program Back - BUTTON COMMAND
BackButton = tk.Button(GUIFII, text="Previous Screen",command=Back, background='steel blue', width =12, font = 'Helvetica 8 bold', highlightbackground='gray82', activebackground='royal blue', borderwidth=.5, relief='solid')
BackButton.grid(row=3, column=0, sticky = W)
    #Program Exit - BUTTON COMMAND
ExitButton = tk.Button(GUI, text="EXIT NOW",command=Exit_Program, background='orangered4', width =10, font = 'Helvetica 8 bold', highlightbackground='yellow', activebackground='orangered3', borderwidth=.5, relief='solid')
ExitButton.grid(row=3, column=2, columnspan = 2, sticky = E)

#Keeping the Window Open and Protocals for Closing
GUI.protocol("WM_DELETE_WINDOW", Exit_Program)
GUI.mainloop()
