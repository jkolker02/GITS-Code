from tkinter import *
from tkinter.font import Font
from datetime import date
from decimal import*
import tkinter as tk
from daqhats_utils import select_hat_device, enum_mask_to_string, chan_list_to_mask
from daqhats import mcc118, mcc152, OptionFlags, HatIDs, HatError
import pandas as pd
import numpy as np
import csv
import os
import subprocess
import shutil
import time

address2 = select_hat_device(HatIDs.MCC_152)
hat2 = mcc152(address2)
options2 = OptionFlags.DEFAULT
info2 = mcc152.info().NUM_AO_CHANNELS

running = True

hat2.dio_output_write_bit(5,1)
hat2.dio_output_write_bit(1,0)
hat2.dio_output_write_bit(2,0)
hat2.dio_output_write_bit(3,0)
hat2.dio_output_write_bit(4,0)

t= 0.001
i=0
d=800

def stepper_f():
    global i, d
    
    while running is True and i<=d:
        hat2.dio_output_write_bit(1,1)
        hat2.dio_output_write_bit(4,1)
        time.sleep(float(t))
        
        hat2.dio_output_write_bit(4,0)
        hat2.dio_output_write_bit(2,1)
        time.sleep(float(t))
        
        
        hat2.dio_output_write_bit(1,0)
        hat2.dio_output_write_bit(3,1)
        time.sleep(float(t))
        
        hat2.dio_output_write_bit(2,0)
        hat2.dio_output_write_bit(4,1)
        time.sleep(float(t))
        
        hat2.dio_output_write_bit(3,0)
        
        i+=1
        
        print(i)
        
    hat2.dio_output_write_bit(4,0)
    i = 0
    
def stepper_h():
    global i, d
    
    while running is True and i<=d:
        hat2.dio_output_write_bit(1,1)
        time.sleep(float(t))
        
        hat2.dio_output_write_bit(4,0)
        time.sleep(float(t))
        
        hat2.dio_output_write_bit(2,1)
        time.sleep(float(t))
        
        hat2.dio_output_write_bit(1,0)
        time.sleep(float(t))
        
        hat2.dio_output_write_bit(3,1)
        time.sleep(float(t))
        
        hat2.dio_output_write_bit(2,0)
        time.sleep(float(t))
        
        hat2.dio_output_write_bit(4,1)
        time.sleep(float(t))
        
        hat2.dio_output_write_bit(3,0)
        time.sleep(float(t))
        
        i+=1
        
        print(i)
        
    hat2.dio_output_write_bit(4,0)
    i = 0  
    