#!/usr/bin/env python3

#---------Imports
import os
import csv
import time
import math
import pandas
import random
import threading
import subprocess
import tkinter as tk
from tkinter import *
from time import sleep
from sys import stdout
from decimal import Decimal
import tkinter.simpledialog as tkSimpleDialog
from daqhats_utils import select_hat_device, enum_mask_to_string, chan_list_to_mask
from daqhats import mcc118, mcc152, OptionFlags, HatIDs, HatError
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.animation as animation
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
#---------End of imports


data = pandas.read_csv(r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/Z1_BENCH_CONFIGURATION.txt", header=None)

dataII = ((data.loc[1:1,[0]]))
dataII = dataII.to_string(index=False, header=None)

dataIII = ((data.loc[2:2,[0]]))
dataIII = dataIII.to_string(index=False, header=None)

color_list=['red','yellow','blue','green','pink','orange','white','brown','purple','spring green', 'red4','plum4','gold3','honeydew2','light sea green','cornflower blue',\
            'thistle1','papaya whip', 'turquoise1','OliveDrab1']

    
if dataII == '1':
    FM_max = 0.0100
    FM_min = 0.0000
    FM_tick = round((FM_max-FM_min)/20,4)
    FM0,FM1,FM2,FM3,FM4,FM5,FM6,FM7,FM8,FM9,FM10,FM11,FM12,FM13,FM14,FM15,FM16,FM17,FM18,FM19,FM20 = \
    round(FM_min,4),round(FM_tick*1+FM_min,4),round(FM_tick*2+FM_min,4),round(FM_tick*3+FM_min,4),round(FM_tick*4+FM_min,4),round(FM_tick*5+FM_min,4),round(FM_tick*6+FM_min,4),\
    round(FM_tick*7+FM_min,4),round(FM_tick*8+FM_min,4),round(FM_tick*9+FM_min,4),round(FM_tick*10+FM_min,4),round(FM_tick*11+FM_min,4),round(FM_tick*12+FM_min,4),round(FM_tick*13+FM_min,4),\
    round(FM_tick*14+FM_min,4),round(FM_tick*15+FM_min,4),round(FM_tick*16+FM_min,4),round(FM_tick*17+FM_min,4),round(FM_tick*18+FM_min,4),round(FM_tick*19+FM_min,4),round(FM_tick*20+FM_min,4)
    FM_Cal = FM_max/5
    
elif dataII == '2':    
    FM_max = 0.1500
    FM_min = 0.0000
    #FM_min = 0.0100
    FM_tick = round((FM_max-FM_min)/20,4)
    FM0,FM1,FM2,FM3,FM4,FM5,FM6,FM7,FM8,FM9,FM10,FM11,FM12,FM13,FM14,FM15,FM16,FM17,FM18,FM19,FM20 = \
    round(FM_min,4),round(FM_tick*1+FM_min,4),round(FM_tick*2+FM_min,4),round(FM_tick*3+FM_min,4),round(FM_tick*4+FM_min,4),round(FM_tick*5+FM_min,4),round(FM_tick*6+FM_min,4),\
    round(FM_tick*7+FM_min,4),round(FM_tick*8+FM_min,4),round(FM_tick*9+FM_min,4),round(FM_tick*10+FM_min,4),round(FM_tick*11+FM_min,4),round(FM_tick*12+FM_min,4),round(FM_tick*13+FM_min,4),\
    round(FM_tick*14+FM_min,4),round(FM_tick*15+FM_min,4),round(FM_tick*16+FM_min,4),round(FM_tick*17+FM_min,4),round(FM_tick*18+FM_min,4),round(FM_tick*19+FM_min,4),round(FM_tick*20+FM_min,4)
    FM_Cal = FM_max/5
    
elif dataII == '3':
    FM_max = 2.0000
    FM_min = 0.0000
    #FM_min = 0.1500
    FM_tick = round((FM_max-FM_min)/20,4)
    FM0,FM1,FM2,FM3,FM4,FM5,FM6,FM7,FM8,FM9,FM10,FM11,FM12,FM13,FM14,FM15,FM16,FM17,FM18,FM19,FM20 = \
    round(FM_min,4),round(FM_tick*1+FM_min,4),round(FM_tick*2+FM_min,4),round(FM_tick*3+FM_min,4),round(FM_tick*4+FM_min,4),round(FM_tick*5+FM_min,4),round(FM_tick*6+FM_min,4),\
    round(FM_tick*7+FM_min,4),round(FM_tick*8+FM_min,4),round(FM_tick*9+FM_min,4),round(FM_tick*10+FM_min,4),round(FM_tick*11+FM_min,4),round(FM_tick*12+FM_min,4),round(FM_tick*13+FM_min,4),\
    round(FM_tick*14+FM_min,4),round(FM_tick*15+FM_min,4),round(FM_tick*16+FM_min,4),round(FM_tick*17+FM_min,4),round(FM_tick*18+FM_min,4),round(FM_tick*19+FM_min,4),round(FM_tick*20+FM_min,4)
    FM_Cal = FM_max/5
    
elif dataII == '4':
    FM_max = 4.0000
    FM_min = 0.0000
    #FM_min = 2.0000
    FM_tick = round((FM_max-FM_min)/20,4)
    FM0,FM1,FM2,FM3,FM4,FM5,FM6,FM7,FM8,FM9,FM10,FM11,FM12,FM13,FM14,FM15,FM16,FM17,FM18,FM19,FM20 = \
    round(FM_min,4),round(FM_tick*1+FM_min,4),round(FM_tick*2+FM_min,4),round(FM_tick*3+FM_min,4),round(FM_tick*4+FM_min,4),round(FM_tick*5+FM_min,4),round(FM_tick*6+FM_min,4),\
    round(FM_tick*7+FM_min,4),round(FM_tick*8+FM_min,4),round(FM_tick*9+FM_min,4),round(FM_tick*10+FM_min,4),round(FM_tick*11+FM_min,4),round(FM_tick*12+FM_min,4),round(FM_tick*13+FM_min,4),\
    round(FM_tick*14+FM_min,4),round(FM_tick*15+FM_min,4),round(FM_tick*16+FM_min,4),round(FM_tick*17+FM_min,4),round(FM_tick*18+FM_min,4),round(FM_tick*19+FM_min,4),round(FM_tick*20+FM_min,4)
    FM_Cal = FM_max/5
    
elif dataII == '5':
    FM_max = 50.0000
    FM_min = 0.0000
    #FM_min = 4.0000
    FM_tick = round((FM_max-FM_min)/20,4)
    FM0,FM1,FM2,FM3,FM4,FM5,FM6,FM7,FM8,FM9,FM10,FM11,FM12,FM13,FM14,FM15,FM16,FM17,FM18,FM19,FM20 = \
    round(FM_min,4),round(FM_tick*1+FM_min,4),round(FM_tick*2+FM_min,4),round(FM_tick*3+FM_min,4),round(FM_tick*4+FM_min,4),round(FM_tick*5+FM_min,4),round(FM_tick*6+FM_min,4),\
    round(FM_tick*7+FM_min,4),round(FM_tick*8+FM_min,4),round(FM_tick*9+FM_min,4),round(FM_tick*10+FM_min,4),round(FM_tick*11+FM_min,4),round(FM_tick*12+FM_min,4),round(FM_tick*13+FM_min,4),\
    round(FM_tick*14+FM_min,4),round(FM_tick*15+FM_min,4),round(FM_tick*16+FM_min,4),round(FM_tick*17+FM_min,4),round(FM_tick*18+FM_min,4),round(FM_tick*19+FM_min,4),round(FM_tick*20+FM_min,4)
    FM_Cal = FM_max/5
    
elif dataII == '6':
    FM_max = 612.0000
    FM_min = 0.0000
    #FM_min = 50.0000
    FM_tick = round((FM_max-FM_min)/20,4)
    FM0,FM1,FM2,FM3,FM4,FM5,FM6,FM7,FM8,FM9,FM10,FM11,FM12,FM13,FM14,FM15,FM16,FM17,FM18,FM19,FM20 = \
    round(FM_min,4),round(FM_tick*1+FM_min,4),round(FM_tick*2+FM_min,4),round(FM_tick*3+FM_min,4),round(FM_tick*4+FM_min,4),round(FM_tick*5+FM_min,4),round(FM_tick*6+FM_min,4),\
    round(FM_tick*7+FM_min,4),round(FM_tick*8+FM_min,4),round(FM_tick*9+FM_min,4),round(FM_tick*10+FM_min,4),round(FM_tick*11+FM_min,4),round(FM_tick*12+FM_min,4),round(FM_tick*13+FM_min,4),\
    round(FM_tick*14+FM_min,4),round(FM_tick*15+FM_min,4),round(FM_tick*16+FM_min,4),round(FM_tick*17+FM_min,4),round(FM_tick*18+FM_min,4),round(FM_tick*19+FM_min,4),round(FM_tick*20+FM_min,4)
    FM_Cal = FM_max/5
    
    
if dataIII == '1':
    PT_max = 5
    PT_min = 0
    PT_tick = round((PT_max-PT_min)/20,4)
    PT0,PT1,PT2,PT3,PT4,PT5,PT6,PT7,PT8,PT9,PT10,PT11,PT12,PT13,PT14,PT15,PT16,PT17,PT18,PT19,PT20 = \
    round(PT_min,4),round(PT_tick*1+PT_min,4),round(PT_tick*2+PT_min,4),round(PT_tick*3+PT_min,4),round(PT_tick*4+PT_min,4),round(PT_tick*5+PT_min,4),round(PT_tick*6+PT_min,4),\
    round(PT_tick*7+PT_min,4),round(PT_tick*8+PT_min,4),round(PT_tick*9+PT_min,4),round(PT_tick*10+PT_min,4),round(PT_tick*11+PT_min,4),round(PT_tick*12+PT_min,4),\
    round(PT_tick*13+PT_min,4),round(PT_tick*14+PT_min,4),round(PT_tick*15+PT_min,4),round(PT_tick*16+PT_min,4),round(PT_tick*17+PT_min,4),round(PT_tick*18+PT_min,4),\
    round(PT_tick*19+PT_min,4),round(PT_tick*20+PT_min,4)
    PT_Cal = PT_max/10
    
elif dataIII == '2':
    PT_max = 10
    PT_min = 0
    PT_tick = round((PT_max-PT_min)/20,4)
    PT0,PT1,PT2,PT3,PT4,PT5,PT6,PT7,PT8,PT9,PT10,PT11,PT12,PT13,PT14,PT15,PT16,PT17,PT18,PT19,PT20 = \
    round(PT_min,4),round(PT_tick*1+PT_min,4),round(PT_tick*2+PT_min,4),round(PT_tick*3+PT_min,4),round(PT_tick*4+PT_min,4),round(PT_tick*5+PT_min,4),round(PT_tick*6+PT_min,4),\
    round(PT_tick*7+PT_min,4),round(PT_tick*8+PT_min,4),round(PT_tick*9+PT_min,4),round(PT_tick*10+PT_min,4),round(PT_tick*11+PT_min,4),round(PT_tick*12+PT_min,4),\
    round(PT_tick*13+PT_min,4),round(PT_tick*14+PT_min,4),round(PT_tick*15+PT_min,4),round(PT_tick*16+PT_min,4),round(PT_tick*17+PT_min,4),round(PT_tick*18+PT_min,4),\
    round(PT_tick*19+PT_min,4),round(PT_tick*20+PT_min,4)
    PT_Cal = PT_max/10
    
elif dataIII == '3':
    PT_max = 1
    PT_min = 0
    PT_tick = round((PT_max-PT_min)/20,4)
    PT0,PT1,PT2,PT3,PT4,PT5,PT6,PT7,PT8,PT9,PT10,PT11,PT12,PT13,PT14,PT15,PT16,PT17,PT18,PT19,PT20 = \
    round(PT_min,4),round(PT_tick*1+PT_min,4),round(PT_tick*2+PT_min,4),round(PT_tick*3+PT_min,4),round(PT_tick*4+PT_min,4),round(PT_tick*5+PT_min,4),round(PT_tick*6+PT_min,4),\
    round(PT_tick*7+PT_min,4),round(PT_tick*8+PT_min,4),round(PT_tick*9+PT_min,4),round(PT_tick*10+PT_min,4),round(PT_tick*11+PT_min,4),round(PT_tick*12+PT_min,4),\
    round(PT_tick*13+PT_min,4),round(PT_tick*14+PT_min,4),round(PT_tick*15+PT_min,4),round(PT_tick*16+PT_min,4),round(PT_tick*17+PT_min,4),round(PT_tick*18+PT_min,4),\
    round(PT_tick*19+PT_min,4),round(PT_tick*20+PT_min,4)
    PT_Cal = PT_max/10
    


fig = plt.Figure(figsize=(16,5), dpi=50, edgecolor='dimgray', linewidth=3)
str = str ('1,3')
list=str.split(",")
li=[]
for i in list:
    li.append(int(i))
channels = li
channel_mask = chan_list_to_mask(channels)
num_channels = len(channels)
samples_per_channel = 600
scan_rate = 10
options = OptionFlags.DEFAULT
address = select_hat_device(HatIDs.MCC_118)
hat1 = mcc118(address)
hat1.a_in_scan_stop()
actual_scan_rate = hat1.a_in_scan_actual_rate(num_channels, scan_rate)
dummy_clock=time.time()
file_object=open("06_Plot_Feedback.txt","w")
file_object.close()
stdout.flush()
dataloop = True
record = False
hat1.a_in_scan_stop()
hat1.a_in_scan_cleanup()
x=0
y1=0
y2=0

Name_Input ="over_flow"

def data_read():
    global dataloop
    global Name_Input
    
    
        
    def read_and_display_data(hat1, samples_per_channel, num_channels):
        global dummy_clock
        global scan_rate
        global channel_mask, scan_rate,options
        global dataloop
        global color_list
        
        
        total_samples_read = 0
        samples_per_channel_read= 1
        timeout = 1/scan_rate
        dataloop = False       
    
        if os.stat('06_Plot_Feedback.txt').st_size == 0:
            print('empty')
        else:
            pandas.set_option('display.max_colwidth',-1)
            df = pandas.read_csv('06_Plot_Feedback.txt', sep=',', header=None)
            df = pandas.DataFrame(df)
            df_len = len(df)
            df = ((df.loc[df_len-300:df_len,0:]))
            outfile = open('06_Plot_Feedback.txt','wb')
            df.to_csv('06_Plot_Feedback.txt', header=False, index=False)
            outfile.close()
            
            
        while total_samples_read < samples_per_channel:
            read_result = hat1.a_in_scan_read(samples_per_channel_read, timeout)
            ts= time.time()-dummy_clock
            samples_read_per_channel = int(len(read_result.data) / num_channels)
            total_samples_read += samples_read_per_channel
                      
            if samples_read_per_channel > 0:
                index = (samples_read_per_channel * num_channels) - num_channels
                data=read_result.data
                data.insert(0,ts)
                with open("06_Plot_Feedback.txt","a") as file_object:
                    writer = csv.writer(file_object)
                    writer.writerow(data)
                    
                if record is True:
                    data_name ="/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/LogFiles/"+Name_Input+".txt"
                    with open(data_name,"a") as data_object:
                        writer = csv.writer(data_object)
                        writer.writerow(data)
            else:
                hat1.a_in_scan_stop()
                hat1.a_in_scan_cleanup()
                hat1.a_in_scan_start(channel_mask, samples_per_channel, scan_rate,options)
                
                
                    
        hat1.a_in_scan_stop()
        hat1.a_in_scan_cleanup()
        stdout.flush()
        dataloop = True
        
                
    t = threading.Thread(target=read_and_display_data, args=(hat1, samples_per_channel, num_channels,), daemon = True)
    t.start()


def animate(i):
    global x, y1, y2, FM_Cal, PT_Cal
    if os.stat('06_Plot_Feedback.txt').st_size == 0:
        x=[1,1]
        y1=[1,1]
        y2=[1,1]
        
    else:
        pandas.set_option('display.max_colwidth',-1)
        df = pandas.read_csv('06_Plot_Feedback.txt', sep=',', header=None)
        df = pandas.DataFrame(df)
        df_len = len(df)
        df_count = len(df.columns)            
        
        if df_count == 3:
            if df_len < 150:
                
                x = ((df.loc[1:df_len,[0]]))
                x = (x[0]).tolist()
                
                y1 = ((df.loc[1:df_len,[1]]))
                y1 = y1*PT_Cal
                y1 = (y1[1]).tolist()
                
                y2 = ((df.loc[1:df_len,[2]]))
                y2 =(y2-1)*FM_Cal
                y2 = (y2[2]).tolist()
                
            elif df_len > 150:
                
                x = ((df.loc[df_len-150:df_len,[0]]))
                x = (x[0]).tolist()

                y1 = ((df.loc[df_len-150:df_len,[1]]))
                y1 = y1*PT_Cal
                y1 = (y1[1]).tolist()
                
                y2 = ((df.loc[df_len-150:df_len,[2]]))
                y2 = (y2-1)*FM_Cal
                y2 = (y2[2]).tolist()
    
    #print(x,y1,y2)
    ax.axes.set_xlim(min(x),max(x)+1)
    ax.axes.set_ylim(min(y1)-.05,max(y1)+.05)
    ax2.axes.set_ylim(min(y2)-.05,max(y2)+.05)
    line.set_xdata(x)
    line.set_ydata(y1)  # update the data
    line2.set_xdata(x)
    line2.set_ydata(y2)
    return line,line2

#Setup the GUI Window
GUI = tk.Tk()
GUI.grid_rowconfigure(0, minsize=25)
GUI.grid_rowconfigure(1, minsize=270)
GUI.grid_columnconfigure(0, minsize=10)
GUI.grid_columnconfigure(1, minsize=75)
GUI.grid_columnconfigure(2, minsize=10)
GUI.configure(background='black')
GUI.title('Automated Equation Module - Flow Dependent')

GUIF = Frame(GUI, bg='black')
GUIF.grid(row=4, column=1)
GUIF.grid_columnconfigure(0, minsize=1)
GUIF.grid_columnconfigure(1, minsize=115)
GUIF.grid_columnconfigure(2, minsize=40)
GUIF.grid_columnconfigure(3, minsize=70)
GUIF.grid_columnconfigure(4, minsize=30)
GUIF.grid_columnconfigure(5, minsize=10)
GUIF.grid_columnconfigure(6, minsize=310)
GUIF.grid_columnconfigure(7, minsize=50)

GUIFI = Frame(GUI, bg='black')
GUIFI.grid(row=5, column=1)
GUIFI.grid_rowconfigure(0, minsize=5)
GUIFI.grid_rowconfigure(2, minsize=5)
GUIFI.grid_columnconfigure(0, minsize=3)
GUIFI.grid_columnconfigure(1, minsize=100)
GUIFI.grid_columnconfigure(2, minsize=100)
GUIFI.grid_columnconfigure(3, minsize=75)
GUIFI.grid_columnconfigure(4, minsize=122)
GUIFI.grid_columnconfigure(5, minsize=122)
GUIFI.grid_columnconfigure(6, minsize=75)
GUIFI.grid_columnconfigure(7, minsize=100)
GUIFI.grid_columnconfigure(8, minsize=100)
GUIFI.grid_columnconfigure(9, minsize=3)



#initial output state on start-up
running = False
value_convert = None
value = 0
Rec_Var = tk.StringVar()
Rec_Var.set("Select to Record")


start_flow = -1
end_flow = 0
equ_profile = None
time_o = 0
time_f = 0
t=0

y_output = 0
valueII = 0
x_output = 0
m = 0
var = StringVar()
varII = StringVar()
var.set("Current Flow Command Set At: %s" % value + " kg/h")
varII.set("Program Time Elapsed: %s" % valueII + " sec")


#Obtain the Board Information
address2 = select_hat_device(HatIDs.MCC_152)
hat2 = mcc152(address2)
options2 = OptionFlags.DEFAULT
info2 = mcc152.info().NUM_AO_CHANNELS
channel2 = 0
hat2.a_out_write(channel=channel2,value=0,options=options)

#Function to define the desired custom cycles
def eqation_profile_func():
    global equ, equ_ret, eqation_profile, equ_profile
           
    equ_profile = equ.get()
    
    
    
    if equ_ret is not None:
            equ_ret.destroy()
           
    equ_ret = Label(GUIF, text="Equation Profile Set to: ''Flow Output'' = %s" % equ_profile, background='black', font = 'Helvetica 7 bold', fg='dark goldenrod', activebackground='gray20', activeforeground = 'dark goldenrod')
    equ_ret.grid(row=1, column=0, columnspan=9, sticky=W)
     
    equ.delete(0,'end')

    
#Function to start program output      
def start_program_func():
    global running
        
    running = True
    
    #Function to control programed output
    def scan_func():
        global equ_profile, start_flow, end_flow, running, channel2, value, valueII, value_convert
        global current_output, var, varII, x_output, time_f, time_o, t, y_output
        
        y = float(eval('2+math.sin(3.2*t)'))
        
        time_o = Decimal(time.time())
        y_output = (float(eval(equ_profile)))
        print(y_output)
        while running is True:
            
            if y_output <= FM_max:
                t=float(x_output)
                y_output = (float(eval(equ_profile)))
                value_convert = Decimal(y_output)*Decimal(1.0)
                hat2.a_out_write(channel=channel2,value=value_convert,options=options)
                time.sleep(float(.10))
                valueII = round(x_output,3)
                value = round(y_output,3)
                var.set("Current Flow Command Set At: %s" % value + " kg/h")
                varII.set("Program Time Elapsed: %s" % valueII + " sec")
                time_f = Decimal(time.time())
                x_output = ((time_f-time_o))
            
            else:
                
                print("exceeds max/min of output")
                print(y_output)
                print(FM_max)
            
                    
                    
                
    t_equ = threading.Thread(target=scan_func, daemon=True)
    t_equ.start()
    

#Function to end program output
def stop_program_func():
    global running, var, varII, value, valueII
    
    running = False
    var.set("Current Flow Command Set At: %s" % value + " kg/h")
    varII.set("Program Time Elapsed: %s" % valueII + " sec")


#Function to define the end flow
def end_func():
    global end_ret, end_flow
        
    if end_ret is not None:
        end_ret.destroy()
        
    end_flow = Decimal(end.get())
    
    
    end_ret = Label(GUIF, text="End Flow Magnitude Set to: %s" % end_flow + "kg/h", background='black', font = 'Helvetica 7 bold', fg='dark goldenrod', activebackground='gray20', activeforeground = 'dark goldenrod')
    end_ret.grid(row=4, columnspan=2, sticky=W)
     
    end.delete(0,'end')

#Function to define the start flow
def start_func():
    global start_ret, start_flow
        
    if start_ret is not None:
        start_ret.destroy()
        
    start_flow = Decimal(start.get())
    
    start_ret = Label(GUIF, text="Start Flow Magnitude Set to: %s" % start_flow + "kg/h", background='black', font = 'Helvetica 7 bold', fg='dark goldenrod', activebackground='gray20', activeforeground = 'dark goldenrod')
    start_ret.grid(row=1, columnspan=2, sticky=W)
     
    start.delete(0,'end')


#Return to system setup
def Back():
    file_object = open("Z1_BENCH_CONFIGURATION.txt", "r")
    lines = file_object.readlines()
    lines = lines[:-4]
    lines = [x.strip('\n') for x in lines]

    with open("Z1_BENCH_CONFIGURATION.txt","w") as file_object:
                    writer = csv.writer(file_object)
                    for line in lines:
                        writer.writerow([line])
                    file_object.close()
    
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/01_Pressure_Flow.py"]) 
    Exit_Program()    

#Function to continually loop plot and data
def Data_loop_func():
    global dataloop
        
    if dataloop == True:
        data_read()
        hat1.a_in_scan_start(channel_mask, samples_per_channel, scan_rate,options)
    GUI.after(450,Data_loop_func)
    
#Function to Record Pressure and Flow
def Record_func():
    global record, Name_Input, Rec_Var
    
    if record is False:
        Name_Input = tkSimpleDialog.askstring("Log File Name", "          ENTER A UNIQUE FILE NAME:       \n(eg. MAN_D15_10_Psi_Internal_Leakage)")
        print(Name_Input)
        if Name_Input is "":
            Name_Input = None
            print('none case')
        if Name_Input is not None:
            record = True
            Rec_Var.set("RECORDING!!!")
            print("im recording your data")
    else:
        record = False
        Rec_Var.set("Select to Record")
        RecordButton["background"] = ('orange')
        print("done recording")

def rec_color_func():
    global record
    
    if record is True:
        rec_color = random.choice(color_list)
        RecordButton["background"] = (rec_color)
        
    GUI.after(350,rec_color_func)


#Function to reset the output to zero
def reset_output_func():
    global channel2, options2, value_convert, options, value, valueII
    
    value=0
    valueII=0
    
    hat2.a_out_write(channel=channel2,value=0,options=options)
    var.set("Current Flow Command Set At: %s" % value + " kg/h")
    varII.set("Program Time Elapsed: %s" % valueII + " sec")
    running = False


#Function to exit the program    
def Exit_Program():
    global channel2, options2, value_convert, options
    
    
    hat2.a_out_write(channel=channel2,value=0,options=options)
    hat1.a_in_scan_stop()
    hat1.a_in_scan_cleanup()
    stdout.flush()
    
    running = False
    
    #NEED TO ADD SOME END CONDITIONS HERE!!!!    
    sys.exit()

    
#Buttons and Labels
    #Control headers/titles - LABELS
automated_control_header= Label(GUI, text="Automated Equation Settings - Flow Dependent - Timed Input/Output", background='black', font = 'Helvetica 14 bold underline bold', fg='dark goldenrod')
automated_control_header.grid(row=0, column=1)
 

    #Equation Time Buttons and Labels - LABEL ENTRY
eqation_profile= Label(GUIF, text="Equation Profile: ", background='black', font = 'Helvetica 7 bold', fg='dark goldenrod', activebackground='gray20', activeforeground = 'dark goldenrod')
eqation_profile.grid(row=0, column=0, columnspan=1, sticky=W)
eqation_profile = Button(GUIF, text='     Enter Equation Profile     ', command=eqation_profile_func, background='black', width=19, font = 'Helvetica 7 bold', fg='dark goldenrod', activebackground='gray20', activeforeground = 'dark goldenrod')
eqation_profile.grid(row=0, column=2, sticky=W)
equ = Entry(GUIF, background = 'gray70', width = 20, font = 'Helvetica 7')
equ.grid(row=0,column=1, sticky=W)
equ_ret = Label(GUIF, text="Equation Profile Set to:", background='black', font = 'Helvetica 7 bold', fg='dark goldenrod', activebackground='gray20', activeforeground = 'dark goldenrod')
equ_ret.grid(row=1, column=0, columnspan=9, sticky=W)
equ.bind('<KP_Enter>', (lambda event: eqation_profile_func()))
equ.bind('<Return>', (lambda event: eqation_profile_func()))


    #Display the current flow magnitude command signal in real time - LABEL ENTRY
current_output = Label(GUIF, textvariable=var, background='black', font = 'Helvetica 7 bold', fg='dark red', activebackground='gray20', activeforeground = 'dark goldenrod')
current_output.grid(row=3, column=0, columnspan=3, sticky=W)

    #Display the current time elapsed in real time - LABEL ENTRY
current_output = Label(GUIF, textvariable=varII, background='black', font = 'Helvetica 7 bold', fg='dark red', activebackground='gray20', activeforeground = 'dark goldenrod')
current_output.grid(row=4, column=0, columnspan=2, sticky=W)

    #Signal program start/stop - BUTTON COMMAND
Enable_Program_ch01 = Button(GUIFI, text='   Enable   \n   Program   ', command = start_program_func, background='black', width=17, font = 'Helvetica 7 bold', fg='dark goldenrod', activebackground='gray20', activeforeground = 'dark goldenrod')
Enable_Program_ch01.grid(row=1, column=4, sticky=W)
Disable_Program_ch01 = Button(GUIFI, text='   Disable   \n   Program   ', command = stop_program_func, background='black', width=17, font = 'Helvetica 7 bold', fg='dark goldenrod', activebackground='gray20', activeforeground = 'dark goldenrod')
Disable_Program_ch01.grid(row=1, column=5, sticky=W)



    #Program Exit - BUTTON COMMAND
ExitButton = tk.Button(GUIFI, text="EXIT NOW",command=Exit_Program, background='orangered4', width =13, font = 'Helvetica 7 bold', highlightbackground='yellow', activebackground='orangered3', borderwidth=.5, relief='solid')
ExitButton.grid(row=1, column=1, sticky=W)

    #Reset Flow - BUTTON COMMAND
ResetOutputButton = tk.Button(GUIFI, text="Reset Outputs",command=reset_output_func, background='RosyBrown4', width =14, font = 'Helvetica 7 bold', highlightbackground='gray82', activebackground='RosyBrown3', borderwidth=.5, relief='solid')
ResetOutputButton.grid(row=1, column=2)

    #Record Current Session
#ValveSync = tk.Button(GUIFI, textvariable=Sync_Var, command=Record_func, background='dark orange', width =12, font = 'Helvetica 7 bold', highlightbackground='gray82', activebackground='royal blue', borderwidth=.5, relief='solid')
#ValveSync.grid(row=1, column=6, sticky=E)    
        
    #Record Current Session
RecordButton = tk.Button(GUIFI, textvariable=Rec_Var, command=Record_func, background='orange', width =13, font = 'Helvetica 7 bold', highlightbackground='gray82', activebackground='royal blue', borderwidth=.5, relief='solid')
RecordButton.grid(row=1, column=7, sticky=E)

    #Return to Setup - BUTTON COMMAND
BackButton = tk.Button(GUIFI, text="Return to Setup",command=Back, background='steel blue', width =13, font = 'Helvetica 7 bold', highlightbackground='gray82', activebackground='royal blue', borderwidth=.5, relief='solid')
BackButton.grid(row=1, column=8, sticky=E)

    #Test to describe how the module works - LABEL ENTRY
help_dialog = Label(GUIF, text = "This module takes a user equation and executes it over time. The expression of the equation \n"
                                 "requires specific inputs that are based on constants, mathmatical operators, and variables \n"
                                 "expressed as 't' (i.e time). Mathmatical operators are specific to the python programing language\n"
                                 "and can be found online through various resources. An example equation: '0.5*math.sin(t/3)'\n"
                                 "illustrates a sine wave output with an amplitude of .5 and a period of 2/3 Pi. Important Note: it is\n"
                                 "possible to provide an expression that will result in values outside of the max/min working range\n"
                                 "of the bench. If this occures an error will be raised and the program will ended.", background='black', font = 'Helvetica 7 bold', justify=LEFT, fg='gray72', activebackground='gray20', activeforeground = 'dark goldenrod')
help_dialog.grid(row=0, rowspan=7, column=3, columnspan=7, sticky=W, ipadx=10)

#!!!!!!!!!!!!!!!!!!!!!!!!!!
canvas = FigureCanvasTkAgg(fig, GUI)
canvas.get_tk_widget().grid(column=1, row=1)
ax = fig.add_subplot(111)
ax.set_xlabel('Time (sec)', fontsize=13, fontweight='bold')
ax.set_ylabel('Pressure (psi)', fontsize=13, color = 'darkgreen', fontweight='bold')
line, = ax.plot(x,y1,'darkgreen')
ax2=ax.twinx()
ax2.set_ylabel('Flow (kg/h)', fontsize=13, color = 'midnightblue', fontweight='bold')
line2, = ax2.plot(y2, 'midnightblue')
fig.tight_layout(pad=1.5)
ani = animation.FuncAnimation(fig, animate, interval=750,blit=False)
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 

#Main loop with protocal
GUI.after(450,Data_loop_func)
GUI.after(350,rec_color_func)
GUI.protocol("WM_DELETE_WINDOW", Exit_Program)
tk.mainloop()


