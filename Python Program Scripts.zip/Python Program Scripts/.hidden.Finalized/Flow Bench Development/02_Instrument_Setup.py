#!/usr/bin/env python3

#Imported Libraries for Background Processing
from tkinter import *
import tkinter as tk
from tkinter import messagebox
import subprocess
import csv


#Setup the GUI Window
GUI = Tk()

GUI.grid_rowconfigure(0, minsize=25)
GUI.grid_rowconfigure(1, minsize=5)
GUI.grid_rowconfigure(3, minsize=35)
GUI.grid_rowconfigure(4, minsize=5)
GUI.grid_columnconfigure(0, minsize=10)
GUI.grid_columnconfigure(4, minsize=10)
GUI.configure(background='black')
GUI.title('Flow Bench User Interface Setup')

GUIF = Frame(GUI, bg='black', height=1)
GUIF.grid(row=1, column=2)

GUIFI = Frame(GUI, height=1, bg='black')
GUIFI.grid(row=2, column=2, pady=3)
GUIFI.grid_columnconfigure(1, minsize=10)

GUIFII = Frame(GUI, height=1, bg='black')
GUIFII.grid(row=3, column=2, sticky = W)
GUIFII.grid_columnconfigure(1, minsize=10)


#Initial Variable States
F = tk.StringVar()
F.set(0)
P = tk.StringVar()
P.set(0)

#Setup Callable Functions
    #Function to define flow meter usage
def Flow_Select():
    global F
    
    if F.get() == '0':
        print('no flow')
    elif F.get() == '1':
        print('flow1')
    elif F.get() == '2':
        print('flow2')
    elif F.get() == '3':
        print('flow3')
    elif F.get() == '4':
        print('flow4')
    elif F.get() == '5':
        print('flow5')
    elif F.get() == '6':
        print('flow6')

    #Function to define pressure transducer usage
def Press_Select():
    global P
    
    if P.get() == '0':
        print('no pressure')
    elif P.get() == '1':
        print('Pressure1')
    elif P.get() == '2':
        print('Pressure2')
    elif P.get() == '3':
        print('Pressure3')
    
        
    #Function to return to previous screen
def Back():
    file_object = open("Z1_BENCH_CONFIGURATION.txt", "r")
    lines = file_object.readlines()
    lines = lines[:-1]
    lines = [x.strip('\n') for x in lines]

    with open("Z1_BENCH_CONFIGURATION.txt","w") as file_object:
                    writer = csv.writer(file_object)
                    for line in lines:
                        writer.writerow([line])
                    file_object.close()
    
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/01_Pressure_Flow.py"]) 
    sys.exit()
    #Function to proceed to the next screen
def Forward():
    if F.get() > '0' and P.get() > '0':
        with open("Z1_BENCH_CONFIGURATION.txt","a") as file_object:
                writer = csv.writer(file_object)
                writer.writerow([F.get()])
                writer.writerow([P.get()])
                file_object.close()
        subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Development/03_0_Automated_Manual.py"]) 
        sys.exit()
    elif F.get() == '0' and P.get() == '0':
        messagebox.showinfo("Error - No Selections Made","Please select a FLOW METER and PRESSURE TRANSDUCER")
    elif F.get() == '0' and P.get() > '0':
        messagebox.showinfo("Error - No Flow Selection Made","Please Select Flow Meter")
    elif P.get() == '0' and F.get() > '0':
        messagebox.showinfo("Error - No Pressure Selection Made","Please Select Pressure Transducer")
        
    #Function to end program selection window
def Exit_Program():
    print("Exit Button pressed")
    file_object=open("Z1_BENCH_CONFIGURATION.txt","w")
    file_object.close()
    sys.exit()
    
#Buttons and Labels
    #Headers/titles - LABELS
Header = Label(GUI, text="Flow Bench User Interface - System Setup (2/4)", background='black', font = 'Helvetica 14 bold underline bold', fg='dark goldenrod')
Header.grid(row=0, column=2)
    #Headers/titles - LABELS
Pressure_Label=Label(GUIF, text = 'Flow Meter Selection', background='black', font = 'Helvetica 9 bold',fg='dark goldenrod', highlightthickness=1, highlightbackground='black', width=25)
Pressure_Label.grid(row=0, column=0)
Flow_Label=Label(GUIF, text = 'Pressure Trans. Selection', background='black', font = 'Helvetica 9 bold',fg='dark goldenrod', highlightthickness=1, highlightbackground='black', width=25)
Flow_Label.grid(row=0, column=1)
    #Program Back - BUTTON COMMAND
BackButton = tk.Button(GUIFII, text="Previous Screen",command=Back, background='steel blue', width =12, font = 'Helvetica 8 bold', highlightbackground='gray82', activebackground='royal blue', borderwidth=.5, relief='solid')
BackButton.grid(row=3, column=0, sticky = W)
    #Program Forward - BUTTON COMMAND
ForwardButton = tk.Button(GUIFII, text="Next Screen",command=Forward, background='steel blue', width =12, font = 'Helvetica 8 bold', highlightbackground='gray82', activebackground='royal blue', borderwidth=.5, relief='solid')
ForwardButton.grid(row=3, column=2, sticky = E)
    #Program Exit - BUTTON COMMAND
ExitButton = tk.Button(GUI, text="EXIT NOW",command=Exit_Program, background='orangered4', width =10, font = 'Helvetica 8 bold', highlightbackground='yellow', activebackground='orangered3', borderwidth=.5, relief='solid')
ExitButton.grid(row=3, column=2, columnspan = 2, sticky = E)
    #Flow Selection - BUTTON COMMAND
fb0=Radiobutton(GUIFI, text="   ***No Flow Selected***  ",value=0, variable=F, command=Flow_Select, bg='black', selectcolor='green', fg='DarkGoldenRod3', activebackground = 'dark slate gray', highlightbackground='OrangeRed4', font='Helvetica 8', width=25, height=1)
fb0.grid(row=1, column=0, sticky = W)
fb1=Radiobutton(GUIFI, text="Flow 1: 0.00 to 0.01 kg/hr",value=1, variable=F, command=Flow_Select, bg='black', selectcolor='green', fg='DarkGoldenRod3', activebackground = 'dark slate gray', highlightbackground='OrangeRed4', font='Helvetica 8', width=25, height=1)
fb1.grid(row=2, column=0, sticky = W)
fb2=Radiobutton(GUIFI, text="Flow 2: 0.01 to 0.15 kg/hr",value=2, variable=F, command=Flow_Select, bg='black', selectcolor='green', fg='DarkGoldenRod3', activebackground = 'dark slate gray', highlightbackground='OrangeRed4', font='Helvetica 8', width=25, height=1)
fb2.grid(row=3, column=0, sticky = W)
fb3=Radiobutton(GUIFI, text="Flow 3: 0.15 to 2.00 kg/hr",value=3, variable=F, command=Flow_Select, bg='black', selectcolor='green', fg='DarkGoldenRod3', activebackground = 'dark slate gray', highlightbackground='OrangeRed4', font='Helvetica 8', width=25, height=1)
fb3.grid(row=4, column=0, sticky = W)
fb4=Radiobutton(GUIFI, text="Flow 4: 2.00 to 4.00 kg/hr",value=4, variable=F, command=Flow_Select, bg='black', selectcolor='green', fg='DarkGoldenRod3', activebackground = 'dark slate gray', highlightbackground='OrangeRed4', font='Helvetica 8', width=25, height=1)
fb4.grid(row=5, column=0, sticky = W)
fb5=Radiobutton(GUIFI, text="Flow 5: 4.00 to 50.0 kg/hr",value=5, variable=F, command=Flow_Select, bg='black', selectcolor='green', fg='DarkGoldenRod3', activebackground = 'dark slate gray', highlightbackground='OrangeRed4', font='Helvetica 8', width=25, height=1)
fb5.grid(row=6, column=0, sticky = W)
fb6=Radiobutton(GUIFI, text="Flow 6: 50.0 to 612  kg/hr",value=6, variable=F, command=Flow_Select, bg='black', selectcolor='green', fg='DarkGoldenRod3', activebackground = 'dark slate gray', highlightbackground='OrangeRed4', font='Helvetica 8', width=25, height=1)
fb6.grid(row=7, column=0, sticky = W)
    #Pressure Selection - BUTTON COMMAND
pb0=Radiobutton(GUIFI, text="  ***No Press Selected***  ",value=0, variable=P, command=Press_Select, bg='black', selectcolor='green', fg='DarkGoldenRod3', activebackground = 'dark slate gray', highlightbackground='OrangeRed4', font='Helvetica 8', width=25, height=1)
pb0.grid(row=1, column=2, sticky = W)
pb1=Radiobutton(GUIFI, text="Press 1: 0.00 to 5.00 Bar  ",value=1, variable=P, command=Press_Select, bg='black', selectcolor='green', fg='DarkGoldenRod3', activebackground = 'dark slate gray', highlightbackground='OrangeRed4', font='Helvetica 8', width=25, height=1)
pb1.grid(row=2, column=2, sticky = W)
pb2=Radiobutton(GUIFI, text="Press 2: 0.00 to 10.0 Bar  ",value=2, variable=P, command=Press_Select, bg='black', selectcolor='green', fg='DarkGoldenRod3', activebackground = 'dark slate gray', highlightbackground='OrangeRed4', font='Helvetica 8', width=25, height=1)
pb2.grid(row=3, column=2, sticky = W)
pb3=Radiobutton(GUIFI, text="Press 3: 1.00 Bar Differn  ",value=3, variable=P, command=Press_Select, bg='black', selectcolor='green', fg='DarkGoldenRod3', activebackground = 'dark slate gray', highlightbackground='OrangeRed4', font='Helvetica 8', width=25, height=1)
pb3.grid(row=4, column=2, sticky = W)


#Keeping the Window Open and Protocals for Closing
GUI.protocol("WM_DELETE_WINDOW", Exit_Program)
GUI.mainloop()


