#!/usr/bin/env python3

from tkinter import *
from tkinter.font import Font
from datetime import date
from decimal import*
from sys import stdout
import tkinter as tk
import RPi.GPIO as GPIO
import pandas as pd
import numpy as np
import csv
import os
import subprocess
import shutil
import time
from smbus2 import SMBus, i2c_msg
import yaml
import logging

from daqhats import mcc152, OptionFlags, HatIDs, HatError
from daqhats_utils import select_hat_device, enum_mask_to_string, chan_list_to_mask


#Obtain the Board Information and set a load
address = select_hat_device(HatIDs.MCC_152)
hat = mcc152(address)
options = OptionFlags.DEFAULT
info = mcc152.info().NUM_AO_CHANNELS
channel = 0
value_convert = 2
hat.a_out_write(channel=channel,value=value_convert,options=options)



GUI = Tk()

GUI.grid_rowconfigure(1, minsize=10)
GUI.grid_rowconfigure(2, minsize=10)
GUI.grid_rowconfigure(3, minsize=10)
GUI.grid_rowconfigure(4, minsize=10)
GUI.grid_rowconfigure(5, minsize=10)


GUI.grid_columnconfigure(0, minsize=20)
GUI.grid_columnconfigure(1, minsize=20)
GUI.grid_columnconfigure(2, minsize=20)

myFont = Font(family = 'Helvetica', size = 10, weight = 'bold')

R1 = tk.StringVar()
stepperi = '-------'
stepperf = '-------'
stepper = tk.StringVar()
steppert = tk.StringVar()
steppert.set(str(stepperi)+' / '+str(stepperf))
on_off = tk.StringVar()
on_off.set('System is Off')


def jrk2cmd(*args):
  return subprocess.check_output(['jrk2cmd'] + list(args))

jrk2cmd('--stop')

class JrkG2I2C(object):
  def __init__(self, bus, address):
    self.bus = bus
    self.address = address
 
  # Sets the target.  For more information about what this command does,
  # see the "Set Target" command in the "Command reference" section of
  # the Jrk G2 user's guide.
  def set_target(self, target):
    command = [0xC0 + (target & 0x1F), (target >> 5) & 0x7F]
    write = i2c_msg.write(self.address, command)
    self.bus.i2c_rdwr(write)
 
  # Gets one or more variables from the Jrk (without clearing them).
  # Returns a list of byte values (integers between 0 and 255).
  def get_variables(self, offset, length):
    write = i2c_msg.write(self.address, [0xE5, offset])
    read = i2c_msg.read(self.address, length)
    self.bus.i2c_rdwr(write, read)
    return list(read)
 
  # Gets the Target variable from the Jrk.
  def get_target(self):
    b = self.get_variables(0x02, 2)
    return b
    print(b)
 
  # Gets the Feedback variable from the Jrk.
  def get_feedback(self):
    b = self.get_variables(0x04, 2)
    return b
    print(b)
 
# Open a handle to "/dev/i2c-3", representing the I2C bus.
bus = SMBus(1)
 
# Select the I2C address of the Jrk (the device number).
address = 11
jrk = JrkG2I2C(bus, address)

jrk.set_target(10)
jrk2cmd('--run')

status = yaml.safe_load(jrk2cmd('-s', '--full'))
feedback = int((status['Feedback'])/4095*100)
target = int((status['Target'])/4095*100)
error = int(abs((feedback-target)))
print(error,feedback,target)


if error > 50:
    print('Error out of range')
    running = False
    jrk2cmd('--stop')
    motor_state = False

motor_state = True
positions = [2000,2350,4000]
i=0
error=0
running = False
start_time=time.ctime()
count=0

def Cycle_Start():
    global stepperf
    global stepperi
    global error
    global positions
    global i
    global motor_state
    global running
    global start_time
    global count
    
    if running is True and motor_state is True:
        if stepperi < stepperf:
            try:
                jrk.set_target(positions[i])
            except:
                print('fireeee')
                time.sleep(.5)
                try:
                    jrk.set_target(positions[i])
                except:
                    print('fireeee again')
                    time.sleep(.5)
                    jrk.set_target(positions[i])
                
            time.sleep(.25)
            status = yaml.safe_load(jrk2cmd('-s', '--full'))
            feedback = int((status['Feedback'])/4095*100)
            target = int((status['Target'])/4095*100)
            error = int(abs((feedback-target)))
            print (error)
            i+=1
            count+=1
            
            if count > 100000:
                end_time=time.ctime()
                li=(stepperi,start_time)
                li=np.array(li).tolist()
                lf=(stepperf,end_time)
                lf=np.array(lf).tolist()
                rows = zip(li,lf)
                print(rows)
                
                with open('/home/pi/Desktop/Python Program Scripts/Finalized/Vavle Development/Log_Files_Dither_NL/Last_Cycle_Count_'+str(round(time.time()))+'.txt', 'w') as f:
                    writer = csv.writer(f)
                    for row in rows:
                        writer.writerow(row)
                f.close()
                count=0
            
        else:
            print('Target cycles reached')
            running = False
            on_off.set('System is Off')
            StartStop['background']=('firebrick')
            StartStop['activebackground']=('red')
            GUI.update_idletasks()
            end_time=time.ctime()
            li=(stepperi,start_time)
            li=np.array(li).tolist()
            lf=(stepperf,end_time)
            lf=np.array(lf).tolist()
            rows = zip(li,lf)
            print(rows)
            
            with open('/home/pi/Desktop/Python Program Scripts/Finalized/Vavle Development/Log_Files_Dither_NL/Last_Cycle_Count_'+str(round(time.time()))+'.txt', 'w') as f:
                writer = csv.writer(f)
                for row in rows:
                    writer.writerow(row)
            f.close()
        
        if error > 85:
            print('Error out of range')
            running = False
            jrk2cmd('--stop')
            motor_state = False
            end_time=time.ctime()
            li=(stepperi,start_time)
            li=np.array(li).tolist()
            lf=(stepperf,end_time)
            lf=np.array(lf).tolist()
            rows = zip(li,lf)
            print(rows)
            
            with open('/home/pi/Desktop/Python Program Scripts/Finalized/Vavle Development/Log_Files/Last_Cycle_Count_'+str(round(time.time()))+'.txt', 'w') as f:
                writer = csv.writer(f)
                for row in rows:
                    writer.writerow(row)
            f.close()
            
        if i >= len(positions)-1:
            i = 0
            stepperi+=1
            steppert.set(str(stepperi)+' / '+str(stepperf))
            GUI.update_idletasks()
    
    GUI.after(2,Cycle_Start)
    
def motor_power():
    global motor_state
    
    if motor_state is False:
        jrk2cmd('--run')
    else:
        print('Motor is already running')
        
def program_run():
    global running
    global stepperf
    global stepperi
    global error
    global positions
    global i
    global motor_state
    global start_time

    if running == False:
        running = True
        print(running)
        on_off.set('System Running')
        StartStop['background']=('green')
        StartStop['activebackground']=('green')
        GUI.update_idletasks()
    else:
        running = False
        on_off.set('System is Off')
        StartStop['background']=('firebrick')
        StartStop['activebackground']=('red')
        GUI.update_idletasks()
        end_time=time.ctime()
        li=(stepperi,start_time)
        li=np.array(li).tolist()
        lf=(stepperf,end_time)
        lf=np.array(lf).tolist()
        rows = zip(li,lf)
        print(rows)
        
        with open('/home/pi/Desktop/Python Program Scripts/Finalized/Vavle Development/Log_Files/Last_Cycle_Count_'+str(round(time.time()))+'.txt', 'w') as f:
            writer = csv.writer(f)
            for row in rows:
                writer.writerow(row)
        f.close()
        

def stepperi_Cycles():
    global stepperi
           
    stepperi = int(stepper_i.get())
    stepper_i.delete(0,'end')
    steppert.set(str(stepperi)+' / '+str(stepperf))
    
def stepperf_Cycles():
    global stepperf
           
    stepperf = int(stepper_f.get())
    stepper_f.delete(0,'end')
    steppert.set(str(stepperi)+' / '+str(stepperf))


def Exit_Program():
    print("Exit Button pressed")
    jrk.set_target(10)
    jrk2cmd('--stop')
    address = select_hat_device(HatIDs.MCC_152)
    hat = mcc152(address)
    options = OptionFlags.DEFAULT
    info = mcc152.info().NUM_AO_CHANNELS
    channel = 0
    value_convert = 0
    hat.a_out_write(channel=channel,value=value_convert,options=options)
    sys.exit()



GUI.title("Motor Control")
GUI.configure(background='black')

GUIF = Frame(GUI, bg='black', height=1)
GUIF.grid(row=3, column=1, sticky=W)
GUIF.grid_rowconfigure(3, minsize=10)
GUIF.grid_columnconfigure(1, minsize=100)
GUIF.grid_columnconfigure(2, minsize=100)

stepper_l=Label(GUIF, text = 'Start Cycle', background='black', font = 'Helvetica 10 bold',fg='dark goldenrod', highlightthickness=1, highlightbackground='black', width=13).grid(row=0, column=1)
stepper_l=Label(GUIF, text = 'End Cycle', background='black', font = 'Helvetica 10 bold',fg='dark goldenrod', highlightthickness=1, highlightbackground='black', width=13).grid(row=0, column=2)
stepper_l=Label(GUIF, text = 'Current Count', background='black', font = 'Helvetica 10 bold',fg='dark goldenrod', highlightthickness=1, highlightbackground='black', width=13).grid(row=0, column=3)

stepper_i=Entry(GUIF, width = 14, bg='black', fg='coral', font = 'Times 10', highlightbackground='OrangeRed4', highlightcolor='OrangeRed2', highlightthickness=1, relief='flat', justify='center')
stepper_i.grid(row=1,column=1,sticky=W)
stepper_i.bind('<Return>', (lambda event: stepperi_Cycles()))
stepper_i.bind('<KP_Enter>', (lambda event: stepperi_Cycles()))
stepper_f=Entry(GUIF, width = 14, bg='black', fg='coral', font = 'Times 10', highlightbackground='OrangeRed4', highlightcolor='OrangeRed2', highlightthickness=1, relief='flat', justify='center')
stepper_f.grid(row=1,column=2,sticky=W)
stepper_f.bind('<Return>', (lambda event: stepperf_Cycles()))
stepper_f.bind('<KP_Enter>', (lambda event: stepperf_Cycles()))
stepper_l=Label(GUIF, textvariable = steppert, background='black', font = 'Helvetica 10 bold',fg='coral', highlightthickness=1, highlightbackground='OrangeRed4', width=20).grid(row=1, column=3)

StartStop = Button(GUIF, textvariable = on_off, font = myFont, command = program_run, height = 1, width =12, background = 'firebrick', activebackground = 'red')
StartStop.grid(row=4, column=3, sticky=E)

GUI.after(2,Cycle_Start)
GUI.protocol("WM_DELETE_WINDOW", Exit_Program)
mainloop()