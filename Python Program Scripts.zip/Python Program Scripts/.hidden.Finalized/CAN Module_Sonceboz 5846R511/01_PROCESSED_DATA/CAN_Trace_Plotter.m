clc
clear all

%Load File
file = 'Position_Command.txt';    
[A]=dlmread(file,',');    
Pa= 2                  
Qa=length(A);          
Ra=[Pa:Qa];              
Timea=(A(Ra,1));   
Command=(A(Ra,2));

%Load File
file = 'Position_Feedback.txt';    
[B]=dlmread(file,',');   
Pb= 2                  
Qb=length(B);          
Rb=[Pb:Qb];              
Timeb=(B(Rb,1));   
Feedback=(B(Rb,2));

%Load File
file = 'Current.txt';   
[C]=dlmread(file,',');    
Pc= 2                  
Qc=length(C);          
Rc=[Pc:Qc];              
Timec=(C(Rc,1));   
Current=(C(Rc,2));

%Load File
file = 'Temperature.txt';   
[D]=dlmread(file,',');   
Pd= 2                  
Qd=length(D);          
Rd=[Pd:Qd];              
Timed=(D(Rd,1));   
Temperature=(D(Rd,2));


%Plot Individual line graphs
figure (figure);
subplot (4,1,1);
plot(Timea,Command,"bk");
title ('Command vs Time');
xlabel('Time (sec)');
ylabel('Cmd Position (% of 100)');

hold on
subplot (4,1,2);
plot(Timeb,Feedback,"g");
title ('Feedback vs Time');
xlabel('Time (sec)');
ylabel('Fdbk Position (% of 100)');

hold on
subplot(4,1,3);
plot(Timec,Current,"b");
title ('Current vs Time');
xlabel('Time (sec)');
ylabel('Current (% of 100)');

hold on
subplot(4,1,4);
plot(Timed,Temperature,"r");
title ('Temperature vs Time');
xlabel('Time (sec)');
ylabel('Temperature (deg C)');




%Plot individual line graphs over dot graphs
%figure (figure);
%subplot (4,1,1);
%plot(Timea,Command,"bk",Timea,Command,".r");
%title ('Actuator Response');
%xlabel('Time (sec)');
%ylabel('Cmd Position (%)');
%
%hold on
%subplot (4,1,2);
%plot(Timeb,Feedback,"bk",Timeb,Feedback,".r");
%title ('Actuator Response');
%xlabel('Time (sec)');
%ylabel('Fdbk Position (%)');
%
%hold on
%subplot(4,1,3);
%plot(Timec,Current,"bk",Timec,Current,".r");
%title ('Actuator Response');
%xlabel('Time (sec)');
%ylabel('Current (%)');
%
%hold on
%subplot(4,1,4);
%plot(Timed,Temperature,"bk",Timed,Temperature,'.r');
%title ('Actuator Response');
%xlabel('Time (sec)');
%ylabel('Temperature (deg C)');


%Calculate and plot velocity of feedback verse feedback
%velocity= diff(Feedback)./diff(Timeb);
%plot (Timeb([1:length(Timeb)-1]),velocity,'.r')
%hold on
%plot (Timeb,Feedback,'g')
