#!/usr/bin/env python3

import multiprocessing as mp
import csv
import pandas
import shutil
import os
import time
import matplotlib.pyplot as plt
from decimal import*

d=pandas.read_csv(r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/rawtemp.log", header=None, delim_whitespace=True)
d=pandas.DataFrame(d)
dl=len(d.index)
dl=int(dl/40)

def proc_temp1():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp1.txt","w+")
    
    for i in range(1,dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp1.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
    
def proc_temp2():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp2.txt","w+")
    
    for i in range(dl,2*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp2.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp3():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp3.txt","w+")
    
    for i in range(2*dl,3*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp3.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)            

def proc_temp4():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp4.txt","w+")
    
    for i in range(3*dl,4*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp4.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp5():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp5.txt","w+")
    
    for i in range(4*dl,5*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp5.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_temp6():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp6.txt","w+")
    
    for i in range(5*dl,6*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp6.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_temp7():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp7.txt","w+")
    
    for i in range(6*dl,7*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp7.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_temp8():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp8.txt","w+")
    
    for i in range(7*dl,8*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp8.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_temp9():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp9.txt","w+")
    
    for i in range(8*dl,9*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp9.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_temp10():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp10.txt","w+")
    
    for i in range(9*dl,10*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp10.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_temp11():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp11.txt","w+")
    
    for i in range(10*dl,11*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp11.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_temp12():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp12.txt","w+")
    
    for i in range(11*dl,12*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp12.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_temp13():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp13.txt","w+")
    
    for i in range(12*dl,13*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp13.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_temp14():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp14.txt","w+")
    
    for i in range(13*dl,14*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp14.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_temp15():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp15.txt","w+")
    
    for i in range(14*dl,15*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp15.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_temp16():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp16.txt","w+")
    
    for i in range(15*dl,16*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp16.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_temp17():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp17.txt","w+")
    
    for i in range(16*dl,17*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp17.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_temp18():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp18.txt","w+")
    
    for i in range(17*dl,18*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp18.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_temp19():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp19.txt","w+")
    
    for i in range(18*dl,19*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp19.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp20():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp20.txt","w+")
    
    for i in range(19*dl,20*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp20.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp21():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp21.txt","w+")
    
    for i in range(20*dl,21*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp21.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp22():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp22.txt","w+")
    
    for i in range(21*dl,22*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp22.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp23():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp23.txt","w+")
    
    for i in range(22*dl,23*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp23.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp24():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp24.txt","w+")
    
    for i in range(23*dl,24*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp24.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp25():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp25.txt","w+")
    
    for i in range(24*dl,25*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp25.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp26():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp26.txt","w+")
    
    for i in range(25*dl,26*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp26.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp27():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp27.txt","w+")
    
    for i in range(26*dl,27*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp27.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp28():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp28.txt","w+")
    
    for i in range(27*dl,28*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp28.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp29():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp29.txt","w+")
    
    for i in range(28*dl,29*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp29.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp30():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp30.txt","w+")
    
    for i in range(29*dl,30*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp30.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp31():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp31.txt","w+")
    
    for i in range(30*dl,31*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp31.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp32():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp32.txt","w+")
    
    for i in range(31*dl,32*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp32.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp33():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp33.txt","w+")
    
    for i in range(32*dl,33*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp33.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp34():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp34.txt","w+")
    
    for i in range(33*dl,34*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp34.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp35():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp35.txt","w+")
    
    for i in range(34*dl,35*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp35.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp36():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp36.txt","w+")
    
    for i in range(35*dl,36*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp36.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp37():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp37.txt","w+")
    
    for i in range(36*dl,37*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp37.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp38():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp38.txt","w+")
    
    for i in range(37*dl,38*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp38.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp39():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp39.txt","w+")
    
    for i in range(38*dl,39*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp39.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_temp40():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp40.txt","w+")
    
    for i in range(39*dl,40*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[13:15].iat[0],16)-40,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp40.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)             
    
    file_compile()

def file_compile():
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/Temperature.txt","w+")
        
    filenames = ['/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp1.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp2.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp3.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp4.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp5.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp6.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp7.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp8.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp9.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp10.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp11.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp12.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp13.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp14.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp15.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp16.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp17.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp18.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp19.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp20.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp21.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp22.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp23.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp24.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp25.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp26.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp27.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp28.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp29.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp30.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp31.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp32.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp33.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp34.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp35.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp36.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp37.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp38.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp39.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_temp40.txt']

    with open('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/01_PROCESSED_DATA/Temperature.txt', 'w') as outfile:
        for fname in filenames:
            with open(fname) as infile:
                outfile.write(infile.read())
    os.remove(r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/rawtemp.log")

     
       
            
            
            
#Function used to process data during recording
p1 = mp.Process(target = proc_temp1)
p2 = mp.Process(target = proc_temp2)
p3 = mp.Process(target = proc_temp3)
p4 = mp.Process(target = proc_temp4)
p5 = mp.Process(target = proc_temp5)
p6 = mp.Process(target = proc_temp6)
p7 = mp.Process(target = proc_temp7)
p8 = mp.Process(target = proc_temp8)
p9 = mp.Process(target = proc_temp9)
p10 = mp.Process(target = proc_temp10)
p11 = mp.Process(target = proc_temp11)
p12 = mp.Process(target = proc_temp12)
p13 = mp.Process(target = proc_temp13)
p14 = mp.Process(target = proc_temp14)
p15 = mp.Process(target = proc_temp15)
p16 = mp.Process(target = proc_temp16)
p17 = mp.Process(target = proc_temp17)
p18 = mp.Process(target = proc_temp18)
p19 = mp.Process(target = proc_temp19)
p20 = mp.Process(target = proc_temp20)
p21 = mp.Process(target = proc_temp21)
p22 = mp.Process(target = proc_temp22)
p23 = mp.Process(target = proc_temp23)
p24 = mp.Process(target = proc_temp24)
p25 = mp.Process(target = proc_temp25)
p26 = mp.Process(target = proc_temp26)
p27 = mp.Process(target = proc_temp27)
p28 = mp.Process(target = proc_temp28)
p29 = mp.Process(target = proc_temp29)
p30 = mp.Process(target = proc_temp30)
p31 = mp.Process(target = proc_temp31)
p32 = mp.Process(target = proc_temp32)
p33 = mp.Process(target = proc_temp33)
p34 = mp.Process(target = proc_temp34)
p35 = mp.Process(target = proc_temp35)
p36 = mp.Process(target = proc_temp36)
p37 = mp.Process(target = proc_temp37)
p38 = mp.Process(target = proc_temp38)
p39 = mp.Process(target = proc_temp39)
p40 = mp.Process(target = proc_temp40)
                
p1.start()
p2.start()
p3.start()
p4.start()       
p5.start()
p6.start()
p7.start()
p8.start()
p9.start()       
p10.start()
p11.start()
p12.start()
p13.start()
p14.start()       
p15.start()
p16.start()
p17.start()
p18.start()
p19.start()       
p20.start()
p21.start()
p22.start()
p23.start()
p24.start()
p25.start()
p26.start()
p27.start()
p28.start()
p29.start()
p30.start()
p31.start()
p32.start()
p33.start()
p34.start()
p35.start()
p36.start()
p37.start()
p38.start()
p39.start()
p40.start()
