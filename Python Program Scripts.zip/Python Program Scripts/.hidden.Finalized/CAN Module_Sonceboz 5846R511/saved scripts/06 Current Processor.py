#!/usr/bin/env python3

import multiprocessing as mp
import csv
import pandas
import shutil
import os
import time
import matplotlib.pyplot as plt
from decimal import*

d=pandas.read_csv(r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/rawcur.log", header=None, delim_whitespace=True)
d=pandas.DataFrame(d)
dl=len(d.index)
dl=int(dl/40)

def proc_cur1():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur1.txt","w+")
    
    for i in range(1,dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur1.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
    
def proc_cur2():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur2.txt","w+")
    
    for i in range(dl,2*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur2.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur3():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur3.txt","w+")
    
    for i in range(2*dl,3*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur3.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)            

def proc_cur4():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur4.txt","w+")
    
    for i in range(3*dl,4*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur4.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur5():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur5.txt","w+")
    
    for i in range(4*dl,5*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur5.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cur6():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur6.txt","w+")
    
    for i in range(5*dl,6*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur6.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cur7():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur7.txt","w+")
    
    for i in range(6*dl,7*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur7.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cur8():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur8.txt","w+")
    
    for i in range(7*dl,8*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur8.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cur9():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur9.txt","w+")
    
    for i in range(8*dl,9*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur9.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cur10():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur10.txt","w+")
    
    for i in range(9*dl,10*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur10.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cur11():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur11.txt","w+")
    
    for i in range(10*dl,11*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur11.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cur12():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur12.txt","w+")
    
    for i in range(11*dl,12*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur12.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cur13():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur13.txt","w+")
    
    for i in range(12*dl,13*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur13.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cur14():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur14.txt","w+")
    
    for i in range(13*dl,14*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur14.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cur15():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur15.txt","w+")
    
    for i in range(14*dl,15*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur15.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cur16():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur16.txt","w+")
    
    for i in range(15*dl,16*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur16.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cur17():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur17.txt","w+")
    
    for i in range(16*dl,17*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur17.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cur18():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur18.txt","w+")
    
    for i in range(17*dl,18*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur18.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cur19():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur19.txt","w+")
    
    for i in range(18*dl,19*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur19.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur20():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur20.txt","w+")
    
    for i in range(19*dl,20*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur20.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur21():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur21.txt","w+")
    
    for i in range(20*dl,21*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur21.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur22():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur22.txt","w+")
    
    for i in range(21*dl,22*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur22.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur23():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur23.txt","w+")
    
    for i in range(22*dl,23*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur23.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur24():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur24.txt","w+")
    
    for i in range(23*dl,24*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur24.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur25():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur25.txt","w+")
    
    for i in range(24*dl,25*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur25.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur26():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur26.txt","w+")
    
    for i in range(25*dl,26*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur26.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur27():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur27.txt","w+")
    
    for i in range(26*dl,27*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur27.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur28():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur28.txt","w+")
    
    for i in range(27*dl,28*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur28.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur29():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur29.txt","w+")
    
    for i in range(28*dl,29*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur29.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur30():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur30.txt","w+")
    
    for i in range(29*dl,30*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur30.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur31():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur31.txt","w+")
    
    for i in range(30*dl,31*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur31.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur32():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur32.txt","w+")
    
    for i in range(31*dl,32*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur32.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur33():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur33.txt","w+")
    
    for i in range(32*dl,33*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur33.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur34():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur34.txt","w+")
    
    for i in range(33*dl,34*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur34.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur35():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur35.txt","w+")
    
    for i in range(34*dl,35*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur35.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur36():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur36.txt","w+")
    
    for i in range(35*dl,36*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur36.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur37():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur37.txt","w+")
    
    for i in range(36*dl,37*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur37.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur38():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur38.txt","w+")
    
    for i in range(37*dl,38*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur38.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur39():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur39.txt","w+")
    
    for i in range(38*dl,39*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur39.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cur40():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur40.txt","w+")
    
    for i in range(39*dl,40*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=round(int(y[2].str[9:11].iat[0],16)/250*100-50,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur40.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)             
    
    file_compile()

def file_compile():
        
    filenames = ['/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur1.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur2.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur3.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur4.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur5.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur6.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur7.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur8.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur9.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur10.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur11.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur12.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur13.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur14.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur15.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur16.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur17.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur18.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur19.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur20.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur21.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur22.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur23.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur24.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur25.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur26.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur27.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur28.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur29.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur30.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur31.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur32.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur33.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur34.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur35.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur36.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur37.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur38.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur39.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cur40.txt']

    with open('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/01_PROCESSED_DATA/Current.txt', 'w') as outfile:
        for fname in filenames:
            with open(fname) as infile:
                outfile.write(infile.read())
    os.remove(r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/rawcur.log")

           
            
            
            
#Function used to process data during recording
p1 = mp.Process(target = proc_cur1)
p2 = mp.Process(target = proc_cur2)
p3 = mp.Process(target = proc_cur3)
p4 = mp.Process(target = proc_cur4)
p5 = mp.Process(target = proc_cur5)
p6 = mp.Process(target = proc_cur6)
p7 = mp.Process(target = proc_cur7)
p8 = mp.Process(target = proc_cur8)
p9 = mp.Process(target = proc_cur9)
p10 = mp.Process(target = proc_cur10)
p11 = mp.Process(target = proc_cur11)
p12 = mp.Process(target = proc_cur12)
p13 = mp.Process(target = proc_cur13)
p14 = mp.Process(target = proc_cur14)
p15 = mp.Process(target = proc_cur15)
p16 = mp.Process(target = proc_cur16)
p17 = mp.Process(target = proc_cur17)
p18 = mp.Process(target = proc_cur18)
p19 = mp.Process(target = proc_cur19)
p20 = mp.Process(target = proc_cur20)
p21 = mp.Process(target = proc_cur21)
p22 = mp.Process(target = proc_cur22)
p23 = mp.Process(target = proc_cur23)
p24 = mp.Process(target = proc_cur24)
p25 = mp.Process(target = proc_cur25)
p26 = mp.Process(target = proc_cur26)
p27 = mp.Process(target = proc_cur27)
p28 = mp.Process(target = proc_cur28)
p29 = mp.Process(target = proc_cur29)
p30 = mp.Process(target = proc_cur30)
p31 = mp.Process(target = proc_cur31)
p32 = mp.Process(target = proc_cur32)
p33 = mp.Process(target = proc_cur33)
p34 = mp.Process(target = proc_cur34)
p35 = mp.Process(target = proc_cur35)
p36 = mp.Process(target = proc_cur36)
p37 = mp.Process(target = proc_cur37)
p38 = mp.Process(target = proc_cur38)
p39 = mp.Process(target = proc_cur39)
p40 = mp.Process(target = proc_cur40)
                
p1.start()
p2.start()
p3.start()
p4.start()       
p5.start()
p6.start()
p7.start()
p8.start()
p9.start()       
p10.start()
p11.start()
p12.start()
p13.start()
p14.start()       
p15.start()
p16.start()
p17.start()
p18.start()
p19.start()       
p20.start()
p21.start()
p22.start()
p23.start()
p24.start()
p25.start()
p26.start()
p27.start()
p28.start()
p29.start()
p30.start()
p31.start()
p32.start()
p33.start()
p34.start()
p35.start()
p36.start()
p37.start()
p38.start()
p39.start()
p40.start()
    
    
