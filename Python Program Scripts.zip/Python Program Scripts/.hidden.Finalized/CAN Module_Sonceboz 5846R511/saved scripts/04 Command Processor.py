#!/usr/bin/env python3

import multiprocessing as mp
import csv
import pandas
import shutil
import os
import time
import matplotlib.pyplot as plt
from decimal import*


d=pandas.read_csv(r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/rawcmd.log", header=None, delim_whitespace=True)
d=pandas.DataFrame(d)
dl=len(d.index)
dl=int(dl/40)

def proc_cmd1():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd1.txt","w+")
    
    for i in range(1,dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd1.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
    
def proc_cmd2():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd2.txt","w+")
    
    for i in range(dl,2*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd2.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd3():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd3.txt","w+")
    
    for i in range(2*dl,3*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd3.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)            

def proc_cmd4():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd4.txt","w+")
    
    for i in range(3*dl,4*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd4.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd5():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd5.txt","w+")
    
    for i in range(4*dl,5*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd5.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cmd6():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd6.txt","w+")
    
    for i in range(5*dl,6*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd6.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cmd7():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd7.txt","w+")
    
    for i in range(6*dl,7*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd7.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cmd8():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd8.txt","w+")
    
    for i in range(7*dl,8*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd8.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cmd9():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd9.txt","w+")
    
    for i in range(8*dl,9*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd9.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cmd10():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd10.txt","w+")
    
    for i in range(9*dl,10*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd10.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cmd11():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd11.txt","w+")
    
    for i in range(10*dl,11*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd11.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cmd12():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd12.txt","w+")
    
    for i in range(11*dl,12*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd12.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cmd13():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd13.txt","w+")
    
    for i in range(12*dl,13*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd13.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cmd14():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd14.txt","w+")
    
    for i in range(13*dl,14*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd14.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cmd15():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd15.txt","w+")
    
    for i in range(14*dl,15*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd15.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cmd16():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd16.txt","w+")
    
    for i in range(15*dl,16*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd16.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cmd17():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd17.txt","w+")
    
    for i in range(16*dl,17*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd17.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cmd18():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd18.txt","w+")
    
    for i in range(17*dl,18*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd18.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_cmd19():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd19.txt","w+")
    
    for i in range(18*dl,19*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd19.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd20():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd20.txt","w+")
    
    for i in range(19*dl,20*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd20.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd21():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd21.txt","w+")
    
    for i in range(20*dl,21*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd21.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd22():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd22.txt","w+")
    
    for i in range(21*dl,22*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd22.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd23():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd23.txt","w+")
    
    for i in range(22*dl,23*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd23.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd24():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd24.txt","w+")
    
    for i in range(23*dl,24*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd24.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd25():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd25.txt","w+")
    
    for i in range(24*dl,25*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd25.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd26():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd26.txt","w+")
    
    for i in range(25*dl,26*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd26.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd27():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd27.txt","w+")
    
    for i in range(26*dl,27*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd27.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd28():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd28.txt","w+")
    
    for i in range(27*dl,28*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd28.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd29():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd29.txt","w+")
    
    for i in range(28*dl,29*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd29.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd30():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd30.txt","w+")
    
    for i in range(29*dl,30*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd30.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd31():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd31.txt","w+")
    
    for i in range(30*dl,31*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd31.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd32():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd32.txt","w+")
    
    for i in range(31*dl,32*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd32.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd33():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd33.txt","w+")
    
    for i in range(32*dl,33*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd33.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd34():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd34.txt","w+")
    
    for i in range(33*dl,34*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd34.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd35():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd35.txt","w+")
    
    for i in range(34*dl,35*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd35.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd36():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd36.txt","w+")
    
    for i in range(35*dl,36*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd36.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd37():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd37.txt","w+")
    
    for i in range(36*dl,37*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd37.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd38():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd38.txt","w+")
    
    for i in range(37*dl,38*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd38.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd39():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd39.txt","w+")
    
    for i in range(38*dl,39*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd39.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_cmd40():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd40.txt","w+")
    
    for i in range(39*dl,40*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[13:15].iat[0],16)
        a1p=int(y[2].str[15:17].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd40.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)             
    
    file_compile()

def file_compile():
        
    filenames = ['/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd1.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd2.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd3.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd4.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd5.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd6.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd7.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd8.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd9.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd10.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd11.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd12.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd13.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd14.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd15.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd16.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd17.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd18.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd19.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd20.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd21.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd22.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd23.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd24.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd25.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd26.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd27.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd28.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd29.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd30.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd31.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd32.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd33.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd34.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd35.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd36.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd37.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd38.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd39.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_cmd40.txt']

    with open('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/01_PROCESSED_DATA/Position_Command.txt', 'w') as outfile:
        for fname in filenames:
            with open(fname) as infile:
                outfile.write(infile.read())
    os.remove(r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/rawcmd.log")
          
    
    
    
p1 = mp.Process(target = proc_cmd1)
p2 = mp.Process(target = proc_cmd2)
p3 = mp.Process(target = proc_cmd3)
p4 = mp.Process(target = proc_cmd4)
p5 = mp.Process(target = proc_cmd5)
p6 = mp.Process(target = proc_cmd6)
p7 = mp.Process(target = proc_cmd7)
p8 = mp.Process(target = proc_cmd8)
p9 = mp.Process(target = proc_cmd9)
p10 = mp.Process(target = proc_cmd10)
p11 = mp.Process(target = proc_cmd11)
p12 = mp.Process(target = proc_cmd12)
p13 = mp.Process(target = proc_cmd13)
p14 = mp.Process(target = proc_cmd14)
p15 = mp.Process(target = proc_cmd15)
p16 = mp.Process(target = proc_cmd16)
p17 = mp.Process(target = proc_cmd17)
p18 = mp.Process(target = proc_cmd18)
p19 = mp.Process(target = proc_cmd19)
p20 = mp.Process(target = proc_cmd20)
p21 = mp.Process(target = proc_cmd21)
p22 = mp.Process(target = proc_cmd22)
p23 = mp.Process(target = proc_cmd23)
p24 = mp.Process(target = proc_cmd24)
p25 = mp.Process(target = proc_cmd25)
p26 = mp.Process(target = proc_cmd26)
p27 = mp.Process(target = proc_cmd27)
p28 = mp.Process(target = proc_cmd28)
p29 = mp.Process(target = proc_cmd29)
p30 = mp.Process(target = proc_cmd30)
p31 = mp.Process(target = proc_cmd31)
p32 = mp.Process(target = proc_cmd32)
p33 = mp.Process(target = proc_cmd33)
p34 = mp.Process(target = proc_cmd34)
p35 = mp.Process(target = proc_cmd35)
p36 = mp.Process(target = proc_cmd36)
p37 = mp.Process(target = proc_cmd37)
p38 = mp.Process(target = proc_cmd38)
p39 = mp.Process(target = proc_cmd39)
p40 = mp.Process(target = proc_cmd40)
                
p1.start()
p2.start()
p3.start()
p4.start()       
p5.start()
p6.start()
p7.start()
p8.start()
p9.start()       
p10.start()
p11.start()
p12.start()
p13.start()
p14.start()       
p15.start()
p16.start()
p17.start()
p18.start()
p19.start()       
p20.start()
p21.start()
p22.start()
p23.start()
p24.start()
p25.start()
p26.start()
p27.start()
p28.start()
p29.start()
p30.start()
p31.start()
p32.start()
p33.start()
p34.start()
p35.start()
p36.start()
p37.start()
p38.start()
p39.start()
p40.start()
