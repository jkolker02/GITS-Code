#!/usr/bin/env python3

import multiprocessing as mp
import csv
import pandas
import shutil
import os
import time
import matplotlib.pyplot as plt
from decimal import*


d=pandas.read_csv(r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/rawfdbk.log", header=None, delim_whitespace=True)
d=pandas.DataFrame(d)
dl=len(d.index)
dl=int(dl/40)

def proc_fdbk1():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk1.txt","w+")
    
    for i in range(1,dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk1.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
    
def proc_fdbk2():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk2.txt","w+")
    
    for i in range(dl,2*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk2.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk3():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk3.txt","w+")
    
    for i in range(2*dl,3*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk3.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)            

def proc_fdbk4():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk4.txt","w+")
    
    for i in range(3*dl,4*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk4.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk5():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk5.txt","w+")
    
    for i in range(4*dl,5*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk5.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_fdbk6():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk6.txt","w+")
    
    for i in range(5*dl,6*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk6.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_fdbk7():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk7.txt","w+")
    
    for i in range(6*dl,7*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk7.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_fdbk8():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk8.txt","w+")
    
    for i in range(7*dl,8*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk8.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_fdbk9():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk9.txt","w+")
    
    for i in range(8*dl,9*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk9.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_fdbk10():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk10.txt","w+")
    
    for i in range(9*dl,10*dl):
     
        y=d.loc[[i]]
        y1=(y[2].str[0:8]).iat[0]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk10.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_fdbk11():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk11.txt","w+")
    
    for i in range(10*dl,11*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk11.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_fdbk12():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk12.txt","w+")
    
    for i in range(11*dl,12*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk12.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_fdbk13():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk13.txt","w+")
    
    for i in range(12*dl,13*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk13.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_fdbk14():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk14.txt","w+")
    
    for i in range(13*dl,14*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk14.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_fdbk15():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk15.txt","w+")
    
    for i in range(14*dl,15*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk15.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_fdbk16():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk16.txt","w+")
    
    for i in range(15*dl,16*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk16.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_fdbk17():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk17.txt","w+")
    
    for i in range(16*dl,17*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk17.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_fdbk18():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk18.txt","w+")
    
    for i in range(17*dl,18*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk18.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)

def proc_fdbk19():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk19.txt","w+")
    
    for i in range(18*dl,19*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk19.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk20():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk20.txt","w+")
    
    for i in range(19*dl,20*dl):
    
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk20.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk21():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk21.txt","w+")
    
    for i in range(20*dl,21*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk21.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk22():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk22.txt","w+")
    
    for i in range(21*dl,22*dl):
     
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk22.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk23():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk23.txt","w+")
    
    for i in range(22*dl,23*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk23.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk24():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk24.txt","w+")
    
    for i in range(23*dl,24*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk24.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk25():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk25.txt","w+")
    
    for i in range(24*dl,25*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk25.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk26():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk26.txt","w+")
    
    for i in range(25*dl,26*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk26.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk27():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk27.txt","w+")
    
    for i in range(26*dl,27*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk27.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk28():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk28.txt","w+")
    
    for i in range(27*dl,28*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk28.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk29():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk29.txt","w+")
    
    for i in range(28*dl,29*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk29.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk30():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk30.txt","w+")
    
    for i in range(29*dl,30*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk30.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk31():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk31.txt","w+")
    
    for i in range(30*dl,31*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk31.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk32():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk32.txt","w+")
    
    for i in range(31*dl,32*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk32.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk33():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk33.txt","w+")
    
    for i in range(32*dl,33*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk33.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk34():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk34.txt","w+")
    
    for i in range(33*dl,34*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk34.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk35():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk35.txt","w+")
    
    for i in range(34*dl,35*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk35.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk36():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk36.txt","w+")
    
    for i in range(35*dl,36*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk36.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk37():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk37.txt","w+")
    
    for i in range(36*dl,37*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk37.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk38():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk38.txt","w+")
    
    for i in range(37*dl,38*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk38.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk39():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk39.txt","w+")
    
    for i in range(38*dl,39*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk39.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)
            
def proc_fdbk40():
    global dl
    global d
    
    newf=open("/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk40.txt","w+")
    
    for i in range(39*dl,40*dl):
                
        y=d.loc[[i]]
        a0=(y[0].str[7:18].iat[0])
        a1=int(y[2].str[17:19].iat[0],16)
        a1p=int(y[2].str[19:21].iat[0],16)
        if a1p == 0:
            a1 = round(a1/250*100/4+0,2)
        elif a1p == 1:
            a1 = round(a1/244*100/4+25,2)
        elif a1p == 2:
            a1 = round(a1/238*100/4+50,2)
        elif a1p == 3:
            a1 = round(a1/232*100/4+75,2)

        ids=[[0,1]]
        ids=pandas.DataFrame(ids)
        idsfm=ids.replace({0:[0]},{0:[str(a0)]})
        idsfm=idsfm.replace({1:[1]},{1:[str(a1)]})
        
        with open ('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk40.txt','a') as data:
            idsfm.to_csv(data, header=False, index=False)             
    
    file_compile()

def file_compile():
        
    filenames = ['/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk1.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk2.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk3.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk4.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk5.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk6.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk7.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk8.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk9.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk10.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk11.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk12.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk13.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk14.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk15.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk16.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk17.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk18.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk19.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk20.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk21.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk22.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk23.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk24.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk25.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk26.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk27.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk28.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk29.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk30.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk31.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk32.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk33.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk34.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk35.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk36.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk37.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk38.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk39.txt',
                 '/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/Buffer/proc_fdbk40.txt']

    with open('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/01_PROCESSED_DATA/Position_Feedback.txt', 'w') as outfile:
        for fname in filenames:
            with open(fname) as infile:
                outfile.write(infile.read())
    
    os.remove(r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 6847R005/data_temp/rawfdbk.log")
          
           
            
            
#Function used to process data during recording
p1 = mp.Process(target = proc_fdbk1)
p2 = mp.Process(target = proc_fdbk2)
p3 = mp.Process(target = proc_fdbk3)
p4 = mp.Process(target = proc_fdbk4)
p5 = mp.Process(target = proc_fdbk5)
p6 = mp.Process(target = proc_fdbk6)
p7 = mp.Process(target = proc_fdbk7)
p8 = mp.Process(target = proc_fdbk8)
p9 = mp.Process(target = proc_fdbk9)
p10 = mp.Process(target = proc_fdbk10)
p11 = mp.Process(target = proc_fdbk11)
p12 = mp.Process(target = proc_fdbk12)
p13 = mp.Process(target = proc_fdbk13)
p14 = mp.Process(target = proc_fdbk14)
p15 = mp.Process(target = proc_fdbk15)
p16 = mp.Process(target = proc_fdbk16)
p17 = mp.Process(target = proc_fdbk17)
p18 = mp.Process(target = proc_fdbk18)
p19 = mp.Process(target = proc_fdbk19)
p20 = mp.Process(target = proc_fdbk20)
p21 = mp.Process(target = proc_fdbk21)
p22 = mp.Process(target = proc_fdbk22)
p23 = mp.Process(target = proc_fdbk23)
p24 = mp.Process(target = proc_fdbk24)
p25 = mp.Process(target = proc_fdbk25)
p26 = mp.Process(target = proc_fdbk26)
p27 = mp.Process(target = proc_fdbk27)
p28 = mp.Process(target = proc_fdbk28)
p29 = mp.Process(target = proc_fdbk29)
p30 = mp.Process(target = proc_fdbk30)
p31 = mp.Process(target = proc_fdbk31)
p32 = mp.Process(target = proc_fdbk32)
p33 = mp.Process(target = proc_fdbk33)
p34 = mp.Process(target = proc_fdbk34)
p35 = mp.Process(target = proc_fdbk35)
p36 = mp.Process(target = proc_fdbk36)
p37 = mp.Process(target = proc_fdbk37)
p38 = mp.Process(target = proc_fdbk38)
p39 = mp.Process(target = proc_fdbk39)
p40 = mp.Process(target = proc_fdbk40)
                
p1.start()
p2.start()
p3.start()
p4.start()       
p5.start()
p6.start()
p7.start()
p8.start()
p9.start()       
p10.start()
p11.start()
p12.start()
p13.start()
p14.start()       
p15.start()
p16.start()
p17.start()
p18.start()
p19.start()       
p20.start()
p21.start()
p22.start()
p23.start()
p24.start()
p25.start()
p26.start()
p27.start()
p28.start()
p29.start()
p30.start()
p31.start()
p32.start()
p33.start()
p34.start()
p35.start()
p36.start()
p37.start()
p38.start()
p39.start()
p40.start()

