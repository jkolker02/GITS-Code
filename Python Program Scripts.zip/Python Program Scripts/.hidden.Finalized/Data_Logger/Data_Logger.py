#!/usr/bin/env python3

import os

os.system("/home/pi/Desktop/daqhats/examples/c/mcc118/data_logger/logger/logger")

