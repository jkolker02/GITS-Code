#MCC 152 Stepper Script

import time
from daqhats_utils import select_hat_device, enum_mask_to_string, chan_list_to_mask
from daqhats import mcc118, mcc152, OptionFlags, HatIDs, HatError

values = mcc152.dio_output_read_port()
values |= 0x05
mcc152.dio_output_write_port(values)