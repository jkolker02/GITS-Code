#!/usr/bin/env python3

from __future__ import print_function
from tkinter import *
from decimal import*
import tkinter as tk
import can
import time
import os
import csv
import pandas
import itertools

pandas.set_option('display.max_colwidth',-1)


#Setup the GUI Window
GUI = Tk()

GUI.grid_rowconfigure(1, minsize=20)
GUI.grid_rowconfigure(2, minsize=20)
GUI.grid_rowconfigure(3, minsize=20)
GUI.grid_rowconfigure(4, minsize=20)
GUI.grid_rowconfigure(5, minsize=20)
GUI.grid_rowconfigure(6, minsize=20)
GUI.grid_rowconfigure(7, minsize=20)
GUI.grid_rowconfigure(8, minsize=20)


GUI.grid_columnconfigure(0, minsize=50)
GUI.grid_columnconfigure(4, minsize=15)

GUI.configure(background='honeydew4')
GUI.title('CAN Control Module - SONCEBOZ "5843R1008" Network')


#initial variable output state on start-up
slider_state = DISABLED
value = 0
x=0
y=0
cyclesi=0
cyclesf=0
cyclesicust=0
cyclesfcust=0
fine=0
course=0
MANi=1
customi=1
running = False
runningII = False
runningIII = False
z=False
cyclescust=None
cyclescusts=None
b=None
bI=None
a="..."
aI="..."
c="..."




#This command enables communication with the PiCAN board and network - bitrate needs to match network
def CAN_cmd():
    global z
    
    if z is False:
        z=True
        mycmd = 'sudo /sbin/ip link set can0 up type can bitrate 250000'
        os.system(mycmd)
        
        Enable_CAN["background"] = str('green')
        Enable_CAN["activebackground"] = str('green')
        
        b = 'CAN NETWORK IS RUNNING...'
        S = tk.Scrollbar(GUI)
        T = tk.Text(GUI, height=1, width=84, fg='green')
        T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
        S.config(command=T.yview)
        T.config(yscrollcommand=S.set)
        T.insert(tk.END, b)
    else:
        z=False
        mycmd = 'sudo /sbin/ip link set can0 down'
        os.system(mycmd)
        
        runningII = False
        slider.set(0)
        slider["state"] = "disabled"
        
        Enable_CAN["background"] = str('#d9d9d9')
        Enable_CAN["activebackground"] = str('#ececec')
        
        Enable_Manual["background"] = str('#d9d9d9')
        Enable_Manual["activebackground"] = str('#ececec')
        
        b = 'CAN NETWORK IS NOT ENABLED...'
        S = tk.Scrollbar(GUI)
        T = tk.Text(GUI, height=1, width=84, fg='red')
        T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
        S.config(command=T.yview)
        T.config(yscrollcommand=S.set)
        T.insert(tk.END, b)
          
    

#This command performs the learn cycle for the actuator - time.sleep is how often the message is sent
def Learn_cmd():
    global z
    
    if z is True and runningII is False:
        Learn["background"] = str('orange')
        Learn["activebackground"] = Learn.cget("background")
        
        b = 'LEARN CYCLE STARTED...'
        S = tk.Scrollbar(GUI)
        T = tk.Text(GUI, height=1, width=84, fg='orange')
        T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
        S.config(command=T.yview)
        T.config(yscrollcommand=S.set)
        T.insert(tk.END, b)
        
        Learn.update_idletasks()
        
        Learn_cmdI()

    elif runningII is True and z is True:
        b = 'OTHER TESTS ARE CURRENTLY ACTIVE - NO LEARN AVAILABLE...'
        S = tk.Scrollbar(GUI)
        T = tk.Text(GUI, height=1, width=84, fg='red')
        T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
        S.config(command=T.yview)
        T.config(yscrollcommand=S.set)
        T.insert(tk.END, b)
        
    else:
        b = 'CAN NETWORK IS NOT ENABLED...'
        S = tk.Scrollbar(GUI)
        T = tk.Text(GUI, height=1, width=84, fg='gray')
        T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
        S.config(command=T.yview)
        T.config(yscrollcommand=S.set)
        T.insert(tk.END, b)

        
def Learn_cmdI():
    global z
    
    if  z is True:
        i=0
        
        while i < 250:
            bus = can.interface.Bus(channel='can0', bustype='socketcan_native')
            msg = can.Message(arbitration_id=0x18FF2700, data=[1, 2, 0, 0, 0, 0, 0, 0], extended_id=True)
            bus.send(msg)
            time.sleep(0.010)
            i+=1
            #print(i)
        w=0
        while w < 300:
            bus = can.interface.Bus(channel='can0', bustype='socketcan_native')
            msg = can.Message(arbitration_id=0x18FF2700, data=[1, 3, 0, 0, 0, 0, 0, 0], extended_id=True)
            bus.send(msg)
            time.sleep(0.010)
            w+=1
            #print(z)
        
        Learn["background"] = str('#d9d9d9')
        Learn["activebackground"] = str('#ececec')
        
        b = 'CAN NETWORK IS RUNNING...'
        S = tk.Scrollbar(GUI)
        T = tk.Text(GUI, height=1, width=84, fg='green')
        T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
        S.config(command=T.yview)
        T.config(yscrollcommand=S.set)
        T.insert(tk.END, b)
               
    
        
#This command sets the position of the actuator using a minor(x) and major value(y)
def Position_cmd():
    global z
    
    if  z is True and runningII is False:
        b = 'POSITION CYCLE STARTED...'
        S = tk.Scrollbar(GUI)
        T = tk.Text(GUI, height=1, width=84, fg='orange')
        T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
        S.config(command=T.yview)
        T.config(yscrollcommand=S.set)
        T.insert(tk.END, b)
        T.update_idletasks()

        Position["background"] = str('orange')
        Position["activebackground"] = str('orange')
        
        Position.update_idletasks()
        
        y=0
    
        while y <= 3:
            x=0
        
            while x <= 237:
                i=0
            
                while i < 1:
                    bus = can.interface.Bus(channel='can0', bustype='socketcan_native')
                    msg = can.Message(arbitration_id=0x18FF2700, data=[1, 0, x, y, 0, 0, 0, 0], extended_id=True)
                    bus.send(msg)
                    time.sleep(0.020)
                    i+=1
        
                x+=29
                #print(y,x)
            
            y+=1
    
        y=3
        while y > -1:
            x=237
        
            while x >= 0:
                i=0
        
                while i < 1:
                    bus = can.interface.Bus(channel='can0', bustype='socketcan_native')
                    msg = can.Message(arbitration_id=0x18FF2700, data=[1, 0, x, y, 0, 0, 0, 0], extended_id=True)
                    bus.send(msg)
                    time.sleep(0.020)
                    i+=1
        
                x-=29
                #print(y,x)
            
            y-=1
       
        Position["background"] = str('#d9d9d9')
        Position["activebackground"] = str("#ececec")
        
        b = 'CAN NETWROK IS RUNNING...'
        S = tk.Scrollbar(GUI)
        T = tk.Text(GUI, height=1, width=84, fg='green')
        T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
        S.config(command=T.yview)
        T.config(yscrollcommand=S.set)
        T.insert(tk.END, b)
        T.update_idletasks()

    elif runningII is True and  z is True:
        b = 'OTHER TESTS ARE CURRENTLY ACTIVE - NO POSITION CYCLE AVAILABLE...'
        S = tk.Scrollbar(GUI)
        T = tk.Text(GUI, height=1, width=84, fg='blue')
        T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
        S.config(command=T.yview)
        T.config(yscrollcommand=S.set)
        T.insert(tk.END, b)    

    else:
        b = 'CAN NETWORK IS NOT ENABLED...'
        S = tk.Scrollbar(GUI)
        T = tk.Text(GUI, height=1, width=84, fg='red')
        T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
        S.config(command=T.yview)
        T.config(yscrollcommand=S.set)
        T.insert(tk.END, b)

#Function to start manual output      
def start_manual_func():
    global runningII
    global slider_state
    global z
    
    if  z is True:
        runningII = True
        running = False
        slider["state"] = "normal"
        manual_func()
    
        Enable_Manual["background"] = str('orange')
        Enable_Manual["activebackground"] = Enable_Manual.cget("background")
        b = 'MANUAL POSITION COMMAND STARTED...'
        S = tk.Scrollbar(GUI)
        T = tk.Text(GUI, height=1, width=84, fg='orange')
        T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
        S.config(command=T.yview)
        T.config(yscrollcommand=S.set)
        T.insert(tk.END, b)
        Position.update_idletasks()
    
    else:
        b = 'CAN NETWORK IS NOT ENABLED...'
        S = tk.Scrollbar(GUI)
        T = tk.Text(GUI, height=1, width=73, fg='brown')
        T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
        S.config(command=T.yview)
        T.config(yscrollcommand=S.set)
        T.insert(tk.END, b)

#Function to end manual output
def stop_manual_func():
    global runningII
    global slider_state
    
    if  z is True:
        runningII = False
        slider.set(0)
        slider["state"] = "disabled"
        
        Enable_Manual["background"] = str('#d9d9d9')
        Enable_Manual["activebackground"] = str('#ececec')
        b = 'CAN NETWORK IS RUNNING...'
        S = tk.Scrollbar(GUI)
        T = tk.Text(GUI, height=1, width=84, fg='green')
        T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
        S.config(command=T.yview)
        T.config(yscrollcommand=S.set)
        T.insert(tk.END, b)
        Position.update_idletasks()
        
    
    else:
        b = 'CAN NETWORK IS NOT ENABLED...'
        S = tk.Scrollbar(GUI)
        T = tk.Text(GUI, height=1, width=84, fg='black')
        T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
        S.config(command=T.yview)
        T.config(yscrollcommand=S.set)
        T.insert(tk.END, b)
        
#Function to control manual output
def manual_func():
    global runningII
    global running
    global slider
    global value
    global x
    global y
        
    if runningII and  z is True:
        running = False
        value=slider.get()
        if 0<= value <= 25:
            y=int(0)
            x=int(value/25*250)
        elif 25< value <= 50:
            y=int(1)
            x=int((value-25)/25*244)
        elif 50< value <=75:
            y=int(2)
            x=int((value-50)/25*238)
        elif 75< value <=100:
            y=int(3)
            x=int((value-75)/25*232)
            
        #print(x,y)
        bus = can.interface.Bus(channel='can0', bustype='socketcan_native')
        msg = can.Message(arbitration_id=0x18FF2700, data=[1, 0, x, y, 0, 0, 0, 0], extended_id=True)
        i=0
        while i < 1:
                bus.send(msg)
                time.sleep(0.010)
                i+=1
        
        slider.update_idletasks()
        
    GUI.after(5,manual_func)        
        


#This command controls the start/stop of the MAN life cycle
def MAN_cmd():
    global z
    global MANi
    global running, runningII, runningIII
    
    if  z is True and runningII is False and running is False:
        MANi +=1
        
    if (MANi % 2) == 0:
        MAN_Life["background"] = str('orange')
        MAN_Life["activebackground"] = MAN_Life.cget("background")
        b = 'MAN LIFE CYCLES RUNNING... CURRENT COUNT: '+str(cyclesi)+'/'+str(cyclesf)
        S = tk.Scrollbar(GUI)
        T = tk.Text(GUI, height=1, width=84, fg='DeepPink4')
        T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
        S.config(command=T.yview)
        T.config(yscrollcommand=S.set)
        T.insert(tk.END, b)
        Position.update_idletasks()
    else:
        MAN_Life["background"] = str('#d9d9d9')
        MAN_Life["activebackground"] = str("#ececec")
        MAN_Life.update_idletasks()
        runningIII=False
        
        
    if  z is False:
        MAN_Life["background"] = str('#d9d9d9')
        MAN_Life["activebackground"] = str("#ececec")
        b = 'CAN NETWORK IS NOT ENABLED...'
        S = tk.Scrollbar(GUI)
        T = tk.Text(GUI, height=1, width=84, fg='purple')
        T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
        S.config(command=T.yview)
        T.config(yscrollcommand=S.set)
        T.insert(tk.END, b)
        
    if running is True or runningII is True:
        MAN_Life["background"] = str('#d9d9d9')
        MAN_Life["activebackground"] = str("#ececec")
        b = 'OTHER TESTS ARE CURRENTLY ACTIVE - NO MAN CYCLES...'
        S = tk.Scrollbar(GUI)
        T = tk.Text(GUI, height=1, width=84, fg='brown')
        T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
        S.config(command=T.yview)
        T.config(yscrollcommand=S.set)
        T.insert(tk.END, b)
        
#Function to define the desired cycles
def MAN_cycles_func():
    global cyclesf
    global cyclesi
    
        
    cyclesf = int(cycles.get())
    
    b = 'MAN LIFE CYCLES SET TO '+str(cyclesf)+'... ' 'CURRENT COUNT '+str(cyclesi)+'/'+str(cyclesf)
    S = tk.Scrollbar(GUI)
    T = tk.Text(GUI, height=1, width=84, fg='brown')
    T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
    S.config(command=T.yview)
    T.config(yscrollcommand=S.set)
    T.insert(tk.END, b)
    cycles.delete(0,'end')

#This command sets the position of the actuator using a minor(x) and major value(y)
def MAN_Life_func():
    global z
    global cyclesi, cyclesf
    global MANi
    global running, runningII, runningIII
    
    if (MANi % 2) == 0:
        runningIII=True
        
        if cyclesi < cyclesf:
            #Part one itteration one
            for i in range(0,3):
                for _ in itertools.repeat(None,15):
                    bus = can.interface.Bus(channel='can0', bustype='socketcan_native')
                    msg = can.Message(arbitration_id=0x18FF2700, data=[1, 0, 232, 3, 0, 0, 0, 0], extended_id=True)
                    bus.send(msg)
                    time.sleep(0.020)
                
                for _ in itertools.repeat(None,15):
                    bus = can.interface.Bus(channel='can0', bustype='socketcan_native')
                    msg = can.Message(arbitration_id=0x18FF2700, data=[1, 0, 185, 3, 0, 0, 0, 0], extended_id=True)
                    bus.send(msg)
                    time.sleep(0.020)
                   
                for _ in itertools.repeat(None,15):
                    bus = can.interface.Bus(channel='can0', bustype='socketcan_native')
                    msg = can.Message(arbitration_id=0x18FF2700, data=[1, 0, 232, 3, 0, 0, 0, 0], extended_id=True)
                    bus.send(msg)
                    time.sleep(0.020)    
                        
                for _ in itertools.repeat(None,15):
                    bus = can.interface.Bus(channel='can0', bustype='socketcan_native')
                    msg = can.Message(arbitration_id=0x18FF2700, data=[1, 0, 0, 0, 0, 0, 0, 0], extended_id=True)
                    bus.send(msg)
                    time.sleep(0.020)
                        
                for _ in itertools.repeat(None,15):
                    bus = can.interface.Bus(channel='can0', bustype='socketcan_native')
                    msg = can.Message(arbitration_id=0x18FF2700, data=[1, 0, 232, 3, 0, 0, 0, 0], extended_id=True)
                    bus.send(msg)
                    time.sleep(0.020)
                
                        
            #Part two itteration
            for i in range(0,2):
                for _ in itertools.repeat(None,15):
                    bus = can.interface.Bus(channel='can0', bustype='socketcan_native')
                    msg = can.Message(arbitration_id=0x18FF2700, data=[1, 0, 232, 3, 0, 0, 0, 0], extended_id=True)
                    bus.send(msg)
                    time.sleep(0.020)
                        
                for _ in itertools.repeat(None,15):
                    bus = can.interface.Bus(channel='can0', bustype='socketcan_native')
                    msg = can.Message(arbitration_id=0x18FF2700, data=[1, 0, 0, 0, 0, 0, 0, 0], extended_id=True)
                    bus.send(msg)
                    time.sleep(0.020)        
               
                        
            #Part three
            for i in range(0,2):       
                for _ in itertools.repeat(None,15):
                        bus = can.interface.Bus(channel='can0', bustype='socketcan_native')
                        msg = can.Message(arbitration_id=0x18FF2700, data=[1, 0, 185, 3, 0, 0, 0, 0], extended_id=True)
                        bus.send(msg)
                        time.sleep(0.020)
                            
                for _ in itertools.repeat(None,15):
                        bus = can.interface.Bus(channel='can0', bustype='socketcan_native')
                        msg = can.Message(arbitration_id=0x18FF2700, data=[1, 0, 139, 3, 0, 0, 0, 0], extended_id=True)
                        bus.send(msg)
                        time.sleep(0.020)
                        
            for _ in itertools.repeat(None,15):
                    bus = can.interface.Bus(channel='can0', bustype='socketcan_native')
                    msg = can.Message(arbitration_id=0x18FF2700, data=[1, 0, 185, 3, 0, 0, 0, 0], extended_id=True)
                    bus.send(msg)
                    time.sleep(0.020)
                        
            for _ in itertools.repeat(None,15):
                    bus = can.interface.Bus(channel='can0', bustype='socketcan_native')
                    msg = can.Message(arbitration_id=0x18FF2700, data=[1, 0, 0, 0, 0, 0, 0, 0], extended_id=True)
                    bus.send(msg)
                    time.sleep(0.020)
                    
            cyclesi +=1
            
            b = 'MAN LIFE CYCLES RUNNING... CURRENT COUNT: '+str(cyclesi)+'/'+str(cyclesf)
            S = tk.Scrollbar(GUI)
            T = tk.Text(GUI, height=1, width=84, fg='black')
            T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
            S.config(command=T.yview)
            T.config(yscrollcommand=S.set)
            T.insert(tk.END, b)
            T.update_idletasks()
            
        else:
            b = 'MAN LIFE CYCLES ARE COMPLETE... GREAT JOB!!!!'
            S = tk.Scrollbar(GUI)
            T = tk.Text(GUI, height=1, width=84, fg='black')
            T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
            S.config(command=T.yview)
            T.config(yscrollcommand=S.set)
            T.insert(tk.END, b)
            MAN_Life["background"] = str('#d9d9d9')
            MAN_Life["activebackground"] = str("#ececec")
            MANi=1
            cyclesi=0
            runningIII=False
            
    GUI.after(1,MAN_Life_func)

#Function to define the desired custom cycles
def Custom_Cycles_func():
    global cyclesfcust
    global cyclesicust
    global cyclescust
    global cyclescusts
    global cycles
           
    cyclescust = cycles_cust.get()
    cyclescust = map(str, cyclescust.split(','))
    cyclescust= [cyclescust]
    cyclescust=pandas.DataFrame(cyclescust)
    cyclescusts=cyclescust.loc[[0],1:]
    cyclescusts=cyclescusts.to_string(header=False,index=False,index_names=False).split('\n')
    cyclescusts=[','.join(ele.split()) for ele in cyclescusts]
    cyclesfcust=int(cyclescust[0])
    
    b = 'CUSTOM CYCLES SET TO: '+str(cyclesfcust)+'... ' 'CURRENT COUNT: '+str(cyclesicust)+'/'+str(cyclesfcust)+'...  STEPS:'+str(cyclescusts)
    S = tk.Scrollbar(GUI)
    T = tk.Text(GUI, height=1, width=84, fg='brown')
    T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
    S.config(command=T.yview)
    T.config(yscrollcommand=S.set)
    T.insert(tk.END, b)
    cycles_cust.delete(0,'end')

#This command controls the start/stop of the custom cycle operation
def Custom_cmd():
    global z
    global customi
    global cyclesfcust
    global cyclesicust
    global cyclescusts
    global running, runningII, runningIII
    
    if  z is True and runningII is False and runningIII is False:
        customi +=1
        
    if (customi % 2) == 0:
        Custom_Cycle["background"] = str('orange')
        Custom_Cycle["activebackground"] = Custom_Cycle.cget("background")
        b = 'CUSTOM CYCLES SET TO: '+str(cyclesfcust)+'... ' 'CURRENT COUNT: '+str(cyclesicust)+'/'+str(cyclesfcust)+'...  STEPS:'+str(cyclescusts)
        S = tk.Scrollbar(GUI)
        T = tk.Text(GUI, height=1, width=84, fg='DeepPink4')
        T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
        S.config(command=T.yview)
        T.config(yscrollcommand=S.set)
        T.insert(tk.END, b)
        T.update_idletasks()
    else:
        Custom_Cycle["background"] = str('#d9d9d9')
        Custom_Cycle["activebackground"] = str("#ececec")
        Custom_Cycle.update_idletasks()
        running=False
        
    if  z is False:
        Custom_Cycle["background"] = str('#d9d9d9')
        Custom_Cycle["activebackground"] = str("#ececec")
        
        b = 'CAN NETWORK IS NOT ENABLED...'
        S = tk.Scrollbar(GUI)
        T = tk.Text(GUI, height=1, width=84, fg='DeepPink2')
        T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
        S.config(command=T.yview)
        T.config(yscrollcommand=S.set)
        T.insert(tk.END, b)
        T.update_idletasks()
        
    if runningII is True or runningIII is True:
        Custom_Cycle["background"] = str('#d9d9d9')
        Custom_Cycle["activebackground"] = str("#ececec")
        b = 'OTHER TESTS ARE CURRENTLY ACTIVE - NO CUSTOM CYCLES AVAILABLE...'
        S = tk.Scrollbar(GUI)
        T = tk.Text(GUI, height=1, width=84, fg='orange')
        T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
        S.config(command=T.yview)
        T.config(yscrollcommand=S.set)
        T.insert(tk.END, b)
        T.update_idletasks()


#This command sets the position of the actuator using a minor(x) and major value(y)
def Custom_Cycle_func():
    global z
    global cyclesicust, cyclesfcust
    global customi
    global cyclescust
    global cyclescusts
    global fine
    global course
    global customl
    global running, runningII, runningIII
    
    if (customi % 2) == 0:
        running = True      
        if cyclesicust < cyclesfcust:
            
            customl=len(cyclescust.columns)
    
            for i in range(1,customl):
                
                value=Decimal(cyclescust[i].str[:].iat[0])
                
                if 0<= value <= 25:
                    course=int(0)
                    fine=int(value/25*250)
                elif 25< value <= 50:
                    course=int(1)
                    fine=int((value-25)/25*244)
                elif 50< value <=75:
                    course=int(2)
                    fine=int((value-50)/25*238)
                elif 75< value <=100:
                    course=int(3)
                    fine=int((value-75)/25*232)
                    
                for _ in itertools.repeat(None,15):
                    bus = can.interface.Bus(channel='can0', bustype='socketcan_native')
                    msg = can.Message(arbitration_id=0x18FF2700, data=[1, 0, fine, course, 0, 0, 0, 0], extended_id=True)
                    bus.send(msg)
                    time.sleep(0.020)
                    
            cyclesicust +=1
            
            b = 'CUSTOM CYCLES SET TO: '+str(cyclesfcust)+'... ' 'CURRENT COUNT: '+str(cyclesicust)+'/'+str(cyclesfcust)+'...  STEPS:'+str(cyclescusts)
            S = tk.Scrollbar(GUI)
            T = tk.Text(GUI, height=1, width=84, fg='DeepPink4')
            T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
            S.config(command=T.yview)
            T.config(yscrollcommand=S.set)
            T.insert(tk.END, b)
            T.update_idletasks()
            
        else:
            b = 'CUSTOM CYCLES ARE COMPLETE... GREAT JOB!!!!'
            S = tk.Scrollbar(GUI)
            T = tk.Text(GUI, height=1, width=84, fg='DeepPink4')
            T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
            S.config(command=T.yview)
            T.config(yscrollcommand=S.set)
            T.insert(tk.END, b)
            Custom_Cycle["background"] = str('#d9d9d9')
            Custom_Cycle["activebackground"] = str("#ececec")
            customi=1
            cyclesicust=0
            running=False
            
    GUI.after(1,Custom_Cycle_func)
    
    
#Function to shut down the CAN network and close the program
def exit_cmd():
    z=False
    mycmdI = 'sudo /sbin/ip link set can0 down'
    os.system(mycmdI)
    system_exit()
def system_exit():
    sys.exit()

        
#Buttons and Labels
    #Headers/titles - LABELS
Header= Label(GUI, text="CAN CONTROL - SONCEBOZ 5843R1008 - ELECTRIC ACTUATOR",background='honeydew4', font='Helvetica 16 bold underline').grid(row=0, column=0, columnspan=6, pady=10)

    #Enable CAN Communication - LABEL ENTRY
Enable_CAN = Label(GUI, text="Open CAN Network:",background='honeydew4', font = 'Helvetica 10 bold').grid(row=1, column=0, sticky=E, padx=10, pady=1)
Enable_CAN = Button(GUI, text='   CAN ENABLE    ', command=CAN_cmd, height = 1, width =20, borderwidth=.5, relief='solid')
Enable_CAN.grid(row=1, column=1, sticky=W)

b = 'CAN NETWORK IS NOT ENABLED...'
S = tk.Scrollbar(GUI)
T = tk.Text(GUI, height=1, width=84, fg='red')
T.grid(row=6, column=1, columnspan=6, sticky=W, pady=5)
S.config(command=T.yview)
T.config(yscrollcommand=S.set)
T.insert(tk.END, b)

    #Perform a Learn Cycle - BUTTON COMMAND
Learn = Label(GUI, text="Perform Learn:",background='honeydew4', font = 'Helvetica 10 bold').grid(row=2, column=0, sticky=E, padx=10, pady=1)
Learn = Button(GUI, text='   LEARN OPEN/CLOSE    ', command=Learn_cmd, height = 1, width =20, borderwidth=.5, relief='solid')
Learn.grid(row=2, column=1, sticky=W, pady=3)

    #Move the Actuator Open and the Closed - BUTTON COMMAND
Position = Label(GUI, text="Check Functionallity:",background='honeydew4', font = 'Helvetica 10 bold').grid(row=3, column=0, sticky=E, padx=10, pady=2)
Position = Button(GUI, text='  POSITION CYCLE (1x)  ', command=Position_cmd, height = 1, width =20, borderwidth=.5, relief='solid')
Position.grid(row=3, column=1, sticky=W)

    #Manual Command Start/Stop - BUTTON COMMAND
Enable_Manual = Button(GUI, text='Enable Manual Control', command = start_manual_func, height = 1, width =20, borderwidth=.5, relief='solid')
Enable_Manual.grid(row=3, column=2, sticky=W, padx=12)

Disable_Manual = Button(GUI, text='Disable Manual Control', command = stop_manual_func, height = 1, width =20, borderwidth=.5, relief='solid')
Disable_Manual.grid(row=3, column=3, padx=1, pady=2)
    
    #Manual Position Slider - SLIDER WIDGET
slider=Scale(GUI, from_=0, to=100, orient=HORIZONTAL, cursor='dot', label="Manual Position Control Settings - Percent of Full Stroke:", font='Helvetica 10 bold underline', repeatdelay=1, repeatinterval=1, resolution=0.50, background='firebrick4', sliderlength=10, borderwidth = 3, foreground='black',length=385, width=12, state=slider_state)
slider.grid(row=1,column=2, columnspan=4, rowspan=2, sticky=W, padx=10)

    #MAN Life Cycle - BUTTON COMMAND
MAN_Life = Label(GUI, text="MAN Life Cycle:",background='honeydew4', font = 'Helvetica 10 bold').grid(row=4, column=0, sticky=E, padx=10, pady=3)
MAN_Life = Button(GUI, text='LIFE CYCLE START/STOP', command=MAN_cmd, height = 1, width =20, borderwidth=.5, relief='solid')
MAN_Life.grid(row=4, column=1, sticky=W, pady=3)

    #MAN  Life Cycle Count - LABEL ENTRY
cycles_count = Button(GUI, text='ENTER # of LIFE CYCLES', command=MAN_cycles_func, height = 1, width =20, borderwidth=.5, relief='solid').grid(row=4, column=2, padx=12, sticky=W)
cycles = Entry(GUI, width = 23)
cycles.grid(row=4, column=3, ipady=3, padx=4, sticky=W)
cycles.bind('<Return>', (lambda event: MAN_cycles_func()))
cycles.bind('<KP_Enter>', (lambda event: MAN_cycles_func()))

    #Custom Cycle - BUTTON COMMAND
Custom_Cycle= Label(GUI, text="Custom Cycle:",background='honeydew4', font = 'Helvetica 10 bold').grid(row=5, column=0, sticky=E, padx=10, pady=3)
Custom_Cycle = Button(GUI, text='CUSTOM CYCLE START/STOP', command=Custom_cmd, height = 1, width =20, borderwidth=.5, relief='solid')
Custom_Cycle.grid(row=5, column=1, sticky=W, pady=3)

    #Custom Cycle Count - LABEL ENTRY
cycles_count_cust = Button(GUI, text='ENTER (Num,pos1,pos2,...)', command=Custom_Cycles_func, height = 1, width =20, borderwidth=.5, relief='solid').grid(row=5, column=2, padx=12, sticky=W)
cycles_cust = Entry(GUI, width = 23)
cycles_cust.grid(row=5, column=3, ipady=3, padx=4, sticky=W)
cycles_cust.bind('<Return>', (lambda event: Custom_Cycles_func()))
cycles_cust.bind('<KP_Enter>', (lambda event: Custom_Cycles_func()))



    #Program Exit - BUTTON COMMAND
ExitButton = tk.Button(GUI, text="EXIT NOW",command=exit_cmd, background='orangered4', highlightbackground='yellow', activebackground='orangered3', borderwidth=.5, relief='solid')
ExitButton.grid(row=7, column=3, sticky=E, padx=18)

GUI.after(1,Custom_Cycle_func)
GUI.after(1,MAN_Life_func)
GUI.mainloop()
