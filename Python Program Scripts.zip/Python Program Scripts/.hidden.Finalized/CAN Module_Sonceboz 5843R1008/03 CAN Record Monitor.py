#!/usr/bin/env python3

from __future__ import print_function
from time import sleep
from tkinter import *
import tkinter as tk
import multiprocessing as mp
from multiprocessing import Pool
import can
import time
import os
import csv
import pandas
import shutil
import numpy
import matplotlib.pyplot as plt
import subprocess
from decimal import*

pandas.set_option('display.max_colwidth',-1)

#Setup the GUI Window
GUI = Tk()

GUI.grid_rowconfigure(0, minsize=20)
GUI.grid_rowconfigure(1, minsize=10)
GUI.grid_rowconfigure(2, minsize=10)
GUI.grid_rowconfigure(3, minsize=10)
GUI.grid_rowconfigure(4, minsize=10)
GUI.grid_rowconfigure(5, minsize=10)
GUI.grid_rowconfigure(6, minsize=10)
GUI.grid_rowconfigure(7, minsize=10)
GUI.grid_rowconfigure(8, minsize=10)

GUI.grid_columnconfigure(0, minsize=38)
GUI.grid_columnconfigure(2, minsize=20)
GUI.grid_columnconfigure(3, minsize=20)
GUI.grid_columnconfigure(4, minsize=20)
GUI.grid_columnconfigure(5, minsize=20)
GUI.grid_columnconfigure(6, minsize=20)
GUI.grid_columnconfigure(7, minsize=20)
GUI.grid_columnconfigure(8, minsize=20)
GUI.grid_columnconfigure(9, minsize=20)
GUI.grid_columnconfigure(10, minsize=10)

GUI.configure(background='honeydew4')
GUI.title('CAN Record Monitor Module - SONCEBOZ "5843R1008" Network')


#initial output state on start-up
runningII = False
z = False
rec = False
one = None
two = None
cIIII = None
cI="CAN NETWORK DOWN..."
b="CAN NETWORK IS NOT ENABLED..."
varI = tk.DoubleVar()
varII = tk.DoubleVar()
varIII = tk.DoubleVar()
varIIII = tk.DoubleVar()
varV = tk.DoubleVar()
varr = tk.DoubleVar()
R2 = tk.StringVar()
R3 = tk.StringVar()
R4 = tk.StringVar()
R5 = tk.StringVar()
R10 = tk.StringVar()
varI.set(cI)
varII.set('')
varIII.set('')
varIIII.set('')
varV.set('')
varr.set(b)
a1 = a2 = a3 = a4 = a5 = a6 = a7 = a8 = a9 = a10 = None
rb2i = rb3i = rb4i = rb5i = rb10i=1
p1f = p2f = p3f = p4f = 1
datat=0
Trigger_Command_Processor = 0
Trigger_Feedback_Processor = 0
Trigger_Current_Processor = 0
Trigger_Temperature_Processor = 0

#This command enables communication with the PiCAN board and network - bitrate needs to match network
def CAN_cmd():
    global z
    global runningII
    
    if z is False:
        z=True
        mycmd = 'sudo /sbin/ip link set can0 up type can bitrate 250000'
        os.system(mycmd)
        
        Enable_CAN["background"] = str('green')
        Enable_CAN["activebackground"] = str('green')
        varI.set("CAN NETWORK IS RUNNI")
        varII.set("NG...")
        varIII.set('')
        varIIII.set('')
        varV.set('')
        varr.set("CAN NETWORK IS RUNNING...")
        
        
    else:
        z=False
        runningII=False
        mycmd = 'sudo /sbin/ip link set can0 down'
        os.system(mycmd)
        varI.set ("CAN NETWORK DOWN...")
        varII.set('')
        varIII.set('')
        varIIII.set('')
        varV.set('')
        varr.set("CAN NETWORK HAS BEEN DISABLED...")
    
        
        Enable_CAN["background"] = str('#d9d9d9')
        Enable_CAN["activebackground"] = str('#ececec')
        CAN_Full_Preview_On["background"] = str('#d9d9d9')
        CAN_Full_Preview_On["activebackground"] = str('#ececec')
        

#Function to log incoming CAN packets and display them in the GUI as a raw valuel
def Raw_CAN_Preview_func():
    global a
    global b
    global z
    global var
    
    if z is True:
        mycmdII = './candump can0 -L -n11 >"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5843R1008/data_temp/raw.log"'
        os.system(mycmdII)
    
        a=pandas.read_csv(r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5843R1008/data_temp/raw.log",header=None);
        b=a.to_string(index=False)
        b=b[2:]
        
        varr.set(b)
    else:
        varr.set("CAN NETWORK IS NOT ENABLED - NO PREVIEW...")

        
#Function to start manual output      
def Start_CAN_Preview_func():
    global runningII
    global z

    if z is True:
        runningII = True
        
        CAN_Full_Preview_On["background"] = str('orange')
        CAN_Full_Preview_On["activebackground"] = CAN_Full_Preview_On.cget("background")
        
        cI=pandas.read_csv(r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5843R1008/sort_temp/sort1.log")
        varI.set(cI)
        cII=pandas.read_csv(r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5843R1008/sort_temp/sort2.log",sep=',')
        cII=cII.to_string(index=False)
        varII.set(cII)
        cIII=pandas.read_csv(r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5843R1008/sort_temp/sort3.log",sep=',')
        cIII=cIII.to_string(index=False)
        varIII.set(cIII)
        cV=pandas.read_csv(r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5843R1008/sort_temp/sort5.log",sep=',')
        cV=cV.to_string(index=False)
        varV.set(cV)
        
    else:
        varI.set("CAN NETWORK DOWN  -")
        varII.set(" NOTHING TO S")
        varIII.set("TART...              ")
        

#Function to end manual output
def Stop_CAN_Preview_func():
    global runningII
    global slider_state
    global z
    
    if z is True:
        runningII = False
            
        CAN_Full_Preview_On["background"] = str('#d9d9d9')
        CAN_Full_Preview_On["activebackground"] = str('#ececec')
        varI.set("END TRANSLATION...")
        varII.set('')
        varIII.set('')
        varIIII.set('')
        varV.set('')
    else:
       varI.set("CAN NETWORK DOWN  -")
       varII.set(" NOTHING TO S")
       varIII.set("TOP...              ")
       
    

#Function to sort CAN packets and show occurance
def Translated_CAN_Preview_func():
    global aI
    global bI
    global z
    global a1,a2,a3,a4,a5,a6,a7,a8,a9,a10
    global RO,R1,R2,R3,R4,R5,R6,R7,R8,R9
    global runningII
    global var
    global cIIII
    global tici
    global datan, datat
    
            
    if runningII and z  is True:
        
        mycmdIII = './candump can0 -L -n5 >"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5843R1008/data_temp/raw.log"'
        os.system(mycmdIII)
        
        pandas.set_option('display.max_colwidth',-1)

        b=pandas.read_csv(r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5843R1008/sort_temp/sort4.log",sep=',')
        d=pandas.read_csv(r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5843R1008/data_temp/raw.log", header=None, delim_whitespace=True)

        b=pandas.DataFrame(b)
        d=pandas.DataFrame(d)
        
        for i in range(1,5):
            y=d.loc[[i]]
            y1=(y[2].str[0:8]).iat[0]
            
            if y1 == str('18FF2463'):
                a1=int(y[2].str[9:11].iat[0],16)
                if a1 == 0:
                    a1 = 'Unpowered'
                elif a1 == 1:
                    a1 = 'Position'
                elif a1 == 3:
                    a1 = 'MFaileSafe'
                elif a1 == 5:
                    a1 = 'EFailSafe'
                elif a1 == 6:
                    a1 = 'ReducedPerf'
                a2=int(y[2].str[11:13].iat[0],16)
                if a2 == 0:
                    a2 = 'NoTests'
                elif a2 == 1:
                    a2 = 'LearnClosed'
                elif a2 == 2:
                    a2 = 'LearnOpen'
                elif a2 == 3:
                    a2 = 'BrokenSpring'
                elif a2 == 4:
                    a2 = 'Hysteresis'
                elif a2 == 6:
                    a2 = 'StoreHistograms'
                elif a2 == 7:
                    a2 = 'ExtendedTests'
                a3=int(y[2].str[13:15].iat[0],16)
                if a3 == 0:
                    a3 = 'NoError'
                elif a3 == 1:
                    a3 = 'SupplyHigh'
                elif a3 == 2:
                    a3 = 'SupplyLow'
                elif a3 == 3:
                    a3 = 'RAM/ROM Error'
                elif a3 == 4:
                    a3 = 'Overtemp'
                elif a3 == 5:
                    a3 = 'EEPROMError'
                elif a3 == 6:
                    a3 = 'MotorEffortLim'    
                a4=int(y[2].str[15:17].iat[0],16)
                if a4 == 0:
                    a4 = 'NoError'
                elif a4 == 1:
                    a4 = 'LearnTimeout'
                elif a4 == 2:
                    a4 = 'GovernorDev'
                elif a4 == 3:
                    a4 = 'BrokenSpring'
                a5=int(y[2].str[17:19].iat[0],16)
                a5p=int(y[2].str[19:21].iat[0],16)
                if a5p == 0:
                    a5 = round(a5/250*100/4+0,2)
                elif a5p == 1:
                    a5 = round(a5/244*100/4+25,2)
                elif a5p == 2:
                    a5 = round(a5/238*100/4+50,2)
                elif a5p == 3:
                    a5 = round(a5/232*100/4+75,2)
                a6=int(y[2].str[21:23].iat[0],16)
                if a6 == 0:
                    a6 = 'NoError'
                elif a6 == 1:
                    a6 = 'ShortToBat'
                elif a6 == 2:
                    a6 = 'ShortToGnd'
                elif a6 == 5:
                    a6 = 'Implaus.'
                elif a6 == 6:
                    a6 = 'Range2Big'
                elif a6 == 7:
                    a6 = 'Range2Small'
                else:
                    a6 = 'Unknown'
            
            if y1 == str('18FF2563'):
                a7=round(int(y[2].str[9:11].iat[0],16)*.8-100,2)
                a8=int(y[2].str[11:13].iat[0],16)
                if a8 == 0:
                    a8 = 'NoError'
                elif a8 == 1:
                    a8 = 'Short2Bat'
                elif a8 == 2:
                    a8 = 'Short2Gnd'
                elif a8 == 5:
                    a8 = 'Implausible'
                a9=round(int(y[2].str[13:15].iat[0],16)-40,2)
                a10=int(y[2].str[15:17].iat[0],16)
                if a10 == 0:
                    a10 ='NoError'
                elif a10 == 1:
                    a10 = 'Short2Bat'
                elif a10 == 2:
                    a10 = 'Short2Gnd'
                elif a10 == 5:
                    a10 = 'Implaus.'
                else:
                    a10 = 'NoID'
            
        
            cIIII=b.replace({'TRANSLATED':[1,2,3,4,5,6,7,8,9,10]},{'TRANSLATED':[str(a1),str(a2),str(a3),str(a4),str(a5),str(a6),str(a7),str(a8),str(a9),str(a10)]})
            cIIII=cIIII.to_string(index=False)
            varIIII.set(cIIII)
            TIIII.update_idletasks()
    
    GUI.after(5,Translated_CAN_Preview_func)

#Function to sort CAN packets and show occurance
def Record_func():
    global p1f
    global p2f
    global p3f
    global p4f
    global runningII
    global z
      
    if runningII and z and rec is True:
    
        p1 = mp.Process(target = rec_cmd)
        p2 = mp.Process(target = rec_fdbk)
        p3 = mp.Process(target = rec_cur)
        p4 = mp.Process(target = rec_temp)
        
        p1.start()
        p2.start()
        p3.start()
        p4.start()
        
                   
    GUI.after(1,Record_func)
    
def rec_cmd():
    global p1f
    
    if R2.get() == '0':
        mycmdI = './candump can0,18FF2700:0000FFFF000000 -L -n200>>"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5843R1008/data_temp/rawcmd.log"'
        os.system(mycmdI)
        p1f=0
        
def rec_fdbk():
    global p2f
    
    if R3.get() == '0':
        mycmdII = './candump can0,18FF2463:000000FFFF00 -L -n200>>"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5843R1008/data_temp/rawfdbk.log"'
        os.system(mycmdII)
        p2f=0
        
def rec_cur():
    global p3f
     
    if R4.get() == '0':
        mycmdII = './candump can0,18FF2563:FF0000FFFF00 -L -n200>>"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5843R1008/data_temp/rawcur.log"'
        os.system(mycmdII)
        p3f=0
        
def rec_temp():
    global p4f
     
    if R5.get() == '0':
        mycmdII = './candump can0,18FF2563:FF0000FFFF00 -L -n18>>"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5843R1008/data_temp/rawtemp.log"'
        os.system(mycmdII)
        p4f=0
            
           

#Radio button control for on off function of recording    
def rb2_cmd():
    global rb2i

    if (rb2i % 2) == 0:
        Rb2.deselect()
        Rb2.update_idletasks()
                       
    rb2i +=1
    
def rb3_cmd():
    global rb3i

    if (rb3i % 2) == 0:
        Rb3.deselect()
        Rb3.update_idletasks()
                       
    rb3i +=1

def rb4_cmd():
    global rb4i

    if (rb4i % 2) == 0:
        Rb4.deselect()
        Rb4.update_idletasks()
                       
    rb4i +=1
    
def rb5_cmd():
    global rb5i

    if (rb5i % 2) == 0:
        Rb5.deselect()
        Rb5.update_idletasks()
                       
    rb5i +=1    

def rb10_cmd():
    global rb10i
    global rec
    global datan
    global datat
    global cIIII
    global Trigger_Command_Processor
    global Trigger_Feedback_Processor
    global Trigger_Current_Processor
    global Trigger_Temperature_Processor
     
    if z is True and runningII is True:
        if (rb10i % 2) == 0:
            Rb10.deselect()
            rec=False
            Rb10["background"] = str('honeydew4')
            Rb10["activebackground"] = str('honeydew4')
            Rb10.update_idletasks()
                        
            if Trigger_Command_Processor or Trigger_Feedback_Processor or Trigger_Current_Processor or Trigger_Temperature_Processor  == 1:
                p1 = mp.Process(target = Command_Processor)
                p2 = mp.Process(target = Feedback_Processor)
                p3 = mp.Process(target = Current_Processor)
                p4 = mp.Process(target = Temperature_Processor)
                
                if Trigger_Command_Processor == 1:
                    p1.start()
                if Trigger_Feedback_Processor == 1:
                    p2.start()
                if Trigger_Current_Processor == 1:
                    p3.start()
                if Trigger_Temperature_Processor == 1:
                    p4.start()
            

            
        else:
            rec=True
            
            Rb10["background"] = str('red')
            Rb10["activebackground"] = str('red')
            datat +=1
            
            if R2.get() == '0':
                Trigger_Command_Processor=1
                   
            if R3.get() == '0':
                Trigger_Feedback_Processor=1
                
            if R4.get() == '0':
                Trigger_Current_Processor=1
                
            if R5.get() == '0':
                Trigger_Temperature_Processor=1
                
            
        rb10i +=1

    if z is False:
        Rb10.deselect()
        varr.set("CAN NETWORK IS NOT ENABLED - NO PREVIEW...")
        varI.set("CAN NETWORK DOWN  -")
        varII.set(" NOTHING TO R")
        varIII.set("ECORD...              ")

    if runningII is False:
        Rb10.deselect()
        varr.set("TRANSLATING IS NOT ENABLED - CANNOT RECORD...")
        varI.set("TRANSLATING IS DOWN -")
        varII.set(" CANNOT RECO")
        varIII.set("RD...              ")
        
def Command_Processor():
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5843R1008/04 Command Processor.py"])  
    
def Feedback_Processor():
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5843R1008/05 Feedback Processor.py"])  
        
def Current_Processor():
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5843R1008/06 Current Processor.py"])  
          
def Temperature_Processor():
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5843R1008/07 Temperature Processor.py"])  

                           
    
#Function to shut down the CAN network and close the program
def exit_cmd():
    z=False
    mycmdI = 'sudo /sbin/ip link set can0 down'
    os.system(mycmdI)
    system_exit()
def system_exit():
    sys.exit()

        
#Buttons and Labels
    #Headers/titles - LABELS
Header= Label(GUI, text="CAN SNIFFER - SONCEBOZ 5843R1008 - ELECTRIC ACTUATOR",background='honeydew4', font='Helvetica 16 bold underline', anchor='center').grid(row=0, column=0, columnspan=20)

    #Enable CAN Communication - LABEL ENTRY
GUIFI = Frame(GUI, bg='honeydew4')
GUIFI.grid(row=7, column=9, sticky=E)

Enable_CAN = Button(GUIFI, text='   CAN ENABLE    ', command=CAN_cmd, height = 1, width =10, borderwidth=.5, relief='solid')
Enable_CAN.grid(row=1, column=1, sticky=W)

    #Enable ONE TIME FILE LOG - BUTTON COMMAND
CAN_Preview = Label(GUI, text="Raw CAN Preview:",background='honeydew4', font = 'Helvetica 11 bold underline').grid(row=1, column=1, sticky=W, pady=1)
CAN_Preview = Button(GUI, text='   REFRESH PREVIEW (10 Packets)   ', command=Raw_CAN_Preview_func, height = 1, width =25, borderwidth=.5, relief='solid').grid(row=3, column=1, sticky=W)

    #Log of Raw Incomming Can Packets - SCROLL WIDGET
Tr = Label(GUI, height=11, width=89, textvariable=varr, anchor=NW, justify=LEFT, bg='white',fg='blue')
Tr.grid(row=2, column=1, columnspan=11, sticky=W, pady=5)


    #Enable Continuous FILE LOG - BUTTON COMMAND
CAN_Full_Preview = Label(GUI, text="Translated CAN Packets:",background='honeydew4', font = 'Helvetica 11 bold underline').grid(row=5, column=1, sticky=W, pady=1)

GUIFII = Frame(GUI, bg='honeydew4')
GUIFII.grid(row=7, column=1, columnspan=2)

CAN_Full_Preview_On = Button(GUIFII, text='   START Translating   ', command= Start_CAN_Preview_func, height = 1, width =20, borderwidth=.5, relief='solid')
CAN_Full_Preview_On.grid(row=1, column=1, sticky=W)

CAN_Full_Preview_Off = Button(GUIFII, text='   STOP Translating   ', command= Stop_CAN_Preview_func, height = 1, width =20, borderwidth=.5, relief='solid')
CAN_Full_Preview_Off.grid(row=1, column=2, sticky=W)

    #Log of Sorted Incomming Can Packets - SCROLL WIDGET
GUIFIIII = Frame(GUI, bg='honeydew4')
GUIFIIII.grid(row=6, column=1, sticky=W, pady=5, columnspan= 11)

TI = Label(GUIFIIII, height=12, width=18, textvariable=varI, anchor=NW,justify=LEFT, bg='white',fg='green')
TI.grid(row=1, column=0, sticky=W)

TII = Label(GUIFIIII, height=12, width=11, textvariable=varII, anchor=NW,justify=LEFT, bg='white',fg='green')
TII.grid(row=1, column=1, sticky=W)

TIII = Label(GUIFIIII, height=12, width=27, textvariable=varIII, anchor=NW,justify=LEFT, bg='white',fg='green')
TIII.grid(row=1, column=2, sticky=W)

TIIII = Label(GUIFIIII, height=12, width=12, textvariable=varIIII, anchor=NW,justify=CENTER, bg='white',fg='green')
TIIII.grid(row=1, column=3, sticky=W)

TV = Label(GUIFIIII, height=12, width=19, textvariable=varV, anchor=NW,justify=CENTER, bg='white',fg='green')
TV.grid(row=1, column=4, sticky=W)


    #Record Data From Actuator - i.e. Translated CAN Packets
GUIFIII = Frame(GUI, bg='honeydew4', height=1)
GUIFIII.grid(row=6, column=0, sticky=SW, ipady=2)

Rb10=Radiobutton(GUIFIII, text="rec.",value=0, variable=R10, bg='honeydew4',font='Helvetica 7', command=rb10_cmd, width=4, height=1)
Rb10.pack(anchor=W)

Rb2=Radiobutton(GUIFIII, text="cmd",value=0, variable=R2, bg='honeydew4',font='Helvetica 7', command=rb2_cmd, width=4, height=1)
Rb2.pack(anchor=W)
Rb3=Radiobutton(GUIFIII, text="fdbk",value=0, variable=R3, bg='honeydew4',font='Helvetica 7', command=rb3_cmd, width=4, height=1)
Rb3.pack(anchor=W)
Rb4=Radiobutton(GUIFIII, text="curr.",value=0, variable=R4, bg='honeydew4',font='Helvetica 7', command=rb4_cmd, width=4, height=1)
Rb4.pack(anchor=W)
Rb5=Radiobutton(GUIFIII, text="temp",value=0, variable=R5, bg='honeydew4',font='Helvetica 7', command=rb5_cmd, width=4, height=1)
Rb5.pack(anchor=W)


    #Program Exit - BUTTON COMMAND
ExitButton = tk.Button(GUIFI, text="EXIT NOW",command=exit_cmd, background='orangered4', highlightbackground='yellow', width=10, activebackground='orangered3', borderwidth=.5, relief='solid')
ExitButton.grid(row=1, column=2, padx=5)

GUI.after(3,Translated_CAN_Preview_func)
GUI.after(2,Record_func)
GUI.mainloop()


