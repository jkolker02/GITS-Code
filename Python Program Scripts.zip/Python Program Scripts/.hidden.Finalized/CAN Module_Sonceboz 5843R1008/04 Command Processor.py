#!/usr/bin/env python3

from multiprocessing import Pool
import csv
import pandas
import os
import matplotlib.pyplot as plt
import numpy as np
from decimal import*

pandas.set_option('display.max_colwidth',-1)
d=pandas.read_csv(r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5843R1008/data_temp/rawcmd.log", header=None, delim_whitespace=True)
d=pandas.DataFrame(d)

a0=(d[0].str[7:18])
a0 = a0.tolist()

a1=d[2].str[13:15]
a1p=(d[2].str[15:17])
a=a1p+a1
a=a.tolist()

for i in range(0, len(a)): 
    a[i] = int(a[i],16)

def command_processor(a):
    return round(a/1000*100,4)
    
p = Pool()
a = (p.map(command_processor,a))

rows = zip(a0,a)

plt.plot(a0, a) 
plt.xlabel('Time (sec)') 
plt.ylabel('Magnitude (%)') 
plt.title('Command Position vs Time') 
plt.show()

with open('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5843R1008/01_PROCESSED_DATA/Position_Command.txt', 'w') as f:
    writer = csv.writer(f)
    for row in rows:
        writer.writerow(row)

f.close()

os.remove(r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5843R1008/data_temp/rawcmd.log")

