clc
clear all

%Fourier Transform of Engine Data

%Load Filters if Needed
pkg load signal;    % Load the signal filtering package
pkg load data-smoothing
[b,a]=butter(6,.1,'low'); % This is a butterworth filter that is (order,frequencies,pass)..
[b1,a1]=butter(1,1,'low'); % This is a butterworth filter that is (order,frequencies,pass)..


%Load File
file = 'mm_air_gap.txt';   % Renaming the file as a variable "file"
[A]=dlmread(file);    % Reading the delimited file of interest
P=5; % Start Time or Start Sample 1386777	1327758	1267866	1207943	1146256	1088327	1027800	728135	485961
Q=length(A); % End Time or End Sample     1387631	1328683	1268815	1208945	1147320	1089459	1029000	729855	488971
R=[P:Q];    % Picking the data range that is being analyzed in matrix form. This will be determined by engine position in the future...   
t=(A(R,01));    % Assign a variable to the the data set by defining range "R" and column "13". Also apply filter if needed
#B=(A(R,01)+0.011001)*100/5.001;    % Assign a variable to the the data set by defining range "R" and column "13". Also apply filter if needed
B=((A(R,02))-.5)*360/4;    % Assign a variable to the the data set by defining range "R" and column "13". Also apply filter if needed
#C=filter(b,a,A(R,03));    % Assign a variable to the the data set by defining range "R" and column "13". Also apply filter if needed
C=(A(R,03));    % Assign a variable to the the data set by defining range "R" and column "13". Also apply filter if needed
D=(A(R,04));    % Assign a variable to the the data set by defining range "R" and column "13". Also apply filter if needed



%Plot Melexis Output vs Time
figure (figure);
subplot (1,1,1);
plot(t,B,'k',t,B,'.r');
title ('Melexis Output vs. Time');
xlabel('Time (sec)');
ylabel('Melexis Output (degrees)');
grid
%set (gca, "xminorgrid", "on");
%set (gca, "yminorgrid", "on");



%Plot Magnet Position vs Time
figure (figure);
subplot (1,1,1);
plot (t,C,'b');
title ('Magnet Position vs. Time');
xlabel('Time (sec)');
ylabel('Magnet Position (degrees)');
grid
%set (gca, "xminorgrid", "on");
%set (gca, "yminorgrid", "on");



%Excitation Voltage vs Time
figure (figure);
subplot (1,1,1);
plot (t,D,'b');
title ('Excitation Voltage vs. Time');
xlabel('Time (sec)');
ylabel('Excitation Voltage (volts)');
grid
%set (gca, "xminorgrid", "on");
%set (gca, "yminorgrid", "on");




%Plot Melexis Output and Magnet Position
figure (figure);
subplot (1,1,1);
plot(t,B,'r',t,C,'c');
title ('Melexis Output vs. Magnet Position');
xlabel('Time (sec)');
ylabel('Angular Position (degrees)');
grid
%set (gca, "xminorgrid", "on");
%set (gca, "yminorgrid", "on");



%Plot Melexis Output and Magnet Position
figure (figure);
subplot (1,2,1);
plot(t,B,'r');
title ('Melexis Output vs. Magnet Position');
xlabel('Time (sec)');
ylabel('Angular Position (degrees)');
grid
%set (gca, "xminorgrid", "on");
%set (gca, "yminorgrid", "on");

subplot (1,2,2);
plot(t,D,'c');
title ('Melexis Output vs. Magnet Position');
xlabel('Time (sec)');
ylabel('Angular Position (degrees)');
grid
%set (gca, "xminorgrid", "on");
%set (gca, "yminorgrid", "on");
