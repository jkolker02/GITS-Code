


from daqhats_utils import select_hat_device, enum_mask_to_string, chan_list_to_mask
from daqhats import mcc152, OptionFlags, HatIDs, HatError, DIOConfigItem
import time




address2 = select_hat_device(HatIDs.MCC_152)
hat2 = mcc152(address2)
hat2.dio_reset()
#hat2.dio_config_read_port(DIOConfigItem.DIRECTION)
z_x=0
j=0
b=1
counter=0

while counter < 5:    
#    z = (hat2.dio_input_read_bit(3))
    a = (hat2.dio_input_read_bit(3))
#    b = (hat2.dio_input_read_bit(1))
#    if z == 0:
#        z_b = 1
#    if z == 1 and z_b == 1:
#        z_x+=1
#        z_b = 0
#        print('hit')
    
    if a == 0 and j== 1:
        counter+=1
        print(counter)
        j=0
        
    if a == 1 and j== 0:
        j=1
        
        
    
        
    


  