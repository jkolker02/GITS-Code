#!/usr/bin/env python3

import os
from tkinter import *
import tkinter as tk
import subprocess



#Setup the GUI Window
GUI = Tk()

GUI.grid_rowconfigure(1, minsize=10)
GUI.grid_rowconfigure(2, minsize=15)
GUI.grid_rowconfigure(3, minsize=5)
GUI.grid_rowconfigure(4, minsize=10)
GUI.grid_rowconfigure(5, minsize=10)

GUI.configure(background='honeydew4')
GUI.title('CAN Main Dashboard - SONCEBOZ "5847R005" Network')

#Setup Callable Functions
    #Function to launch data aquisiton
def Control():
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5847R005/02 CAN Control.py"])    
    #Function to launch ramp program
def Monitor_Record():
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5847R005/03 CAN Record Monitor.py"])
    #Function to launch step program
def system_exit():
    sys.exit()
    
#Buttons and Labels
    #Headers/titles - LABELS
Header= Label(GUI, text="Main CAN Dashboard - Program Launcher",background='honeydew4', font='Helvetica 16 bold underline').grid(row=0, column=0, columnspan=2, padx=10, pady=5)

    #Launch The DAQ System - LABEL ENTRY
launch_DAQ = Label(GUI, text="Launch CAN Control:",background='honeydew4', font = 'Helvetica 10 bold').grid(row=1, column=0, sticky=E, padx=10)
launch_DAQ = Button(GUI, text='   CONTROL    ', command=Control, height = 1, width =20, borderwidth=.5, relief='solid').grid(row=1, column=1, sticky=W)

    #Launch The Ramp System - LABEL ENTRY
launch_DAQ = Label(GUI, text="Launch CAN Monitor/Record:",background='honeydew4', font = 'Helvetica 10 bold').grid(row=2, column=0, sticky=E, padx=10)
launch_DAQ = Button(GUI, text='   RECORD / MONITOR    ', command=Monitor_Record, height = 1, width =20, borderwidth=.5, relief='solid').grid(row=2, column=1, sticky=W)

 #Program Exit - BUTTON COMMAND
exitButton = tk.Button(GUI, text="EXIT NOW",command=system_exit, height = 1, width =20, background='orangered4', highlightbackground='yellow', activebackground='orangered3', borderwidth=.5, relief='solid')
exitButton.grid(row=4, column=1, sticky=W)

GUI.mainloop()
