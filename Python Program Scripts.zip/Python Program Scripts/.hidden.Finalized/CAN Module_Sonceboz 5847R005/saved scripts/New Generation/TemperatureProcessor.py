#!/usr/bin/env python3

from multiprocessing import Pool
import csv
import pandas
import os
import matplotlib.pyplot as plt
import numpy as np
from decimal import*

def CAN_TEMPERATURE():
    
    pandas.set_option('display.max_colwidth',-1)
    d=pandas.read_csv(r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5847R005/data_temp/rawtemp.log", header=None, delim_whitespace=True)
    d=pandas.DataFrame(d)

    a0=(d[0].str[7:18])
    a0=a0.tolist()

    a1=d[2].str[13:15]
    a1=a1.tolist()

    for i in range(0, len(a1)): 
        a1[i] = int(a1[i],16)

           
    p = Pool()
    a1 = (p.map(temperature_processor,a1))

    rows = zip(a0,a1)

    plt.plot(a0, a1) 
    plt.xlabel('Time (sec)') 
    plt.ylabel('Temperature (deg C)') 
    plt.title('Temperature vs Time') 
    plt.show()

    with open('/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5847R005/01_PROCESSED_DATA/Temperature.txt', 'w') as f:
        writer = csv.writer(f)
        for row in rows:
            writer.writerow(row)


    f.close()

    os.remove(r"/home/pi/Desktop/Python Program Scripts/Finalized/CAN Module_Sonceboz 5847R005/data_temp/rawtemp.log")

def temperature_processor(a1):
    return round(a1-40,2)
