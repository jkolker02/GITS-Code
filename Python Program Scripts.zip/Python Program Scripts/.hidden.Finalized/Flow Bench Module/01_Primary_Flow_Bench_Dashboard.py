#!/usr/bin/env python3

import os
from tkinter import *
import tkinter as tk
import subprocess



#Setup the GUI Window
GUI = Tk()

GUI.grid_rowconfigure(1, minsize=8)
GUI.grid_rowconfigure(2, minsize=8)
GUI.grid_rowconfigure(3, minsize=10)
GUI.grid_rowconfigure(4, minsize=8)
GUI.grid_rowconfigure(5, minsize=20)
GUI.grid_rowconfigure(6, minsize=10)

GUI.configure(background='honeydew4')
GUI.title('Pressure Control Module - Channel 01')

#Setup Callable Functions
    #Function to launch data aquisiton
def DAQ():
    subprocess.Popen([r"/home/pi/Desktop/daqhats/examples/c/mcc118/data_logger/logger/logger"])    
    #Function to launch ramp program
def RAMP():
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Module/02_Pressure_Control_Ramp.py"])
    #Function to launch step program
def STEP():
    subprocess.Popen([r"/home/pi/Desktop/Python Program Scripts/Finalized/Flow Bench Module/03_Pressure_Control_Step.py"]) 
    #Function to end program selection window
def system_exit():
    sys.exit()
    
#Buttons and Labels
    #Headers/titles - LABELS
Header= Label(GUI, text="Main Flow Bench Screen - Program Launcher",background='honeydew4', font='Helvetica 16 bold underline').grid(row=0, column=0, columnspan=2, padx=10, pady=10)

    #Launch The DAQ System - LABEL ENTRY
launch_DAQ = Label(GUI, text="Launch DAQ   Program:",background='honeydew4', font = 'Helvetica 10 bold').grid(row=1, column=0, sticky=E, padx=10)
launch_DAQ = Button(GUI, text='   DAQ    ', command=DAQ, height = 1, width =20, borderwidth=.5, relief='solid').grid(row=1, column=1, sticky=W)

    #Launch The Ramp System - LABEL ENTRY
launch_DAQ = Label(GUI, text="Launch RAMP Program:",background='honeydew4', font = 'Helvetica 10 bold').grid(row=2, column=0, sticky=E, padx=10)
launch_DAQ = Button(GUI, text='   RAMP    ', command=RAMP, height = 1, width =20, borderwidth=.5, relief='solid').grid(row=2, column=1, sticky=W)

    #Launch The Step System - LABEL ENTRY
launch_DAQ = Label(GUI, text="Launch STEP  Program:",background='honeydew4', font = 'Helvetica 10 bold').grid(row=3, column=0, sticky=E, padx=10)
launch_DAQ = Button(GUI, text='   STEP    ', command=STEP, height = 1, width =20, borderwidth=.5, relief='solid').grid(row=3, column=1, sticky=W)

 #Program Exit - BUTTON COMMAND
exitButton = tk.Button(GUI, text="EXIT NOW",command=system_exit, background='orangered4', highlightbackground='yellow', activebackground='orangered3', borderwidth=.5, relief='solid')
exitButton.grid(row=5, column=0)

GUI.mainloop()
