#!/usr/bin/env python3

from __future__ import print_function
from time import sleep
from sys import version_info, stdout
from tkinter import *
from PIL import Image
from PIL import ImageTk
from decimal import Decimal

from daqhats import mcc118, mcc152, OptionFlags, HatIDs, HatError
from daqhats_utils import select_hat_device, enum_mask_to_string, chan_list_to_mask

import tkinter as tk
import time

#initial output state on start-up
running = False
runningII = False
value_convert = None
slider_state = DISABLED
value = 0
start_pressure = -1
end_pressure = 0
dwell_time = 1
time_o = 0
time_f = 0
step_size = 0
y = 0
x = 0
n = 0
value = 0
valueII = 0

#Obtain the Board Information
address = select_hat_device(HatIDs.MCC_152)
hat = mcc152(address)
options = OptionFlags.DEFAULT
info = mcc152.info().NUM_AO_CHANNELS
channel = 0

#Setup the GUI Window
GUI = Tk()

GUI.grid_rowconfigure(1, minsize=10)
GUI.grid_rowconfigure(2, minsize=8)
GUI.grid_rowconfigure(3, minsize=10)
GUI.grid_rowconfigure(4, minsize=8)
GUI.grid_rowconfigure(5, minsize=10)
GUI.grid_rowconfigure(6, minsize=8)
GUI.grid_rowconfigure(7, minsize=10)
GUI.grid_rowconfigure(8, minsize=8)
GUI.grid_rowconfigure(9, minsize=10)
GUI.grid_rowconfigure(10, minsize=8)
GUI.grid_rowconfigure(11, minsize=10)
GUI.grid_rowconfigure(12, minsize=8)
GUI.grid_rowconfigure(13, minsize=10)
GUI.grid_rowconfigure(14, minsize=8)

GUI.grid_columnconfigure(0, minsize=10)
GUI.grid_columnconfigure(1, minsize=75)
GUI.grid_columnconfigure(3, minsize=25)
GUI.grid_columnconfigure(7, minsize=10)

GUI.configure(background='honeydew4')
GUI.title('Pressure Control Module - Channel 01')

var = StringVar()
varII = StringVar()
var.set("Current Pressure Set At: %s" % value + " psi")
varII.set("Current Time Set At: %s" % valueII + " sec")

    
#Function to control programed step function output
def scan_func():
    global dwell_time
    global start_pressure
    global end_pressure
    global running
    global channel
    global value
    global value_convert
    global current_output
    global var
    global varII
    global y
    global x
    global time_f
    global time_o
    global setep_size
    global n
    
    if running:
        
        y = start_pressure
        z = step_size * n + start_pressure
                        
        if z <= end_pressure:
            time_o = Decimal(time.time())
            y = step_size*n + start_pressure            
            time_f = Decimal(time.time())
            time.sleep(dwell_time)
            
            
            x = (time_f-time_o) + Decimal(dwell_time) + x
            
            value = round(y,5)
            valueII = round(x,5)
            
            value_convert = Decimal(y)*Decimal(.034482758)
            hat.a_out_write(channel=channel,value=value_convert,options=options)
                                  
            var.set("Current Pressure Set At: %s" % value + " psi")
            varII.set("Current Time Set At: %s" % valueII + " sec")
            
            n = n + 1
            
            print(y,x,n,)
            
        if z > end_pressure:
            
            time.sleep(dwell_time)
            running = False
            y = end_pressure
            valueII = round(x,5)
            value = round(y,5)
            slider["state"] = "normal"
            slider.set(y)
            slider["state"] = "disabled"
            n = 0
            x = 0
            value_convert = Decimal(y)*Decimal(.034482758)
            hat.a_out_write(channel=channel,value=value_convert,options=options)
            var.set("Current Pressure Set At: %s" % value + " psi")
            varII.set("Current Time Set At: %s" % valueII + " sec")
                        
    GUI.after(1,scan_func)
    
#Function to control manual output
def manual_func():
    global runningII
    global running
    global value
    global value_convert
    global current_output
    global var
    global varII
    global channel
        
    if runningII:
        running = False
        value = slider.get()
        value_convert = (Decimal(value)*Decimal(.034482758))
        hat.a_out_write(channel=channel,value=value_convert,options=options)
        var.set("Output Value Set At: %s" % value + "psi")
        slider.update_idletasks()
        
    GUI.after(5,manual_func)   
    
#Function to start program output      
def start_program_func():
    global running
    global runningII
    global slider_state
    global pressure_start
    
    running = True
    runningII = False
    slider["state"] = "disabled"

#Function to end program output
def stop_program_func():
    global running
    global pressure_start
    global value
    
    slider["state"] = "normal"
    slider.set(y)
    slider["state"] = "disabled"
    running = False

#Function to start manual output      
def start_manual_func():
    global runningII
    global slider_state
    
    runningII = True
    running = False
    slider["state"] = "normal"

#Function to end manual output
def stop_manual_func():
    global runningII
    global slider_state
    
    runningII = False
    slider["state"] = "disabled"

#Function to define the end pressure
def end_func():
    global end_ret
    global end_pressure
        
    if end_ret is not None:
        end_ret.destroy()
        
    end_pressure = Decimal(end.get())
    
    
    end_ret = Label(GUI, text="End Pressure Magnitude Set to: %s" % end_pressure + "psi", fg='red4', background='honeydew4')
    end_ret.grid(row=5, columnspan=3, sticky=W)
     
    end.delete(0,'end')

#Function to define the start pressure
def start_func():
    global start_ret
    global start_pressure
        
    if start_ret is not None:
        start_ret.destroy()
        
    start_pressure = Decimal(start.get())
    
    
    start_ret = Label(GUI, text="Start Pressure Magnitude Set to: %s" % start_pressure + "psi", fg='red4', background='honeydew4')
    start_ret.grid(row=2, columnspan=3, sticky=W)
     
    start.delete(0,'end')
    
    
#Function to define the dwell period
def dwell_func():
    global dwell_ret
    global dwell_time
        
    if dwell_ret is not None:
        dwell_ret.destroy()
        
    dwell_time = Decimal(dwell.get())
    
    
    dwell_ret = Label(GUI, text="Dwell Time Per Step Set to: %s" % dwell_time + "sec", fg='red4', background='honeydew4')
    dwell_ret.grid(row=11, columnspan=3, sticky=W)
     
    dwell.delete(0,'end')
    
#Function to define the step size
def step_func():
    global step_ret
    global step_size
        
    if step_ret is not None:
        step_ret.destroy()
        
    step_size = Decimal(step.get())
    
    
    step_ret = Label(GUI, text="Incremental Step Size Set to: %s" % step_size + "psi", fg='red4', background='honeydew4')
    step_ret.grid(row=8, columnspan=3, sticky=W)
     
    step.delete(0,'end')
    
#Function to reset time counter (not used) 
def reset_time_func():
    global dwell_time
    global x
    global valueII
    
    x=0
    valueII = x
    varII.set("Current Time Set At: %s" % valueII + " sec")

#Function to reset pressure back to zero
def reset_pressure_func():
    global dwell_time
    global x
    global valueII
    
    value = 0
    
    var.set("Current Pressure Set At: %s" % value + " psi")
    slider["state"] = "normal"
    slider.set(value)
    slider["state"] = "disabled"
    value_convert = (value*.034482758)
    hat.a_out_write(channel=channel,value=value_convert,options=options)
    
#Function to exit the program   
def system_exit():
    global center_pos
    global channel
    global options
    global value_convert
    
    if value_convert is None:
        hat.a_out_write(channel=channel,value=0,options=options)
    if value_convert is not None:
        hat.a_out_write(channel=channel,value=0,options=options)

                         
    sys.exit()

#Buttons and Labels
    #Control headers/titles - LABELS
program_control_header= Label(GUI, text="Step Function Control Settings",background='honeydew4', font='Helvetica 16 bold underline').grid(row=0, column=0, columnspan=4, padx=150, pady=10)
manual_control_header= Label(GUI, text="Manual Control Settings ",background='honeydew4', font='Helvetica 16 bold underline').grid(row=0, column=4, columnspan=2, pady=10)

    #Start Pressure Buttons and Labels - LABEL ENTRY
start_pressure = Label(GUI, text="Starting Pressure (psi):",background='honeydew4', font = 'Helvetica 10 bold').grid(row=1, column=0, sticky=W)
start_pressure = Button(GUI, text='   Enter Starting Pressure    ', command=start_func, height = 1, width =20, borderwidth=.5, relief='solid').grid(row=1, column=2, sticky=W)
start = Entry(GUI)
start.grid(row=1, column=1, sticky=W)
start_ret = Label(GUI, text="Start Pressure Magnitude Set to: ",background='honeydew4')
start_ret.grid(row=2, columnspan=3, sticky=W)
start.bind('<KP_Enter>', (lambda event: start_func()))
start.bind('<Return>', (lambda event: start_func()))
   
   #End Pressure Buttons and Labels - LABEL ENTRY
end_pressure = Label(GUI, text="Ending Pressure (psi):",background='honeydew4', font = 'Helvetica 10 bold').grid(row=4, column=0, sticky=W)
end_pressure = Button(GUI, text='   Enter Ending Pressure    ', command=end_func, height = 1, width =20, borderwidth=.5, relief='solid').grid(row=4, column=2, sticky=W)
end = Entry(GUI)
end.grid(row=4, column=1, sticky=W)
end_ret = Label(GUI, text="End Pressure Magnitude Set to: ",background='honeydew4')
end_ret.grid(row=5, columnspan=3, sticky=W)
end.bind('<KP_Enter>', (lambda event: end_func()))
end.bind('<Return>', (lambda event: end_func()))

    #Dwell Time Buttons and Labels - LABEL ENTRY
dwell_time= Label(GUI, text="Dwell Time Per Step (sec):",background='honeydew4', font = 'Helvetica 10 bold').grid(row=10, column=0, sticky=W)
dwell_time = Button(GUI, text='   Enter Dwell Time    ', command=dwell_func, height = 1, width =20, borderwidth=.5, relief='solid').grid(row=7, column=2, sticky=W)
dwell = Entry(GUI)
dwell.grid(row=10, column=1, sticky=W)
dwell_ret = Label(GUI, text="Dwell Time Per Step Set to:",background='honeydew4')
dwell_ret.grid(row=11, columnspan=3, sticky=W)
dwell.bind('<KP_Enter>', (lambda event: dwell_func()))
dwell.bind('<Return>', (lambda event: dwell_func()))

    #Step Size Buttons and Labels - LABEL ENTRY
step_size= Label(GUI, text="Incremental Step Size (psi):",background='honeydew4', font = 'Helvetica 10 bold').grid(row=7, column=0, sticky=W)
step_size = Button(GUI, text='   Enter Step Size    ', command=step_func, height = 1, width =20, borderwidth=.5, relief='solid').grid(row=10, column=2, sticky=W)
step = Entry(GUI)
step.grid(row=7, column=1, sticky=W)
step_ret = Label(GUI, text="Incremental Step Size Set to:",background='honeydew4')
step_ret.grid(row=8, columnspan=3, sticky=W)
step.bind('<KP_Enter>', (lambda event: step_func()))
step.bind('<Return>', (lambda event: step_func()))

    #Display the current pressure magnitude output command in real time - LABEL ENTRY
current_output = Label(GUI, textvariable=var, background='gray77', borderwidth=.5, relief='solid', font = 'Helvetica 10 bold')
current_output.grid(row=5, column=4, columnspan=2, rowspan=2, sticky=W, pady=2)

    #Display the current time elapsed in real time - LABEL ENTRY
current_output = Label(GUI, textvariable=varII, background='gray77', borderwidth=.5, relief='solid', font = 'Helvetica 10 bold')
current_output.grid(row=7, column=4, columnspan=2, sticky=W, pady=2)

    #Pressure Program Start/Stop - BUTTON COMMAND
Endable_Program_ch01 = Button(GUI, text='Enable Program', command = start_program_func, height = 1, width =18, borderwidth=.5, relief='solid').grid(row=13, column=1, sticky=W)
Disable_Program_ch01 = Button(GUI, text='Disable Program', command = stop_program_func, height = 1, width =20, borderwidth=.5, relief='solid').grid(row=13, column=2, padx=2, sticky=W)

    #Pressure Manual Command Start/Stop - BUTTON COMMAND
Endable_Manual_ch01 = Button(GUI, text='Enable Manual Control', command = start_manual_func, height = 1, width =20, borderwidth=.5, relief='solid').grid(row=2, rowspan=3, column=4, sticky=W)
Disable_Manual_ch01 = Button(GUI, text='Disable Manual Control', command = stop_manual_func, height = 1, width =20, borderwidth=.5, relief='solid').grid(row=2, rowspan=3, column=5, sticky=W, padx=3, pady=1)
    
    #Manual Position Slider - SLIDER WIDGET
slider=Scale(GUI, from_=0, to=145, orient=HORIZONTAL, resolution=0.01,repeatdelay=1, repeatinterval=1, background='firebrick4', sliderlength=10, borderwidth = 1.5, foreground='black',length=373, width=10, state=slider_state)
slider.grid(row=1,column=4, columnspan=4, rowspan=1, sticky=W)

    #Program Exit - BUTTON COMMAND
exitButton = tk.Button(GUI, text="EXIT NOW",command=system_exit, background='orangered4', highlightbackground='yellow', activebackground='orangered3', borderwidth=.5, relief='solid')
exitButton.grid(row=13, column=0, padx=20)

    #Reset Pressure - BUTTON COMMAND
resetPressureButton = tk.Button(GUI, text="Reset Pressure (0.0 psi)",command=reset_pressure_func, background='RosyBrown4', highlightbackground='RosyBrown4', activebackground='RosyBrown3', borderwidth=.5, relief='solid')
resetPressureButton.grid(row=10, column=4)

GUI.after(1, scan_func)
GUI.after(1, manual_func)
GUI.mainloop()
