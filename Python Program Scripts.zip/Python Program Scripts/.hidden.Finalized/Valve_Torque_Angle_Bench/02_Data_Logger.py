#!/usr/bin/env python3

#---------Imports
import os
import csv
import pandas
import numpy as np
from sys import stdout
from decimal import Decimal
from daqhats_utils import select_hat_device, enum_mask_to_string, chan_list_to_mask
from daqhats import mcc118, mcc152, OptionFlags, HatIDs, HatError

#---------End of imports




with open("02_Configuration_File.txt","w") as file_object:
                writer = csv.writer(file_object)
                writer.writerow([1])
                writer.writerow([1])
                file_object.close()
                
with open("03_Raw_Feedback.txt","w") as file_object:
                file_object.close()
                
file_trigger = pandas.read_csv(r"/home/pi/Desktop/Python Program Scripts/Finalized/Valve_Torque_Angle_Bench/02_Configuration_File.txt", header=None)
file_trigger = ((file_trigger.loc[1:1,[0]]))
file_trigger = file_trigger.to_string(index=False, header=None)

str = str ('1,2,3,4')
list=str.split(",")
li=[]
for i in list:
    li.append(int(i))
channels = li
print (channels)
channel_mask = chan_list_to_mask(channels)
print (channel_mask)
num_channels = len(channels)

size_request = 500

samples_per_channel = size_request
scan_rate = 10000.0
options = OptionFlags.CONTINUOUS
address = select_hat_device(HatIDs.MCC_118)
hat1 = mcc118(address)
hat1.a_in_scan_stop()
hat_read_buf = [] * (samples_per_channel * num_channels)
buffer_size_samples = samples_per_channel * num_channels
actual_scan_rate = hat1.a_in_scan_actual_rate(num_channels, scan_rate)

hat1.a_in_scan_stop()
hat1.a_in_scan_cleanup()



def read_and_display_data(hat1, samples_per_channel, num_channels):
    
    global dummy_clock
    global scan_rate
    global channel_mask, scan_rate,options
    global dataloop
    global color_list
    global data
    global size_request
    global file_trigger
    
    total_samples_read = 0
    samples_per_channel_read = size_request
    timeout = num_channels * samples_per_channel / scan_rate * 10
    dataloop = False        
        
    print(channel_mask, samples_per_channel, scan_rate, options)
    print(file_trigger)
    hat1.a_in_scan_start(channel_mask, samples_per_channel, scan_rate, options)
    

    
    while int(file_trigger) == 1:
        
        file_trigger = pandas.read_csv(r"/home/pi/Desktop/Python Program Scripts/Finalized/Valve_Torque_Angle_Bench/02_Configuration_File.txt", header=None)
        file_trigger = ((file_trigger.loc[1:1,[0]]))
        file_trigger = file_trigger.to_string(index=False, header=None)
        print('Im here')
        retval = hat1.a_in_scan_status()
        k = retval.running
        j= retval.samples_available
        i = 0
    
        while j < size_request:
            retval = hat1.a_in_scan_status()
            k = retval.running
            j= retval.samples_available
            i += 1
            print('wait', i , "\n")
            
            if i > size_request:
                hat1.a_in_scan_stop()
                hat1.a_in_scan_cleanup()
                hat1.a_in_scan_start(channel_mask, samples_per_channel, scan_rate,options)
                i = 0
               
        read_result = hat1.a_in_scan_read(samples_per_channel_read, timeout)
        print(retval)
        #ts= time.time()-dummy_clock
        samples_read_per_channel = int(len(read_result.data) / num_channels)
        total_samples_read += 1
             
        data = read_result.data    
             
        if len(data) > 10:
            data = np.array(data)
            data = data.reshape(int(len(data)/4),4)
            
                
            with open("03_Raw_Feedback.txt","a") as file_object:
                writer = csv.writer(file_object)
                writer.writerows(data)
        else:
            print('data too small')


            
            
                
    hat1.a_in_scan_stop()
    hat1.a_in_scan_cleanup()
    stdout.flush()


read_and_display_data(hat1, samples_per_channel, num_channels)


print('GOOD_BYE')