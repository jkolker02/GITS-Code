#!/usr/bin/env python3

from __future__ import print_function
from time import sleep
from sys import stdout
from daqhats import mcc118, mcc152, OptionFlags, HatIDs, HatError
from daqhats_utils import select_hat_device, enum_mask_to_string, chan_list_to_mask
from sys import version_info, stdout
from tkinter import *
import tkinter as tk
import math
import time
import matplotlib.pyplot as plt
import sys
import pandas as pd


GUI = Tk()
GUI.configure(background='white')
GUI.title('Square Wave Generator')

lis1=[]
lis2=[]
cycles=1

address = select_hat_device(HatIDs.MCC_152)
hat = mcc152(address)
options = OptionFlags.DEFAULT
channel = 0
num_channels = mcc152.info().NUM_AO_CHANNELS


def go():
    global cycles
    global lis1
    global lis2
    global address
    global hat
    global options
    global channel
    global num_channels
    
    while cycles<=100:
        t=0
        lis1.clear()
        lis2.clear()
        
        while t<=.05:
        
            x = 2
            print("%.2f"%x,"%.2f"%t,"%.2f"%cycles)
            lis1.append(t)
            lis2.append(x)             
        

            value = x
            hat.a_out_write(channel=channel, value=value, options=options)
            time.sleep(.2)
        
            x = 0
            print("%.2f"%x,"%.2f"%t,"%.2f"%cycles)
            t=t+.025
            lis1.append(t)
            lis2.append(x)
            value = x
            hat.a_out_write(channel=channel, value=value, options=options)
            time.sleep(.1)
        
    cycles=cycles+1
    #plt.plot(lis1,lis2)
    #plt.show()
    
value = 0
hat.a_out_write(channel=channel, value=value, options=options)


    #END THE PROGRAM
exitButton = tk.Button(GUI, text="EXIT NOW",command=sys.exit, background='red')
exitButton.grid(row=15, column=0)
    #DATA RECORD BUTTON
thegobutton = Button(GUI, text="Produce Signal", command =go, background ='green').grid(row=15, column=5, sticky=W)


GUI.mainloop()