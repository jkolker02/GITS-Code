#!/usr/bin/env python3

from __future__ import print_function
#from time import sleep
#from sys import stdout
from daqhats import mcc118, mcc152, OptionFlags, HatIDs, HatError
from daqhats_utils import select_hat_device, enum_mask_to_string, chan_list_to_mask
#from sys import version_info, stdout
from tkinter import *
from PIL import Image
from PIL import ImageTk
from decimal import Decimal
import tkinter as tk
import time

#initial output state on start-up
running = False
runningII = False
value_convert = None
slider_state = DISABLED




#Obtain the Board Information
address = select_hat_device(HatIDs.MCC_152)
hat = mcc152(address)
options = OptionFlags.DEFAULT
info = mcc152.info().NUM_AO_CHANNELS
channel = 0

#Setup the GUI Window
GUI = Tk()

GUI.grid_rowconfigure(1, minsize=8)
GUI.grid_rowconfigure(2, minsize=8)
GUI.grid_rowconfigure(3, minsize=15)
GUI.grid_rowconfigure(4, minsize=8)
GUI.grid_rowconfigure(5, minsize=8)
GUI.grid_rowconfigure(6, minsize=15)
GUI.grid_rowconfigure(7, minsize=8)
GUI.grid_rowconfigure(8, minsize=8)
GUI.grid_rowconfigure(9, minsize=15)
GUI.grid_rowconfigure(10, minsize=15)
GUI.grid_rowconfigure(11, minsize=8)
GUI.grid_rowconfigure(12, minsize=8)
GUI.grid_rowconfigure(13, minsize=15)
GUI.grid_rowconfigure(14, minsize=8)
GUI.grid_rowconfigure(15, minsize=8)
GUI.grid_rowconfigure(16, minsize=15)
GUI.grid_rowconfigure(17, minsize=8)
GUI.grid_rowconfigure(18, minsize=8)
GUI.grid_rowconfigure(19, minsize=15)
GUI.grid_rowconfigure(20, minsize=8)
GUI.grid_rowconfigure(21, minsize=8)

GUI.grid_columnconfigure(3, minsize=75)
GUI.grid_columnconfigure(4, minsize=75)

GUI.configure(background='white')
GUI.title('Square Wave Generator')

    
#Function to control programed output
def scan_func():
    global cycles_start
    global cycles_count
    global freq_rate
    global center_pos
    global valley_mag
    global peak_mag
    global running
    global channel
    global value
    global value_convert
        
    if running:
        
        if cycles_start<=cycles_count:
            value = (peak_mag + center_pos)
            print (value)
            value_convert = value/20
            hat.a_out_write(channel=channel,value=value_convert,options=options)
            t=float(Decimal(.5)/freq_rate)
            time.sleep(t)
            
            
             
            value = (center_pos - valley_mag)
            print (value)
            value_convert = value/20
            hat.a_out_write(channel=channel,value=value_convert,options=options)
            time.sleep(t)
            
            
            print (cycles_start)
            
            cycles_start=cycles_start+1
            
            if cycles_start>=cycles_count+1:
                hat.a_out_write(channel=channel,value=value_convert,options=options)
                slider["state"] = "normal"
                slider.set(value)
                slider["state"] = "disabled"
                print (center_pos)
                running = False
                    
    GUI.after(5,scan_func)
    
#Function to control manual output
def manual_func():
    global runningII
    global running
    global value
    global value_convert
        
    if runningII:
        running = False
        channel = 0
        value = slider.get()
        value_convert = (value/20)
        hat.a_out_write(channel=channel,value=value_convert,options=options)
        time.sleep(1)
        print (slider.get())
                                 
    GUI.after(10,manual_func)   
    
#Function to start program output      
def start_program_func():
    global running
    global runningII
    global slider_state
    global center_pos
    
    running = True
    runningII = False
    slider["state"] = "disabled"

#Function to end program output
def stop_program_func():
    global running
    global center_pos
    global value
    
    slider["state"] = "normal"
    slider.set(value)
    slider["state"] = "disabled"
    running = False

#Function to start manual output      
def start_manual_func():
    global runningII
    global slider_state
    
    runningII = True
    running = False
    slider["state"] = "normal"

#Function to end manual output
def stop_manual_func():
    global runningII
    global slider_state
    
    runningII = False
    slider["state"] = "disabled"

#Function to define the signal frequency
def peak_func():
    global peak_ret
    global peak_mag
        
    if peak_ret is not None:
        peak_ret.destroy()
        
    peak_mag = Decimal(peak.get())
    
    
    peak_ret = Label(GUI, text="Peak Magnitude Set to: %s" % peak_mag, fg='green', background='white')
    peak_ret.grid(row=2, columnspan=3, sticky=W)
     
    peak.delete(0,'end')

#Function to define the signal frequency
def valley_func():
    global valley_ret
    global valley_mag
        
    if valley_ret is not None:
        valley_ret.destroy()
        
    valley_mag = Decimal(valley.get())
    
    
    valley_ret = Label(GUI, text="Valley Magnitude Set to: %s" % valley_mag, fg='green', background='white')
    valley_ret.grid(row=5, columnspan=3, sticky=W)
     
    valley.delete(0,'end')
    
    
#Function to define the signal frequency
def center_func():
    global center_ret
    global center_pos
        
    if center_ret is not None:
        center_ret.destroy()
        
    center_pos = Decimal(center.get())
    
    
    center_ret = Label(GUI, text="Signal Center Set to: %s" % center_pos, fg='green', background='white')
    center_ret.grid(row=8, columnspan=3, sticky=W)
     
    center.delete(0,'end')
    
    
#Function to define the desired cycles
def cycles_func():
    global cycles_ret
    global cycles_count
        
    if cycles_ret is not None:
        cycles_ret.destroy()
        
    cycles_count = int(cycles.get())
    
    
    cycles_ret = Label(GUI, text="Required Cycles Set to: %s" % cycles_count, fg='green', background='white')
    cycles_ret.grid(row=11, columnspan=3, sticky=W)
     
    cycles.delete(0,'end')
    
#Function to define the starting cycles
def cycles_start_func():
    global cycles_st_ret
    global cycles_start
        
    if cycles_st_ret is not None:
        cycles_st_ret.destroy()
        
    cycles_start = int(cycles_st.get())
    
    
    cycles_st_ret = Label(GUI, text="Starting Cycles Set to: %s" % cycles_start, fg='green', background='white')
    cycles_st_ret.grid(row=14, columnspan=3, sticky=W)
     
    cycles_st.delete(0,'end')
    
#Function to define the signal frequency
def signal_frequency_func():
    global freq_ret
    global freq_rate
    global options
    
    if freq_ret is not None:
        freq_ret.destroy()
        
    freq_rate = Decimal(freq.get())
    
    
    freq_ret = Label(GUI, text="Signal Frequency Set to: %s" % freq_rate, fg='green', background='white')
    freq_ret.grid(row=17, columnspan=3, sticky=W)
     
    freq.delete(0,'end')   
    
def system_exit():
    global center_pos
    global channel
    global options
    global value_convert
    
    if value_convert is None:
        hat.a_out_write(channel=channel,value=0,options=options)
    if value_convert is not None:
        hat.a_out_write(channel=channel,value=value_convert,options=options)

                         
    sys.exit()

#Buttons and Labels
    #Control headers/titles - LABELS
program_control_header= Label(GUI, text="Program Controls",background='white').grid(row=0, column=1, pady=10)
manual_control_header= Label(GUI, text="Manual Controls",background='white').grid(row=0, column=4, columnspan=2, pady=10)
    #Peak of the Square Wave - LABEL ENTRY
peak_mag= Label(GUI, text="Peak Magnitude:",background='white').grid(row=1, column=0, sticky=W)
peak_mag = Button(GUI, text='   Enter Peak Magnitude    ', command=peak_func, height = 1, width =20).grid(row=1, column=2, sticky=W)
peak = Entry(GUI)
peak.grid(row=1, column=1, sticky=W)
peak_ret = Label(GUI, text="Peak Magnitude Set to:",background='white')
peak_ret.grid(row=2, columnspan=3, sticky=W)
peak.bind('<Return>', (lambda event: peak_func()))

    #Valley of the Square Wave - LABEL ENTRY
valley_mag = Label(GUI, text="Valley Magnitude:",background='white').grid(row=4, column=0, sticky=W)
valley_mag = Button(GUI, text='   Enter Valley Magnitude    ', command=valley_func, height = 1, width =20).grid(row=4, column=2, sticky=W)
valley = Entry(GUI)
valley.grid(row=4, column=1, sticky=W)
valley_ret = Label(GUI, text="Valley Magnitude Set to:",background='white')
valley_ret.grid(row=5, columnspan=3, sticky=W)
valley.bind('<Return>', (lambda event: valley_func()))

    #Center of the Square Wave - LABEL ENTRY
center_pos= Label(GUI, text="Signal Center:",background='white').grid(row=7, column=0, sticky=W)
center_pos = Button(GUI, text='   Enter Signal Center    ', command=center_func, height = 1, width =20).grid(row=7, column=2, sticky=W)
center = Entry(GUI)
center.grid(row=7, column=1, sticky=W)
center_ret = Label(GUI, text="Signal Center Set to:",background='white')
center_ret.grid(row=8, columnspan=3, sticky=W)
center.bind('<Return>', (lambda event: center_func()))

    #Cycle Max of the Square Wave - LABEL ENTRY
cycles_count= Label(GUI, text="Required Cycles:",background='white').grid(row=10, column=0, sticky=W)
cycles_count = Button(GUI, text='   Enter Cycles    ', command=cycles_func, height = 1, width =20).grid(row=10, column=2, sticky=W)
cycles = Entry(GUI)
cycles.grid(row=10, column=1, sticky=W)
cycles_ret = Label(GUI, text="Required Cycles Set to:",background='white')
cycles_ret.grid(row=11, columnspan=3, sticky=W)
cycles.bind('<Return>', (lambda event: cycles_func()))

    #Cycle start of the Square Wave - LABEL ENTRY
cycles_start= Label(GUI, text="Starting Cycles:",background='white').grid(row=13, column=0, sticky=W)
cycles_start = Button(GUI, text='   Enter Cycles    ', command=cycles_start_func, height = 1, width =20).grid(row=13, column=2, sticky=W)
cycles_st = Entry(GUI)
cycles_st.grid(row=13, column=1, sticky=W)
cycles_st_ret = Label(GUI, text="Starting Cycles Set to:",background='white')
cycles_st_ret.grid(row=14, columnspan=3, sticky=W)
cycles_st.bind('<Return>', (lambda event: cycles_start_func()))

    #Rate(frequency) of the Square Wave - LABEL ENTRY
freq_rate= Label(GUI, text="Signal Frequency:",background='white').grid(row=16, column=0, sticky=W)
freq_rate = Button(GUI, text='   Enter Frequency    ', command=signal_frequency_func, height = 1, width =20).grid(row=16, column=2, sticky=W)
freq = Entry(GUI)
freq.grid(row=16, column=1, sticky=W)
freq_ret = Label(GUI, text="Signal Frequency Set to:",background='white')
freq_ret.grid(row=17, columnspan=3, sticky=W)
freq.bind('<Return>', (lambda event: signal_frequency_func()))

    #Display the current output and cycle count in real time - LABEL ENTRY
current_output = Label(GUI, text="Current Output:",background='white')
current_output.grid(row=5, column=5, sticky=W)

current_cycles = Label(GUI, text="Current Cycle Count:",background='white')
current_cycles.grid(row=6, column=5, sticky=W)

    #Signal program start/stop - BUTTON COMMAND
Endable_Program_ch01 = Button(GUI, text='Enable Ch01 Program', command = start_program_func, height = 1, width =20).grid(row=19, column=1, sticky=W)
Disable_Program_ch01 = Button(GUI, text='Disable Ch01 Program', command = stop_program_func, height = 1, width =20).grid(row=19, column=2, sticky=W)

    #Signal manual command start/stop - BUTTON COMMAND
Endable_Manual_ch01 = Button(GUI, text='Enable Ch01 Manual Control', command = start_manual_func, height = 1, width =20).grid(row=2, rowspan=2, column=4, sticky=W, padx=3, pady=1)
Disable_Manual_ch01 = Button(GUI, text='Disable Ch01 Manual Control', command = stop_manual_func, height = 1, width =20).grid(row=2, rowspan=2, column=5, sticky=W, pady=1)
    
    #Manual Position Slider - SLIDER WIDGET
slider=Scale(GUI, from_=0, to=100, orient=HORIZONTAL, resolution=0.01, background='white', sliderlength=10, borderwidth = 1.5, foreground='red',length=372, width=10, state=slider_state)
slider.grid(row=1,column=4, columnspan=2, rowspan=1, sticky=W, padx=3)

    #Program Exit - BUTTON COMMAND
exitButton = tk.Button(GUI, text="EXIT NOW",command=system_exit, background='red')
exitButton.grid(row=19, column=0)

    #Graphic Window - CANVAS CREATION
pic = Canvas(GUI, width=300, height=200)
pic.grid(row=7, rowspan=8, column=5, columnspan=4, padx=10)
photo = PhotoImage(file="Plot_FigureII.gif")
pic.create_image(150,100, image=photo)


GUI.after(5000, scan_func)
GUI.after(5000, manual_func)
#GUI.mainloop()