#!/usr/bin/env python

from __future__ import print_function
from sys import version_info, stdout
import time
import math

lis1=[]
lis2=[]
cycles=1
    
while cycles<=5:
    t=0
    lis1.clear()
    lis2.clear()
        
    while t<=5+.025:
        
        lis1.append(t)
        w=2*2*math.pi
        x = 2.5+.625*math.sin(w*t)
        print("%.2f"%x,"%.2f"%w,"%.2f"%t,"%.2f"%cycles)
        t=t+.1
        time.sleep(.004583)
        lis2.append(x)            
        value = x
        stdout.flush()
        file_object=open("data","a")
        file_object.write('{0} {1}\n'.format("%.2f"%x,"%.2f"%t))
        
        
    cycles=cycles+1
    #plt.plot(lis1,lis2)
    #plt.show()
    
value = 0

print(file_object)