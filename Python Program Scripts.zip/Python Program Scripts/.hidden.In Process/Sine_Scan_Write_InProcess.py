#!/usr/bin/env python3


#THIS LINE IS USED TO CALL ON TOOLS AND LIBRARIES
from __future__ import print_function
from time import sleep
from sys import stdout
from daqhats import mcc118, mcc152, OptionFlags, HatIDs, HatError
from daqhats_utils import select_hat_device, enum_mask_to_string, chan_list_to_mask
from sys import version_info, stdout
from tkinter import *
import tkinter as tk
import math
import time
import matplotlib.pyplot as plt
import sys
import pandas as pd
import csv


#THIS LINE IS THE GUI WINDOW SETUP AND MAIN CALLS FOR FUNCTIONS (buttons, commands, labels, etc.)
    #GUI MAIN WINDOW SETUP
GUI = Tk()
GUI.configure(background='white')
GUI.grid_rowconfigure(0, minsize=15)
GUI.grid_rowconfigure(3, minsize=15)
GUI.grid_rowconfigure(6, minsize=15)
GUI.grid_rowconfigure(9, minsize=15)
GUI.grid_rowconfigure(12, minsize=15)
GUI.grid_rowconfigure(15, minsize=15)
GUI.grid_rowconfigure(18, minsize=15)
GUI.title('Channel Recording Control')
   

#THIS LINE IS IMPORTING A TIME STAMP CONSTANT THAT WILL BE USED TO CALCULATE RUNNING TIME
ts = time.time()

#THIS LINE DEFINES THE CHANNELS TO BE RECORDED BY THE MCC118 HAT
def channel_entry():
    
    global chan_ret
    global num_channels
    global channel_mask
    global chan1
    global li
    
    if chan_ret is not None:
        chan_ret.destroy()
    
    chan1 = chan.get()
    list = chan1.split(',')
    li=[]
        
    for i in list:
        li.append(int(i))
    
    chan_ret = Label(GUI, text="Channels Set to Record: %s" % li, fg='green', background='white')
    chan_ret.grid(row=2, columnspan=3, sticky=W)
    
    chan1 = li
    channel_mask = chan_list_to_mask(chan1)
    num_channels = len(chan1)
    
    chan.delete(0,'end')



#THIS LINE DEFINES THE MAX SAMPLES TO LOOK AT AND HOW QUICK THE HAT SCANS DATA
def sample_collection_size():
    global samp_collect_ret
    global sample_collect
    
    if samp_collect_ret is not None:
        samp_collect_ret.destroy()
    
    sample_collect = int(collect.get())
    
    samp_collect_ret = Label(GUI, text="Sample Collection Size Set to: %s" % sample_collect, fg='green', background='white')
    samp_collect_ret.grid(row=5, columnspan=3, sticky=W)
    
    collect.delete(0,'end')



#THIS LINE DEFINES THE SCAN RATE OF THE SYSTEM 
def sample_scan_rate():
    global scan_ret
    global scan_rate
    global options
    
    if scan_ret is not None:
        scan_ret.destroy()
        
    scan_rate = int(scan.get())
    
    
    scan_ret = Label(GUI, text="Scan Rate Set to: %s" % scan_rate, fg='green', background='white')
    scan_ret.grid(row=8, columnspan=3, sticky=W)
    

    options = OptionFlags.DEFAULT
    
    scan.delete(0,'end')



#THIS LINE SELECTS THE MCC118 HAT TO USE AND DISPLAYS THE OPERATING PARAMETERS IN THE DIALOG WINDOW
def querry_board():
    global querry_ret
    global num_channels
    global actual_scan_rate
    global hat
    global address
        
    if querry_ret is not None:
        querry_ret.destroy()
        
    address = select_hat_device(HatIDs.MCC_118)
    hat = mcc118(address)
    hat.a_in_scan_stop()
    querry_ret = Label(GUI, text="- board address 0%s"%address, fg='green', background='white')
    querry_ret.grid(row=10, column=1, columnspan=2, sticky=W)
        
    actual_scan_rate = hat.a_in_scan_actual_rate(num_channels, scan_rate)
    scan_rate_ret = Label(GUI, text="- actual scan rate %s" % actual_scan_rate, fg='green', background='white')
    scan_rate_ret.grid(row=11, column=1, columnspan=2, sticky=W)
    
    
    
#THIS LINE PRODUCES HEADERS FOR THE DATA SET IN THE DIALOG WINDOW
def headers():
    global head_rett1
    global chan1
    global li
    
    
    head_reta = str('Samples Read     Scan Count    ')
    head_retb = Label(GUI, text="%s" % head_reta, background='white')
    head_retb.grid(row=13, column=1, sticky=W)
    
    head_retc = []
    x=0
    
    while x < len(chan1):
        y = (chan1[x])
        head_retc.append("channel_0"+str(y)+"  ")
        x=x+1
    
    str1="  "
    head_retd = (str1.join(head_retc))
    
    head_rete = Label(GUI, text="%s" %(head_retd), background="white")
    head_rete.grid(row=13, column=2, sticky=W, pady=5)



#THIS LINE READS/WRITES THE DATA AND DISPLAYS IT IN THE DIALOG WINDOW
def read_data():
    global total_samples_read
    global channel_mask
    global read_request_size
    global timeout
    global num_channels
    global hat
    global sample_collect
    global address
    global index
    global ts
    global z
    while z < 1:
        
        total_samples_read = 0
        read_request_size = sample_collect
        timeout = 10.0
        hat.a_in_scan_start(channel_mask, sample_collect, scan_rate,options)
        
        #LOOPING DATA COLLECTION UNTIL THE BUFFER SIZE IS COLLECTED
        while total_samples_read < sample_collect:
            read_result = hat.a_in_scan_read(read_request_size, timeout)

               
            #CALCULATES THE SYSTEM TIME AND AMOUNT OF DATA TAKEN
            td= time.time() - ts
            
                  
            #CONTINUALLY DISPLAYS THE RECORDED SAMPLE
            samples_read_per_channel = int(len(read_result.data) / num_channels)
            total_samples_read += samples_read_per_channel
            
            pd.set_option('display.max_rows',sample_collect)
            ci=[]
            ci=pd.DataFrame(read_result.data)
            
            #Create the data arrays
            for i in range(num_channels):
                pd.set_option('display.max_rows',sample_collect)
                ch=pd.DataFrame(read_result.data[0+i:len(read_result.data):len(chan1)],columns=[i])
                ci.insert(i,'data',ch)
                
            
            
            #WRITES DATA TO A FILE AND CONTINUALLY APPENDS THE RESULTS TO THE FILE
            if samples_read_per_channel > 0:
                index = samples_read_per_channel * num_channels - num_channels

                for i in range(num_channels):
                    file_object=open('data.csv','a')
                    file_object = ci.to_csv('data.csv',header = False, index = False)
                    #file_object.write('\n')
                    #print('{:.5f}'.format(read_result.data[index + i]), 'V\n', end='')
                    
            stdout.flush()
        
        sleep(.025)
        
        hat.a_in_scan_cleanup()
        
        z = z+1  

    

#THE FOLLOWING LINES SETUP THE GUI BUTTONS AND ISSUES COMMANDS ACCORDINGLY
    #CHANNEL RECORD BUTTON/LABEL SETUP
Channels_to_Record = Label(GUI, text="Channels to Record:",background='white').grid(row=1, column=0, sticky=W)
Enter_Channels = Button(GUI, text='    Enter Channels    ', command=  channel_entry, height = 1, width =20).grid(row=1, column=2, sticky=W)
chan = Entry(GUI)
chan.grid(row=1, column=1, sticky=W)
chan_ret = Label(GUI, text="Channels Set to Record:",background='white')
chan_ret.grid(row=2, columnspan=3, sticky=W)
num_channels = chan.get()
chan.bind('<Return>', (lambda event: channel_entry()))
    #Sample Collection Size SET BUTTON/LABEL SETUP
Sample_Collection= Label(GUI, text="Sample Collection Size:",background='white').grid(row=4, column=0, sticky=W)
Enter_Collection_Size = Button(GUI, text='Enter Sample Collection Size', command=sample_collection_size, height = 1, width =20).grid(row=4, column=2, sticky=W)
collect = Entry(GUI)
collect.grid(row=4, column=1, sticky=W)
samp_collect_ret = Label(GUI, text="Sample Collection Size Set to:",background='white')
samp_collect_ret.grid(row=5, columnspan=3, sticky=W)
collect.bind('<Return>', (lambda event: sample_collection_size()))
    #SCAN RATE BUTTON/LABEL SETUP
Sample_Scan= Label(GUI, text="Sample Scan Rate:",background='white').grid(row=7, column=0, sticky=W)
Enter_Scan = Button(GUI, text='   Enter Scan Rate    ', command=sample_scan_rate, height = 1, width =20).grid(row=7, column=2, sticky=W)
scan = Entry(GUI)
scan.grid(row=7, column=1, sticky=W)
scan_ret = Label(GUI, text="Scan Rate Set to:",background='white')
scan_ret.grid(row=8, columnspan=3, sticky=W)
scan.bind('<Return>', (lambda event: sample_scan_rate()))
    #QUERRY AND UPDATE THE SYSTEM HAT
MCC_118_Information= Label(GUI, text="MCC 118 Information:",background='white').grid(row=10, column=0, sticky=W)
Enter_Scan = Button(GUI, text='      Querry Board      ', command=querry_board, height = 1, width =20).grid(row=10, column=2, sticky=W)
querry_ret = Label(GUI, text="QUERRY FOR UPDATE...",background='white')
querry_ret.grid(row=10, column=1, columnspan=2, sticky=W)
    #BUILD DATA HEADER LABLES FOR SIGNALS
Headers= Label(GUI, text="Data Headers:",background='white').grid(row=13, column=0, sticky=W)
Refresh_Headers = Button(GUI, text='   Refresh Data Headers    ', command=headers, height = 1, width =20).grid(row=13, column=5, sticky=W)
head_ret = Label(GUI, text="Data Headers:",background='white')
head_ret.grid(row=13, column=0, sticky=W)
    #END THE PROGRAM
exitButton = tk.Button(GUI, text="EXIT NOW",command=sys.exit, background='red')
exitButton.grid(row=15, column=0)
    #DATA RECORD BUTTON
record = Button(GUI, text="Record Data", command =read_data, background ='green').grid(row=15, column=5, sticky=W)


#GUI.mainloop()

#THIS IS JUNK BELOW THIS LINE

z=0

GUI.mainloop()