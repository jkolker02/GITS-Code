#!/usr/bin/env python

from __future__ import print_function
from sys import version_info, stdout
from daqhats_utils import select_hat_device
from daqhats import mcc152, OptionFlags, HatIDs, HatError
import time
import math
import matplotlib.pyplot as plt

lis1=[]
lis2=[]
cycles=1
    
while cycles<=150:
    t=0
    lis1.clear()
    lis2.clear()
        
    while t<=5+.025:
        
        lis1.append(t)
        w=2*2*math.pi
        x = 2.5+.625*math.sin(w*t)
        print("%.2f"%x,"%.2f"%w,"%.2f"%t,"%.2f"%cycles)
        t=t+.03
        time.sleep(.004583)
        lis2.append(x)             
        
        options = OptionFlags.DEFAULT
        channel = 0
        num_channels = mcc152.info().NUM_AO_CHANNELS

        address = select_hat_device(HatIDs.MCC_152)

        hat = mcc152(address)
        value = x
        hat.a_out_write(channel=channel, value=value, options=options)
        stdout.flush()
        
    cycles=cycles+1
    #plt.plot(lis1,lis2)
    #plt.show()
    
value = 0
hat.a_out_write(channel=channel, value=value, options=options)
            
