#!/usr/bin/env python3.3
#  -*- coding: utf-8 -*-


#THIS LINE IS USED TO CALL ON TOOLS AND LIBRARIES
from __future__ import print_function
from time import sleep
from sys import stdout
from daqhats import mcc118, mcc152, OptionFlags, HatIDs, HatError
from daqhats_utils import select_hat_device, enum_mask_to_string, chan_list_to_mask
from sys import version_info, stdout
from tkinter import *
from tkinter import font
import math
import time
import matplotlib.pyplot as plt

#THIS LINE IS SETTING UP THE GUI WINDOW AND FONT
win = Tk()
myFont = font.Font (family="Times New Roman", size=12)


#THIS LINE IS IMPORTING A TIME STAMP CONSTANT THAT WILL BE USED TO CALCULATE RUNNING TIME
ts= time.time()

#THIS LINE DEFINES THE CHANNELS TO BE RECORDED BY THE MCC118 HAT
channels = Tk()
channels.title('Channel Entry')
chan = Entry(channels, str (input("Enter Channels to Record Seperated by Commas:")))
chan.grid(row=0, column=1)
list = chan.split(",")
li=[]
for i in list:
    li.append(int(i))
print(li)

chan = li

channel_mask = chan_list_to_mask(chan)
num_channels = len(chan)

#THIS LINE DEFINES THE MAX SAMPLES TO LOOK AT AND HOW QUICK THE HAT SCANS DATA
samples_per_channel = 30
scan_rate = 10.0 
options = OptionFlags.DEFAULT


#THIS LINE SELECTS THE MCC118 HAT TO USE AND DISPLAYS THE OPERATING PARAMETERS IN THE DIALOG WINDOW
address = select_hat_device(HatIDs.MCC_118)
hat = mcc118(address)
hat.a_in_scan_stop()
print('\nSelected MCC 118 HAT device at address', address)
actual_scan_rate = hat.a_in_scan_actual_rate(num_channels, scan_rate)
input('\nPress ENTER to continue ...')
            

#THIS LINE CONFIGURES AND STARTS THE SCAN BASED ON THE SELECTED PARAMETERS
hat.a_in_scan_start(channel_mask, samples_per_channel, scan_rate,options)


#THIS LINE PRODUCES HEADERS FOR THE DATA SET IN THE DIALOG WINDOW
print('Samples Read    Scan Count', end='')
for channel in chan:
    print('    Channel ', chan, sep='', end='')
print('')


#THIS LINE READS THE DATA AND DISPLAYS IT IN THE DIALOG WINDOW
def read_and_display_data(hat, samples_per_channel, num_channels):
    total_samples_read = 0
    read_request_size = 1
    timeout = 10.0

    # Continuously update the display value until Ctrl-C is
    # pressed or the number of samples requested has been read.
    while total_samples_read < samples_per_channel:
        read_result = hat.a_in_scan_read(read_request_size, timeout)

        # Check for an overrun error
        if read_result.hardware_overrun:
            print('\nHardware overrun\n')
            break
        elif read_result.buffer_overrun:
            print('\nBuffer overrun\n')
            break
        
        td= time.time() - ts
        samples_read_per_channel = int(len(read_result.data) / num_channels)
        total_samples_read += samples_read_per_channel
                  
        # Display the last sample for each channel.
        print('\r{:8}'.format(samples_read_per_channel),' {:12} '.format(total_samples_read), end='')


        if samples_read_per_channel > 0:
            index = samples_read_per_channel * num_channels - num_channels

            for i in range(num_channels):
                file_object=open("data","a")
                file_object.write('{0} {1}\n'.format("%.6f"%td,"%.2f"%read_result.data[index + i]))
                
                print('{:12.5f}'.format(read_result.data[index + i]), 'V ',
                      end='')
           
            stdout.flush()
            #sleep(1.0)
            print('\n')


read_and_display_data(hat, samples_per_channel, num_channels)
