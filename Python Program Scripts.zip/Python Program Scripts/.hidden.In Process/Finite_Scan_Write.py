#!/usr/bin/env python
#  -*- coding: utf-8 -*-

from __future__ import print_function
from time import sleep
from sys import stdout
from daqhats import mcc118, OptionFlags, HatIDs, HatError
from daqhats_utils import select_hat_device, enum_mask_to_string, chan_list_to_mask
import time

CURSOR_BACK_2 = '\x1b[2D'
ERASE_TO_END_OF_LINE = '\x1b[0K'


str = str (input("Enter Channels to Record Seperated by Commas:"))
list=str.split(",")
li=[]
for i in list:
    li.append(int(i))
print(li)

channels = li

channel_mask = chan_list_to_mask(channels)
num_channels = len(channels)

samples_per_channel = 10
scan_rate = 10.0 
options = OptionFlags.DEFAULT


# Select an MCC 118 HAT device to use.
address = select_hat_device(HatIDs.MCC_118)
hat = mcc118(address)
hat.a_in_scan_stop()

print('\nSelected MCC 118 HAT device at address', address)

actual_scan_rate = hat.a_in_scan_actual_rate(num_channels, scan_rate)


input('\nPress ENTER to continue ...')
            

# Configure and start the scan.
hat.a_in_scan_start(channel_mask, samples_per_channel, scan_rate,options)

# Display the header row for the data table.
print('Samples Read    Scan Count', end='')

for chan in channels:
    print('    Channel ', chan, sep='', end='')
    
print('')


def read_and_display_data(hat, samples_per_channel, num_channels):
    total_samples_read = 0
    read_request_size = 1
    timeout = 10.0

    # Continuously update the display value until Ctrl-C is
    # pressed or the number of samples requested has been read.
    while total_samples_read < samples_per_channel:
        read_result = hat.a_in_scan_read(read_request_size, timeout)

        # Check for an overrun error
        if read_result.hardware_overrun:
            print('\nHardware overrun\n')
            break
        elif read_result.buffer_overrun:
            print('\nBuffer overrun\n')
            break
        
        ts= time.time()
        samples_read_per_channel = int(len(read_result.data) / num_channels)
        total_samples_read += samples_read_per_channel
                  
        # Display the last sample for each channel.
        print('\r{:8}'.format(samples_read_per_channel),' {:12} '.format(total_samples_read), end='')


        if samples_read_per_channel > 0:
            index = samples_read_per_channel * num_channels - num_channels

            for i in range(num_channels):
                file_object=open("data","a")
                file_object.write('{0} {1} {2}\n'.format("%.6f"%ts,"%.2f"%read_result.data[index + i]))
                
                print('{:12.5f}'.format(read_result.data[index + i]), 'V ',
                      end='')
           
            stdout.flush()
            #sleep(1.0)
            print('\n')


read_and_display_data(hat, samples_per_channel, num_channels)
stdout.flush()