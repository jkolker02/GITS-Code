from daqhats import mcc118, mcc152, OptionFlags, HatIDs, HatError
from daqhats_utils import select_hat_device, enum_mask_to_string, chan_list_to_mask
import tkinter as tk
from tkinter import *
from tkinter import Canvas
import time
import math
import numpy as np
from time import sleep

from daqhats import mcc118, mcc152, OptionFlags, HatIDs, HatError
from daqhats_utils import select_hat_device, enum_mask_to_string, chan_list_to_mask

#-----gather board information-----
#

address = select_hat_device(HatIDs.MCC_152)
hat = mcc152(address)
options = OptionFlags.DEFAULT
info = mcc152.info().NUM_AO_CHANNELS
channel = 0

address1 = select_hat_device(HatIDs.MCC_118)
hat1 = mcc118(address1)

#-----create window & configure initial grid-----
#

window = tk.Tk()
window.grid()
window.configure(background = '#d9d9d9')
window.title('Rivet Torsional Strength Test')

#-----Variable Declaration-----
#
final_Pressure = float(150.0)
start_Pressure = float(0.0)
current_Pressure = 0
execution_Time = int(20)
running = False
manual_running = False
permission = DISABLED

time_Array = [0]
pressure_Array = [0]
voltage_Array = [0]
result1_Array = [0]
result2_Array = [0]

runtime = 0;
start_time = 0;
current_time = 0;

results_file = open('results_file.txt', 'w')



m = (final_Pressure - start_Pressure) / execution_Time

#----Column initialization-----
#

window.grid_columnconfigure(0, minsize = 50, weight = 1)
window.grid_columnconfigure(1, minsize = 50, weight = 1)
window.grid_columnconfigure(2, minsize = 50, weight = 1)
window.grid_columnconfigure(3, minsize = 80, weight = 1)
window.grid_columnconfigure(4, minsize = 50, weight = 1)
window.grid_columnconfigure(5, minsize = 50, weight = 1) #Divider
window.grid_columnconfigure(6, minsize = 50, weight = 1)
window.grid_columnconfigure(7, minsize = 50, weight = 1)
window.grid_columnconfigure(8, minsize = 50, weight = 1)
window.grid_columnconfigure(9, minsize = 50, weight = 1)
window.grid_columnconfigure(10, minsize = 50, weight = 1)

window.grid_rowconfigure(0, minsize = 40, weight = 1)
window.grid_rowconfigure(1, minsize = 10, weight = 1)#Title Line
window.grid_rowconfigure(2, minsize = 40, weight = 1)
window.grid_rowconfigure(3, minsize = 40, weight = 1)
window.grid_rowconfigure(4, minsize = 40, weight = 1)
window.grid_rowconfigure(5, minsize = 40, weight = 1)
window.grid_rowconfigure(6, minsize = 40, weight = 1)
window.grid_rowconfigure(7, minsize = 40, weight = 1)
window.grid_rowconfigure(8, minsize = 40, weight = 1)
window.grid_rowconfigure(9, minsize = 40, weight = 1)



#-----Function Declaration-----
#

def set_Final_Pressure():
    global final_Pressure
    final_Pressure = int(end_Pressure_entry.get())
    end_Pressure_entry.delete(0,'end')
    label1 = Label(window, text = "The starting pressure is {}\n The final pressure is {}".format(start_Pressure, final_Pressure), width = 30)
    label1.grid(row = 8, column = 1,columnspan = 2)
    update_Time_Array()
    
    
def set_Start_Pressure():
    global start_Pressure
    start_Pressure = int(start_Pressure_Entry.get())
    start_Pressure_Entry.delete(0,'end')
    label1 = Label(window, text = "The starting pressure is {}\n The final pressure is {}".format(start_Pressure, final_Pressure), width = 30)
    label1.grid(row = 8, column = 1, columnspan = 2)
    update_Time_Array()


def set_Execution_Time():
    global execution_Time
    execution_Time = int(execution_Time_Entry.get())
    execution_Time_Entry.delete(0,'end')
    ex_Time_Label = Label(window, text = 'Current set execution time: {}'.format(execution_Time), fg = 'black', bg = '#d9d9d9', font = "Arial 8 normal", width = 28)
    ex_Time_Label.grid(row = 4, column = 0, sticky = S)
    update_Time_Array()
    
def update_Pressure_Display():
    label1 = Label(window, text = "The starting pressure is {}\n The final pressure is {}".format(start_Pressure, final_Pressure), width = 30)
    label1.grid(row = 8, column = 1, columnspan = 2, sticky = E)
    
def update_User_Status():
    if (running):
        status = Label(window, text = "Current User Status: Active", font = "Arial 8 normal", bg = '#d9d9d9', fg = 'Green', width = 25)
    else:
        status = Label(window, text = "Current User Status: Inactive", font = "Arial 8 normal", bg = '#d9d9d9', fg = 'REd', width = 25)
    status.grid(row = 6, column = 0)
    
def update_Manual_Status():
    if (manual_running):
        status = Label(window, text = "Current Manual Status: Active", font = "Arial 8 normal", bg = '#d9d9d9', fg = "Green", width = 25)
    else:
        status = Label(window, text = "Current Manual Status: Inactive", font = "Arial 8 normal", bg = '#d9d9d9', fg = 'red', width = 30)
    status.grid(row = 6, column = 8, columnspan = 2)
    
def enable_Manual():
    global permission
    global manual_running
    global running
    
    manual_running = True
    running = False
    slider['state'] = ACTIVE
    update_User_Status()
    update_Manual_Status()
    
def disable_Manual():
    global permission
    global manual_running
    global running
    
    manual_running = False
    slider['state'] = DISABLED
    update_Manual_Status()
    
def user_Start():
    global running
    running = True
    update_User_Status()
    disable_Manual()
    update_Manual_Status()

def user_Stop():
    global running
    running = False
    update_User_Status()
    
def exit_Program():
    hat.a_out_write(channel=channel,value=0,options=options)
    sys.exit()

def update_Time_Array():
    global time_Array
    global pressure_Array
    global execution_Time
    global start_Pressure
    global final_Pressure
    global voltage_Array
    global m
    
    time_Array = [0] * (execution_Time * 100)
    
    
    pressure_Array = time_Array
    m = (final_Pressure - start_Pressure) / execution_Time
    
    for i in range(0, len(pressure_Array)):
        pressure_Array[i] = round(((time_Array[i] * m) + start_Pressure),3)
        
    
    for i in range(0, len(voltage_Array)):
        voltage_Array = pressure_Array
    
        
def update_Current_Set_Pressure(value):
    global current_Pressure
    global current_time
    global start_time
    global m
    
    current_Pressure = current_Pressure
    if manual_running:
        current_Pressure = int(slider.get())
    if running:
        current_Pressure = (m * (time.time()-start_time))
    label = Label(window, text = 'Current Pressure Set at: {} psi'.format(current_Pressure), fg = 'black', bg = '#d9d9d9', font = 'Arial 10 normal', width = 30)
    label.grid(row = 4, column =6, columnspan = 2) 
    
def run():
    global running
    global manual_Running
    global runtime
    global execution_Time
    global start_time
    global current_time
    global current_Pressure
    global start_Pressure
    global final_Pressure
    global time_Array
    global result1_Array
    global result2_Array
    
    
    start_time = time.time()
    if (running):
        
        while runtime < execution_Time:
            blah
            current_time = time.time()
            runtime = current_time - start_time
            time.append(runtime)
            value = start_Pressure + (runtime * m)
            #voltage = value * conversion_factor
            #hat.a_out_write(channel=channel,value=voltage,options=options)
            result1_Array.append(hat1.a_in_read(channel = 0, options = options))
            result2_Array.append(hat1.a_in_read(channel = 1, options = options))
            sleep(.01)
            
            
        running = False
    while (manual_Running):
        update_Current_Set_Pressure()
        current_time = time.time()
        runtime = current_time - start_time
        value = current_Pressure
        time[i] = runtime
        #voltage = value * conversion_factor
        #hat.a_out_write(channel=channel, value = voltage, options=options)
        result1_Array.append(hat1.a_in_read(channel = 0, options = options))
        result2_Array.append(hat1.a_in_read(channel = 1, options = options))
        sleep(.01)
        
        
    
    
   
    

#-----Inserting labels-----
#
frame0 = tk.Frame(window, bg = 'black')
frame0.grid(row=0,column=0,columnspan = 11)


frame1= Label(window, text="User Input",fg = 'black', bg='#d9d9d9', font = 'Arial 19 bold', padx = 15, pady = 7)
frame1.grid(row=0,column=2, sticky = W)

frame2 = Label(window, text="Manual Control", fg = 'black',bg='#d9d9d9', font = 'Arial 19 bold', padx = 15, pady=7)
frame2.grid(row=0, column = 7)



#-----Aestetics-----
#


titleFrame = tk.Frame(window, bg = 'black')
titleFrame.grid(row=1, column = 0, columnspan = 11, sticky = 'ew')


#-----User entered data-----
#

start_Pressure_Label = Label(window, text="Starting PSI: ", fg = 'black', bg = '#d9d9d9', font = "Arial 13 normal", padx = 10, pady = 25)
start_Pressure_Label.grid(row = 2, column = 0, sticky = W)

start_Pressure_Entry = tk.Entry(window)
start_Pressure_Entry.grid(row = 2, column = 2, sticky = W)

button1 = Button(window, text = 'Enter',  command = set_Start_Pressure, fg = 'black', bg = '#aeaeae', font = "Arial 8 bold", bd = 2, width = 2, height = 1, activebackground = '#11c808', activeforeground = 'white')
button1.grid(row = 2, column = 3, sticky = W)



ending_Pressure = Label(window, text="Final PSI: ", fg = 'black', bg = '#d9d9d9', font = "Arial 13 normal",padx = 10, pady = 10)
ending_Pressure.grid(row = 3, column = 0, sticky = W)

end_Pressure_entry = tk.Entry(window)
end_Pressure_entry.grid(row = 3, column = 2, sticky = W)

button2 = Button(window, text = 'Enter', command = set_Final_Pressure, fg = 'black', bg = '#aeaeae', font = "Arial 8 bold", bd = 2, width = 2, height = 1, activebackground = '#11c808', activeforeground = 'white')
button2.grid(row = 3, column = 3, sticky = W)



execution_Time_L = Label(window, text = 'Execution Time (sec): ', fg  = 'black', bg = '#d9d9d9', font = "Arial 13 normal", padx = 10, pady =25)
execution_Time_L.grid(row = 4, column = 0, sticky = E)

execution_Time_Entry = tk.Entry(window)
execution_Time_Entry.grid(row = 4, column = 2, sticky = W)

button3 = Button(window, text = 'Enter', command = set_Execution_Time, fg = 'black', bg = '#aeaeae', font = "Arial 8 bold", bd = 2, width = 2, height = 1, activebackground = '#11c808', activeforeground = 'white')
button3.grid(row = 4, column = 3, sticky = W)

ex_Time_Label = Label(window, text = 'Current set execution time: {}'.format(execution_Time), fg = 'black', bg = '#d9d9d9', font = "Arial 8 normal", width = 32)
ex_Time_Label.grid(row = 4, column = 0, sticky = S)

update_Pressure_Display()
update_User_Status()
update_Manual_Status()
update_Current_Set_Pressure(0)

start_Button = Button(window, text = "Run Program", command = user_Start, fg = 'white', bg = '#11c808', font = "Arial 12 bold", bd = 3, height = 2, width = 10, activebackground = '#08A800', activeforeground = 'white')
start_Button.grid(row = 9, column = 1, columnspan = 2, sticky = W)

stop_Button = Button(window, text = "Stop Program", command = user_Stop, fg = 'white', bg = '#ff4848', font = 'Arial 12 bold', bd = 3, height = 2, width = 10, activebackground = '#c90000', activeforeground = 'white')
stop_Button.grid(row = 9, column = 1, columnspan = 2, sticky = E)






#-----Manual Control-----
#
slider = Scale(window, from_= start_Pressure, to = final_Pressure, orient = HORIZONTAL, length = 300, state = permission, command = update_Current_Set_Pressure)
slider.grid(row = 2, column = 7)

toggle_Lock_B = Button(window, text = "Enable Manual", command = enable_Manual, fg = 'white', bg = '#11c808', font = "Arial 8 bold", bd = 2, width = 10, height = 1,pady = -2, activebackground = '#08A800', activeforeground = 'white')
toggle_Lock_B.grid(row = 3, column = 7, sticky = W)

toggle_Lock_B2 = Button(window, text = "Disable Manual", command = disable_Manual, fg = 'white', bg = '#ff4848', font = "Arial 8 bold", bd = 2, width = 10, height = 1,pady = -2, activebackground = '#c90000', activeforeground = 'white')
toggle_Lock_B2.grid(row = 3, column = 7, sticky = E)


exit_Button = Button(window, text = 'EXIT', fg = 'white', bg = '#c40909', font = "Arial 18 bold", bd = 4, width = 8, height = 1, activebackground = '#940606', activeforeground = 'white', command = exit_Program)
exit_Button.grid(row = 9, column = 0, sticky = SW)





window.mainloop()