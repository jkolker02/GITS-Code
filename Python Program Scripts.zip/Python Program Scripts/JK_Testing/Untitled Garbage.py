import tkinter as tk
from tkinter import Canvas

app = tk.Tk()
#app.title('Canvas')

canvas = Canvas(app)
canvas.pack()

canvas.create_line(10,10,150,50)
app.mainloop()