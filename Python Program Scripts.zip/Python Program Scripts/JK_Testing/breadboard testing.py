#!/usr/bin/env python3

from __future__ import print_function
from time import sleep
from sys import version_info, stdout
from tkinter import *
from PIL import Image
from PIL import ImageTk
from decimal import Decimal
import numpy as np

from daqhats import mcc118, mcc152, OptionFlags, HatIDs, HatError
from daqhats_utils import select_hat_device, enum_mask_to_string, chan_list_to_mask
import math
import tkinter as tk
import time
import matplotlib.pyplot as plt


address = select_hat_device(HatIDs.MCC_152)
hat = mcc152(address)
options = OptionFlags.DEFAULT
info = mcc152.info().NUM_AO_CHANNELS
channel = 0
li = []


results = []
times = []


address1 = select_hat_device(HatIDs.MCC_118)
hat1 = mcc118(address1)

hat.a_out_write(channel=channel,value=5,options=options)
start_time = time.time()
while (time.time() - start_time) < 8:
    #val = 5*(math.sin(time.time()))
    val = 5
    hat.a_out_write(channel=channel,value=abs(val),options=options)
    value = hat1.a_in_read(channel = 0, options = options)
    results.append(value)
    times.append(time.time() - start_time)
    sleep(.01)

    
plt.plot(times,results)
plt.show()
 

hat.a_out_write(channel = channel, value = 0, options = options)

file = open("helloTest.txt", 'w')
for i in range(0, len(times)):
    timerrr = str(format(times[i],'.6f'))
    file.write(timerrr +  ' ')
    resultss = str(format(results[i],'.6f'))
    file.write(resultss)
    file.write('\n')
   
file.close()
    